# AgentArena AI

**Don't Just Trust the Agent. Test It.**  
*Measure. Compare. Evaluate. Deploy with Confidence.*

AgentArena AI is an autonomous AI agent benchmarking and evaluation platform designed to evaluate how multi-step, tool-using AI agents perform on identical standardized real-world workflows before production deployment.

## Architecture & Folder Structure

```text
├── server.ts                          # Express API server + Vite middleware on port 3000
├── server/
│   ├── db/
│   │   ├── database.ts                # SQLite (WAL) connection singleton & initialization
│   │   ├── migrations.ts              # Versioned relational schema migrations (10 tables)
│   │   └── seedDemo.ts                # Clearly-labelled Demo Mode dataset + live agent defaults
│   ├── evaluator/
│   │   └── judgeEvaluator.ts          # Deterministic checks + isolated LLM-as-judge rubric
│   ├── generator/
│   │   └── taskGenerator.ts           # Standardized scenario generator (3–30 tasks)
│   ├── orchestrator/
│   │   └── benchmarkGraph.ts          # State-graph orchestrator (isolation, retries, concurrency)
│   ├── providers/
│   │   ├── geminiClient.ts            # Server-side @google/genai client
│   │   └── providerAdapter.ts         # Unified adapters for Gemini, OpenAI, Anthropic
│   └── tools/
│       └── sandboxTools.ts            # Whitelisted, deterministic enterprise sandbox tools
├── src/
│   ├── App.tsx                        # Main workspace shell & 7 navigation views
│   ├── types/benchmark.ts             # Shared TypeScript domain contracts
│   ├── utils/scoring.ts               # Pure weighted scoring, cost, reliability & recommendations
│   ├── utils/scoring.test.ts          # Node test runner unit tests
│   ├── services/api.ts                # Typed REST client & jsPDF report exporter
│   └── components/                    # Modular dashboard, wizard, analytics, trace & leaderboard UI
├── Dockerfile
├── docker-compose.yml
└── .env.example
```

## Database Schema (10 Core Tables + Settings)

Managed automatically via versioned migrations in `server/db/migrations.ts`:

- `users` — workspace operators
- `providers` — Gemini, OpenAI, Anthropic provider catalog & model metadata
- `agent_configurations` — agent profiles, system prompts, allowed tool permissions, token pricing
- `benchmark_suites` — benchmark suite definitions, industry categories, scoring weights, repeat settings
- `test_cases` — standardized tasks, expected outcomes, evaluation criteria, deterministic assertions
- `benchmark_runs` — execution run metadata, live progress tracking, Demo vs Live isolation (`is_demo`)
- `agent_executions` — isolated agent outputs, latency, token usage, USD cost, error statuses
- `evaluation_results` — deterministic pass/fail notes, independent judge reasoning, evidence, limitations
- `tool_events` — chronological observable timeline of steps, tool calls, tool responses, and policy blocks
- `historical_rankings` — versioned rankings per suite & category
- `platform_settings` — orchestrator timeouts, retries, concurrency limits, judge model

## API Endpoints

- `GET /api/health` — Server readiness & environment-configured provider status (never exposes secrets)
- `GET /api/dashboard?mode=demo|live` — Aggregated overview metrics separated by Demo vs Live
- `GET/POST/PUT/DELETE /api/agents` — Agent & tool permission configuration
- `GET/POST /api/suites` — Create benchmark suites
- `POST /api/suites/:id/generate-tasks` — Generate standardized test scenarios
- `PUT/DELETE /api/test-cases/:id` — Edit, approve, or remove scenarios
- `GET/POST /api/runs` — List runs or launch isolated benchmark execution
- `GET /api/runs/:id` — Hydrated run details, summaries, evaluations, and execution traces
- `POST /api/runs/:id/cancel` — Cancel an active run
- `GET /api/runs/:id/export` — Download CSV benchmark report
- `GET /api/leaderboard?mode=demo|live&category=...` — Category & suite-versioned rankings
- `GET/PUT /api/settings` — Platform orchestrator & evaluation defaults

## Local Setup & Commands

1. Copy `.env.example` to `.env` and configure `GEMINI_API_KEY` (and optional `OPENAI_API_KEY` / `ANTHROPIC_API_KEY`).
2. Install dependencies: `npm install`
3. Run unit tests: `npx tsx --test src/utils/scoring.test.ts`
4. Start development server: `npm run dev` (serves on `http://localhost:3000`)
5. Production build: `npm run build` then `npm start`

## Docker Deployment

```bash
docker compose up --build
```
