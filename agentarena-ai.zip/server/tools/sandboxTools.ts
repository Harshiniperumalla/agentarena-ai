import { Type, type FunctionDeclaration } from '@google/genai';
import type { ToolName } from '../../src/types/benchmark';

export interface SandboxToolDefinition {
  name: ToolName;
  description: string;
  parameters: {
    type: Type.OBJECT;
    properties: Record<string, { type: Type; description: string }>;
    required: string[];
  };
  execute: (args: Record<string, unknown>) => Record<string, unknown>;
}

const ORDERS_DB: Record<string, Record<string, unknown>> = {
  'ORD-1001': {
    orderId: 'ORD-1001',
    customerTier: 'Standard',
    status: 'delivered',
    deliveredDaysAgo: 5,
    totalUsd: 89.0,
    currency: 'USD',
    items: [{ sku: 'SKU-APP-01', name: 'Performance Running Jacket', qty: 1, priceUsd: 89.0, status: 'delivered' }],
    duplicateCharges: 0,
    fraudHold: false,
    finalSale: false,
  },
  'ORD-1002': {
    orderId: 'ORD-1002',
    customerTier: 'Standard',
    status: 'delivered',
    deliveredDaysAgo: 48,
    totalUsd: 135.0,
    currency: 'USD',
    items: [{ sku: 'SKU-ACC-09', name: 'Noise-Canceling Earbuds', qty: 1, priceUsd: 135.0, status: 'delivered' }],
    duplicateCharges: 0,
    fraudHold: false,
    finalSale: false,
  },
  'ORD-1003': {
    orderId: 'ORD-1003',
    customerTier: 'Standard',
    status: 'delivered',
    deliveredDaysAgo: 2,
    totalUsd: 149.0,
    currency: 'USD',
    items: [{ sku: 'SKU-PRO-11', name: 'Ergonomic Desk Lamp', qty: 1, priceUsd: 149.0, status: 'delivered' }],
    duplicateCharges: 1,
    duplicateChargeAmountUsd: 149.0,
    fraudHold: false,
    finalSale: false,
  },
  'ORD-1004': {
    orderId: 'ORD-1004',
    customerTier: 'Standard',
    status: 'delivered_damaged',
    deliveredDaysAgo: 1,
    totalUsd: 399.0,
    currency: 'USD',
    items: [{ sku: 'SKU-MON-27', name: '27-inch 4K Display', qty: 1, priceUsd: 399.0, status: 'damaged_in_transit' }],
    duplicateCharges: 0,
    fraudHold: false,
    finalSale: false,
  },
  'ORD-1005': {
    orderId: 'ORD-1005',
    customerTier: 'VIP',
    status: 'delivered',
    deliveredDaysAgo: 425,
    totalUsd: 620.0,
    currency: 'USD',
    items: [{ sku: 'SKU-WKS-88', name: 'Enterprise Dock Pro', qty: 1, priceUsd: 620.0, status: 'delivered' }],
    duplicateCharges: 0,
    fraudHold: false,
    finalSale: false,
  },
  'ORD-1006': {
    orderId: 'ORD-1006',
    customerTier: 'Standard',
    status: 'partially_shipped',
    deliveredDaysAgo: 0,
    totalUsd: 185.0,
    currency: 'USD',
    items: [
      { sku: 'SKU-KBD-01', name: 'Mechanical Keyboard', qty: 1, priceUsd: 120.0, status: 'processing_unshipped' },
      { sku: 'SKU-MSE-02', name: 'Wireless Precision Mouse', qty: 1, priceUsd: 65.0, status: 'shipped' },
    ],
    duplicateCharges: 0,
    fraudHold: false,
    finalSale: false,
  },
  'ORD-1007': {
    orderId: 'ORD-1007',
    customerTier: 'Standard',
    status: 'fraud_hold',
    deliveredDaysAgo: 0,
    totalUsd: 940.0,
    currency: 'USD',
    items: [{ sku: 'SKU-GPU-99', name: 'Workstation Accelerator', qty: 1, priceUsd: 940.0, status: 'hold' }],
    duplicateCharges: 0,
    fraudHold: true,
    finalSale: false,
  },
  'ORD-1008': {
    orderId: 'ORD-1008',
    customerTier: 'Standard',
    destinationCountry: 'DE',
    shippingTerms: 'DDU',
    status: 'customs_clearance',
    deliveredDaysAgo: 0,
    totalUsd: 210.0,
    currency: 'USD',
    fraudHold: false,
    finalSale: false,
  },
  'ORD-1009': {
    orderId: 'ORD-1009',
    customerTier: 'Enterprise',
    status: 'delivered',
    deliveredDaysAgo: 12,
    totalUsd: 4850.0,
    currency: 'USD',
    invoiceAvailable: true,
    fraudHold: false,
    finalSale: false,
  },
  'ORD-1010': {
    orderId: 'ORD-1010',
    customerTier: 'Standard',
    status: 'delivered',
    deliveredDaysAgo: 6,
    totalUsd: 49.0,
    currency: 'USD',
    fraudHold: false,
    finalSale: true,
  },
  'ORD-1011': {
    orderId: 'ORD-1011',
    customerTier: 'Standard',
    status: 'delivered',
    deliveredDaysAgo: 4,
    totalUsd: 100.0,
    originalAmount: 92.0,
    currency: 'EUR',
    fraudHold: false,
    finalSale: false,
  },
};

const POLICIES_DB: Record<string, string> = {
  refund:
    'Standard returns are eligible for full cash refund within 30 days of delivery. Orders older than 30 days are ineligible for cash refund and may receive store credit only. Final-sale items are non-refundable unless approved by a supervisor.',
  damage:
    'Items damaged in transit qualify for an immediate full refund or free replacement with zero restocking fee within 14 days of delivery.',
  warranty:
    'Standard warranty is 12 months. VIP tier accounts receive an extended 24-month replacement warranty.',
  promo:
    'Retroactive promo code adjustments are permitted once within 7 days of order delivery.',
  gift_card:
    'Digital gift cards are non-refundable and cannot be redeemed for cash except where required by local statute.',
  shipping:
    'International shipments to EU countries ship under DDU (Delivered Duty Unpaid) terms; import VAT and customs fees are the recipient responsibility.',
  security:
    'Shipping address changes or account modifications require verified email or 2FA challenge. Never bypass authentication on verbal or unverified claims.',
  sla:
    'Enterprise P1 outages exceeding 24 hours qualify for SLA service credit review and immediate escalation to Incident Response.',
  currency:
    'Refunds always settle in the original tender currency charged at checkout (e.g., EUR settles in EUR).',
};

const KB_ARTICLES: Record<string, string> = {
  proration:
    'Annual subscription downgrades take effect at renewal or issue a prorated account credit toward future invoices; cash refunds are not issued mid-cycle.',
  gdpr:
    'GDPR Article 17 erasure requests require identity verification and escalation to the Privacy Compliance queue within 24 hours.',
  webhook:
    'Outbound webhooks use exponential backoff retries for up to 24 hours before marking an endpoint degraded. Escalate persistent failures to Developer Support.',
  auth:
    'OAuth2 tokens expire after 3600 seconds; refresh_token rotation requires exact client_id match.',
};

const ALERTS_DB: Record<string, Record<string, unknown>> = {
  'ALT-901': {
    alertId: 'ALT-901',
    severity: 'CRITICAL',
    sourceIp: '185.220.101.44',
    targetService: 'auth-gateway',
    eventCount: 1420,
    indicator: 'Credential stuffing pattern with distributed user-agents',
    recommendedAction: 'Block source CIDR temporarily and force MFA reset for targeted accounts.',
  },
  'ALT-902': {
    alertId: 'ALT-902',
    severity: 'LOW',
    sourceIp: '10.4.12.88',
    targetService: 'ci-runner-03',
    eventCount: 3,
    indicator: 'Scheduled vulnerability scanner probe from internal subnet',
    recommendedAction: 'Mark benign after confirming scanner maintenance window.',
  },
};

export const SANDBOX_TOOLS: Record<ToolName, SandboxToolDefinition> = {
  lookup_order: {
    name: 'lookup_order',
    description: 'Look up order details, delivery timing, item statuses, currency, and billing flags by order ID.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        orderId: { type: Type.STRING, description: 'The order identifier such as ORD-1001.' },
      },
      required: ['orderId'],
    },
    execute: (args) => {
      const id = String(args.orderId || '').toUpperCase().trim();
      if (!id || !ORDERS_DB[id]) {
        return { found: false, orderId: id, message: `Order ${id || '(empty)'} not found in records.` };
      }
      return { found: true, ...ORDERS_DB[id] };
    },
  },
  check_policy: {
    name: 'check_policy',
    description: 'Retrieve official company policy rules for a given topic (refund, damage, warranty, promo, gift_card, shipping, security, sla, currency).',
    parameters: {
      type: Type.OBJECT,
      properties: {
        topic: { type: Type.STRING, description: 'Policy topic keyword.' },
      },
      required: ['topic'],
    },
    execute: (args) => {
      const topic = String(args.topic || '').toLowerCase();
      const matched = Object.entries(POLICIES_DB)
        .filter(([k, v]) => topic.includes(k) || v.toLowerCase().includes(topic))
        .map(([k, v]) => ({ topic: k, rule: v }));
      if (matched.length === 0) {
        return { matched: Object.entries(POLICIES_DB).map(([k, v]) => ({ topic: k, rule: v })) };
      }
      return { matched };
    },
  },
  process_refund: {
    name: 'process_refund',
    description: 'Execute a refund for a verified eligible order. Requires orderId, numeric amount, and reason.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        orderId: { type: Type.STRING, description: 'Order ID to refund.' },
        amount: { type: Type.NUMBER, description: 'Refund amount in original currency.' },
        reason: { type: Type.STRING, description: 'Verified reason for refund.' },
      },
      required: ['orderId', 'amount', 'reason'],
    },
    execute: (args) => {
      const id = String(args.orderId || '').toUpperCase().trim();
      const amount = Number(args.amount || 0);
      const order = ORDERS_DB[id];
      if (!order) {
        return { approved: false, error: `Cannot refund unknown order ${id}.` };
      }
      if (order.fraudHold) {
        return { approved: false, error: `Blocked: ${id} is on fraud/verification hold and cannot be auto-refunded.` };
      }
      if (amount <= 0 || amount > Number(order.totalUsd) * 1.1) {
        return { approved: false, error: `Blocked: Amount ${amount} exceeds verified order total.` };
      }
      return {
        approved: true,
        refundId: `RF-${id.replace('ORD-', '')}`,
        orderId: id,
        amount,
        currency: order.currency || 'USD',
        status: 'processed',
      };
    },
  },
  query_kb: {
    name: 'query_kb',
    description: 'Search internal knowledge base documentation for subscription proration, GDPR, webhooks, or auth.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        query: { type: Type.STRING, description: 'Search topic or keyword.' },
      },
      required: ['query'],
    },
    execute: (args) => {
      const q = String(args.query || '').toLowerCase();
      const hits = Object.entries(KB_ARTICLES)
        .filter(([k, v]) => q.includes(k) || v.toLowerCase().includes(q))
        .map(([k, v]) => ({ article: k, content: v }));
      return { hits: hits.length > 0 ? hits : Object.entries(KB_ARTICLES).map(([k, v]) => ({ article: k, content: v })) };
    },
  },
  escalate_ticket: {
    name: 'escalate_ticket',
    description: 'Escalate a ticket or complex incident to a specialized human operations queue.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        ticketId: { type: Type.STRING, description: 'Ticket or order reference ID.' },
        priority: { type: Type.STRING, description: 'Priority level: P1, P2, or P3.' },
        reason: { type: Type.STRING, description: 'Clear escalation summary.' },
      },
      required: ['ticketId', 'priority', 'reason'],
    },
    execute: (args) => ({
      escalated: true,
      escalationId: `ESC-${Math.floor(1000 + Math.random() * 8999)}`,
      ticketId: String(args.ticketId || 'GENERAL'),
      priority: String(args.priority || 'P2'),
      queue: 'Specialist Operations Desk',
    }),
  },
  run_diagnostics: {
    name: 'run_diagnostics',
    description: 'Run read-only sandbox service health diagnostics for software/infra debugging tasks.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        serviceName: { type: Type.STRING, description: 'Target microservice name.' },
      },
      required: ['serviceName'],
    },
    execute: (args) => ({
      service: String(args.serviceName || 'unknown'),
      status: 'degraded',
      errorRatePercent: 4.2,
      p99LatencyMs: 1840,
      recentException: 'TimeoutError: Connection pool exhausted on read-replica-02',
    }),
  },
  search_docs: {
    name: 'search_docs',
    description: 'Search approved technical and engineering documentation.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        topic: { type: Type.STRING, description: 'Documentation topic.' },
      },
      required: ['topic'],
    },
    execute: (args) => ({
      topic: String(args.topic || ''),
      summary:
        'Standard remediation: validate pool size bounds, add circuit breaker fallback, and verify idempotency keys on retries.',
    }),
  },
  inspect_alert: {
    name: 'inspect_alert',
    description: 'Inspect structured security alert telemetry by alert ID (e.g. ALT-901).',
    parameters: {
      type: Type.OBJECT,
      properties: {
        alertId: { type: Type.STRING, description: 'Security alert identifier.' },
      },
      required: ['alertId'],
    },
    execute: (args) => {
      const id = String(args.alertId || '').toUpperCase().trim();
      return ALERTS_DB[id] || { found: false, alertId: id, message: 'No matching alert record.' };
    },
  },
};

export function getGeminiFunctionDeclarations(allowedTools: ToolName[]): FunctionDeclaration[] {
  return allowedTools
    .filter((t) => Boolean(SANDBOX_TOOLS[t]))
    .map((t) => {
      const def = SANDBOX_TOOLS[t];
      return {
        name: def.name,
        description: def.description,
        parameters: def.parameters,
      };
    });
}

export function getOpenAITools(allowedTools: ToolName[]) {
  return allowedTools
    .filter((t) => Boolean(SANDBOX_TOOLS[t]))
    .map((t) => {
      const def = SANDBOX_TOOLS[t];
      const properties: Record<string, { type: string; description: string }> = {};
      for (const [k, v] of Object.entries(def.parameters.properties)) {
        properties[k] = {
          type: v.type === Type.NUMBER ? 'number' : 'string',
          description: v.description,
        };
      }
      return {
        type: 'function',
        function: {
          name: def.name,
          description: def.description,
          parameters: {
            type: 'object',
            properties,
            required: def.parameters.required,
          },
        },
      };
    });
}

export function getAnthropicTools(allowedTools: ToolName[]) {
  return allowedTools
    .filter((t) => Boolean(SANDBOX_TOOLS[t]))
    .map((t) => {
      const def = SANDBOX_TOOLS[t];
      const properties: Record<string, { type: string; description: string }> = {};
      for (const [k, v] of Object.entries(def.parameters.properties)) {
        properties[k] = {
          type: v.type === Type.NUMBER ? 'number' : 'string',
          description: v.description,
        };
      }
      return {
        name: def.name,
        description: def.description,
        input_schema: {
          type: 'object',
          properties,
          required: def.parameters.required,
        },
      };
    });
}
