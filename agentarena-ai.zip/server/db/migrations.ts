import type Database from 'better-sqlite3';

export interface Migration {
  version: number;
  name: string;
  up: (db: Database.Database) => void;
}

export const MIGRATIONS: Migration[] = [
  {
    version: 1,
    name: 'initial_agentarena_schema',
    up: (db) => {
      db.exec(`
        CREATE TABLE IF NOT EXISTS users (
          id TEXT PRIMARY KEY,
          email TEXT NOT NULL UNIQUE,
          name TEXT NOT NULL,
          role TEXT NOT NULL DEFAULT 'admin',
          created_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS providers (
          id TEXT PRIMARY KEY,
          name TEXT NOT NULL,
          env_var TEXT NOT NULL,
          supported_models_json TEXT NOT NULL,
          created_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS agent_configurations (
          id TEXT PRIMARY KEY,
          name TEXT NOT NULL,
          provider TEXT NOT NULL REFERENCES providers(id),
          model_id TEXT NOT NULL,
          description TEXT NOT NULL,
          system_prompt TEXT NOT NULL,
          allowed_tools_json TEXT NOT NULL,
          supports_tools INTEGER NOT NULL DEFAULT 1,
          input_cost_per_1m REAL,
          output_cost_per_1m REAL,
          max_steps INTEGER NOT NULL DEFAULT 4,
          is_demo INTEGER NOT NULL DEFAULT 0,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_agents_provider ON agent_configurations(provider);
        CREATE INDEX IF NOT EXISTS idx_agents_demo ON agent_configurations(is_demo);

        CREATE TABLE IF NOT EXISTS benchmark_suites (
          id TEXT PRIMARY KEY,
          name TEXT NOT NULL,
          version TEXT NOT NULL DEFAULT 'v1.0.0',
          category TEXT NOT NULL,
          description TEXT NOT NULL,
          weights_json TEXT NOT NULL,
          reliability_repeats INTEGER NOT NULL DEFAULT 1,
          is_demo INTEGER NOT NULL DEFAULT 0,
          created_by TEXT REFERENCES users(id),
          created_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_suites_category ON benchmark_suites(category);
        CREATE INDEX IF NOT EXISTS idx_suites_demo ON benchmark_suites(is_demo);

        CREATE TABLE IF NOT EXISTS test_cases (
          id TEXT PRIMARY KEY,
          suite_id TEXT NOT NULL REFERENCES benchmark_suites(id) ON DELETE CASCADE,
          code TEXT NOT NULL,
          title TEXT NOT NULL,
          instructions TEXT NOT NULL,
          expected_outcome TEXT NOT NULL,
          evaluation_criteria TEXT NOT NULL,
          difficulty TEXT NOT NULL,
          reference_answer TEXT NOT NULL,
          deterministic_rules_json TEXT NOT NULL,
          approved INTEGER NOT NULL DEFAULT 1,
          order_index INTEGER NOT NULL DEFAULT 0
        );
        CREATE INDEX IF NOT EXISTS idx_test_cases_suite ON test_cases(suite_id);

        CREATE TABLE IF NOT EXISTS benchmark_runs (
          id TEXT PRIMARY KEY,
          suite_id TEXT NOT NULL REFERENCES benchmark_suites(id) ON DELETE CASCADE,
          suite_name TEXT NOT NULL,
          suite_version TEXT NOT NULL,
          category TEXT NOT NULL,
          status TEXT NOT NULL,
          current_stage TEXT NOT NULL,
          progress_percent INTEGER NOT NULL DEFAULT 0,
          completed_tasks INTEGER NOT NULL DEFAULT 0,
          total_tasks INTEGER NOT NULL DEFAULT 0,
          weights_json TEXT NOT NULL,
          selected_agent_ids_json TEXT NOT NULL,
          is_demo INTEGER NOT NULL DEFAULT 0,
          started_at TEXT NOT NULL,
          completed_at TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_runs_suite ON benchmark_runs(suite_id);
        CREATE INDEX IF NOT EXISTS idx_runs_status ON benchmark_runs(status);
        CREATE INDEX IF NOT EXISTS idx_runs_demo ON benchmark_runs(is_demo);

        CREATE TABLE IF NOT EXISTS agent_executions (
          id TEXT PRIMARY KEY,
          run_id TEXT NOT NULL REFERENCES benchmark_runs(id) ON DELETE CASCADE,
          test_case_id TEXT NOT NULL REFERENCES test_cases(id) ON DELETE CASCADE,
          agent_id TEXT NOT NULL REFERENCES agent_configurations(id),
          agent_name TEXT NOT NULL,
          provider TEXT NOT NULL,
          model_id TEXT NOT NULL,
          repeat_index INTEGER NOT NULL DEFAULT 0,
          status TEXT NOT NULL,
          output TEXT NOT NULL,
          error_message TEXT,
          latency_ms INTEGER NOT NULL,
          input_tokens INTEGER,
          output_tokens INTEGER,
          cost_usd REAL,
          started_at TEXT NOT NULL,
          completed_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_exec_run ON agent_executions(run_id);
        CREATE INDEX IF NOT EXISTS idx_exec_agent ON agent_executions(agent_id);
        CREATE INDEX IF NOT EXISTS idx_exec_case ON agent_executions(test_case_id);

        CREATE TABLE IF NOT EXISTS evaluation_results (
          id TEXT PRIMARY KEY,
          execution_id TEXT NOT NULL UNIQUE REFERENCES agent_executions(id) ON DELETE CASCADE,
          run_id TEXT NOT NULL REFERENCES benchmark_runs(id) ON DELETE CASCADE,
          test_case_id TEXT NOT NULL REFERENCES test_cases(id) ON DELETE CASCADE,
          agent_id TEXT NOT NULL,
          accuracy_score REAL NOT NULL,
          task_completed INTEGER NOT NULL,
          tool_efficiency_score REAL,
          deterministic_passed INTEGER NOT NULL,
          deterministic_notes_json TEXT NOT NULL,
          judge_model TEXT NOT NULL,
          judge_reasoning TEXT NOT NULL,
          judge_evidence TEXT NOT NULL,
          judge_limitations TEXT NOT NULL,
          failure_category TEXT NOT NULL,
          improvement_recommendation TEXT NOT NULL,
          evaluated_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_eval_run ON evaluation_results(run_id);
        CREATE INDEX IF NOT EXISTS idx_eval_agent ON evaluation_results(agent_id);

        CREATE TABLE IF NOT EXISTS tool_events (
          id TEXT PRIMARY KEY,
          execution_id TEXT NOT NULL REFERENCES agent_executions(id) ON DELETE CASCADE,
          sequence INTEGER NOT NULL,
          timestamp TEXT NOT NULL,
          event_type TEXT NOT NULL,
          tool_name TEXT,
          input_summary TEXT,
          output_summary TEXT,
          duration_ms INTEGER NOT NULL DEFAULT 0,
          success INTEGER NOT NULL DEFAULT 1
        );
        CREATE INDEX IF NOT EXISTS idx_tool_events_exec ON tool_events(execution_id);

        CREATE TABLE IF NOT EXISTS historical_rankings (
          id TEXT PRIMARY KEY,
          run_id TEXT NOT NULL REFERENCES benchmark_runs(id) ON DELETE CASCADE,
          suite_id TEXT NOT NULL,
          suite_name TEXT NOT NULL,
          suite_version TEXT NOT NULL,
          category TEXT NOT NULL,
          agent_id TEXT NOT NULL,
          agent_name TEXT NOT NULL,
          provider TEXT NOT NULL,
          model_id TEXT NOT NULL,
          rank INTEGER NOT NULL,
          overall_score REAL NOT NULL,
          task_completion_rate REAL NOT NULL,
          accuracy_score REAL NOT NULL,
          reliability_score REAL NOT NULL,
          cost_efficiency_score REAL,
          avg_latency_ms INTEGER NOT NULL,
          avg_cost_per_task_usd REAL,
          test_count INTEGER NOT NULL,
          is_demo INTEGER NOT NULL DEFAULT 0,
          recorded_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_rankings_category ON historical_rankings(category);
        CREATE INDEX IF NOT EXISTS idx_rankings_demo ON historical_rankings(is_demo);

        CREATE TABLE IF NOT EXISTS platform_settings (
          key TEXT PRIMARY KEY,
          value_json TEXT NOT NULL,
          updated_at TEXT NOT NULL
        );
      `);
    },
  },
];

export function runMigrations(db: Database.Database): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS schema_migrations (
      version INTEGER PRIMARY KEY,
      name TEXT NOT NULL,
      applied_at TEXT NOT NULL
    );
  `);

  const applied = new Set<number>(
    (db.prepare('SELECT version FROM schema_migrations').all() as { version: number }[]).map(
      (r) => r.version
    )
  );

  for (const migration of MIGRATIONS) {
    if (!applied.has(migration.version)) {
      const tx = db.transaction(() => {
        migration.up(db);
        db.prepare(
          'INSERT INTO schema_migrations (version, name, applied_at) VALUES (?, ?, ?)'
        ).run(migration.version, migration.name, new Date().toISOString());
      });
      tx();
    }
  }
}
