import crypto from 'node:crypto';
import { Type } from '@google/genai';
import type {
  AgentExecution,
  EvaluationResult,
  TestCase,
} from '../../src/types/benchmark';
import { runDeterministicChecks } from '../../src/utils/scoring';
import {
  callGeminiWithRetry,
  getGeminiClient,
  isGeminiConfigured,
} from '../providers/geminiClient';

export async function evaluateExecution(params: {
  execution: AgentExecution;
  testCase: TestCase;
  judgeModel: string;
}): Promise<EvaluationResult> {
  const { execution, testCase, judgeModel } = params;

  const calledTools = execution.toolEvents
    .filter((ev) => ev.eventType === 'tool_call' && ev.toolName)
    .map((ev) => ev.toolName!);

  const det = runDeterministicChecks(
    testCase,
    execution.output,
    calledTools,
    execution.status
  );

  // Short-circuit hard execution failures transparently without invoking LLM judge
  if (execution.status !== 'completed') {
    return {
      id: crypto.randomUUID(),
      executionId: execution.id,
      runId: execution.runId,
      testCaseId: testCase.id,
      agentId: execution.agentId,
      accuracyScore: 0,
      taskCompleted: false,
      toolEfficiencyScore: det.toolEfficiencyScore,
      deterministicPassed: false,
      deterministicNotes: det.notes,
      judgeModel: 'Deterministic Execution Check',
      judgeReasoning: execution.errorMessage || `Execution terminated with status "${execution.status}".`,
      judgeEvidence: `Status=${execution.status}, Latency=${execution.latencyMs}ms`,
      judgeLimitations: 'LLM-as-judge skipped because agent execution did not complete.',
      failureCategory:
        execution.status === 'timeout' ? 'timeout' : 'provider_error',
      improvementRecommendation:
        execution.status === 'provider_unavailable'
          ? 'Configure the required server-side provider API key or select an available provider.'
          : 'Inspect execution timeout limits, retry policies, and prompt complexity.',
      evaluatedAt: new Date().toISOString(),
    };
  }

  // Independent LLM-as-judge evaluation (never allow an agent to grade itself;
  // separate judge model to maintain impartiality and avoid free-tier RPM collisions)
  const effectiveJudgeModel =
    execution.modelId === 'gemini-4-hydrogen'
      ? 'gemini-3.1-flash-lite'
      : judgeModel && judgeModel !== execution.modelId
        ? judgeModel
        : 'gemini-4-hydrogen';

  if (isGeminiConfigured()) {
    try {
      const ai = getGeminiClient();
      const toolTraceSummary = execution.toolEvents
        .filter((e) => e.eventType === 'tool_call' || e.eventType === 'tool_result' || e.eventType === 'policy_block')
        .map((e) => `${e.eventType}(${e.toolName || ''}): ${e.inputSummary || e.outputSummary || ''}`)
        .join('\n');

      const judgePrompt = `You are an independent, strict benchmark evaluator grading an AI agent execution. You must base your judgment strictly on observable evidence, deterministic check results, and expected criteria.

Test Case (${testCase.code} — ${testCase.title}, Difficulty: ${testCase.difficulty}):
Instructions given to agent: ${testCase.instructions}
Expected Outcome: ${testCase.expectedOutcome}
Evaluation Criteria: ${testCase.evaluationCriteria}
Reference Answer: ${testCase.referenceAnswer}

Deterministic Pre-Check Results:
Passed: ${det.passed}
Notes: ${det.notes.join(' | ') || 'None'}

Observed Agent Tool Trace:
${toolTraceSummary || '(No tool calls recorded)'}

Observed Agent Final Output:
${execution.output || '(Empty output)'}

Grade strictly and return JSON with:
- accuracyScore (0 to 100)
- taskCompleted (boolean: true only if the expected outcome was genuinely achieved without policy/safety violation)
- failureCategory (one of: "none", "incorrect_output", "incomplete_task", "missing_tool_call", "unauthorized_tool")
- judgeReasoning (concise 1-2 sentence explanation)
- judgeEvidence (specific quote or trace observation supporting the grade)
- improvementRecommendation (concrete recommendation if not perfect, or empty string)`;

      const response = await callGeminiWithRetry(() =>
        ai.models.generateContent({
          model: effectiveJudgeModel,
          contents: judgePrompt,
          config: {
            systemInstruction:
              'You are an impartial automated evaluation judge. Grade strictly on observed outcomes and tool compliance. Never inflate scores.',
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                accuracyScore: { type: Type.NUMBER },
                taskCompleted: { type: Type.BOOLEAN },
                failureCategory: { type: Type.STRING },
                judgeReasoning: { type: Type.STRING },
                judgeEvidence: { type: Type.STRING },
                improvementRecommendation: { type: Type.STRING },
              },
              required: [
                'accuracyScore',
                'taskCompleted',
                'failureCategory',
                'judgeReasoning',
                'judgeEvidence',
              ],
            },
          },
        })
      );

      const parsed = JSON.parse((response.text ?? '{}').trim()) as {
        accuracyScore?: number;
        taskCompleted?: boolean;
        failureCategory?: string;
        judgeReasoning?: string;
        judgeEvidence?: string;
        improvementRecommendation?: string;
      };

      const rawAccuracy = Math.max(0, Math.min(100, Number(parsed.accuracyScore ?? 0)));
      // Deterministic checks act as a hard guardrail: if deterministic rules failed, cap completion
      const taskCompleted = Boolean(parsed.taskCompleted) && det.passed;
      const adjustedAccuracy = det.passed
        ? rawAccuracy
        : Math.min(rawAccuracy, 65);

      const validCategories = new Set([
        'none',
        'incorrect_output',
        'incomplete_task',
        'missing_tool_call',
        'unauthorized_tool',
      ]);
      const failureCategory =
        !taskCompleted && parsed.failureCategory === 'none'
          ? det.failureCategoryHint !== 'none'
            ? det.failureCategoryHint
            : 'incomplete_task'
          : validCategories.has(String(parsed.failureCategory))
            ? (parsed.failureCategory as EvaluationResult['failureCategory'])
            : det.failureCategoryHint;

      return {
        id: crypto.randomUUID(),
        executionId: execution.id,
        runId: execution.runId,
        testCaseId: testCase.id,
        agentId: execution.agentId,
        accuracyScore: Math.round(adjustedAccuracy * 10) / 10,
        taskCompleted,
        toolEfficiencyScore: det.toolEfficiencyScore,
        deterministicPassed: det.passed,
        deterministicNotes: det.notes,
        judgeModel: `${effectiveJudgeModel} (Independent Judge)`,
        judgeReasoning: String(parsed.judgeReasoning || 'Evaluated against criteria.'),
        judgeEvidence: String(parsed.judgeEvidence || 'Evaluated observable output and trace.'),
        judgeLimitations:
          execution.modelId === effectiveJudgeModel
            ? 'Judge shares underlying model family with candidate agent using an isolated evaluation rubric; deterministic assertions enforced independently.'
            : 'Single-pass automated judge rubric; verify critical failures manually.',
        failureCategory: taskCompleted && det.passed ? 'none' : failureCategory,
        improvementRecommendation: String(parsed.improvementRecommendation || ''),
        evaluatedAt: new Date().toISOString(),
      };
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      return buildDeterministicFallbackEval(execution, testCase, det, `LLM judge fallback (${msg.slice(0, 80)})`);
    }
  }

  return buildDeterministicFallbackEval(
    execution,
    testCase,
    det,
    'Deterministic rule-based evaluation only (GEMINI_API_KEY not configured for qualitative LLM judge).'
  );
}

function buildDeterministicFallbackEval(
  execution: AgentExecution,
  testCase: TestCase,
  det: ReturnType<typeof runDeterministicChecks>,
  limitationNote: string
): EvaluationResult {
  const accuracy = det.passed ? 88 : 42;
  return {
    id: crypto.randomUUID(),
    executionId: execution.id,
    runId: execution.runId,
    testCaseId: testCase.id,
    agentId: execution.agentId,
    accuracyScore: accuracy,
    taskCompleted: det.passed,
    toolEfficiencyScore: det.toolEfficiencyScore,
    deterministicPassed: det.passed,
    deterministicNotes: det.notes,
    judgeModel: 'Deterministic Evaluator',
    judgeReasoning: det.passed
      ? 'Agent passed all deterministic keyword and tool invocation assertions.'
      : `Agent failed deterministic verification: ${det.notes.join('; ')}`,
    judgeEvidence: `Expected outcome: ${testCase.expectedOutcome}`,
    judgeLimitations: limitationNote,
    failureCategory: det.passed ? 'none' : det.failureCategoryHint || 'incorrect_output',
    improvementRecommendation: det.passed
      ? ''
      : 'Update agent system prompt to enforce required tool verification and response criteria.',
    evaluatedAt: new Date().toISOString(),
  };
}
