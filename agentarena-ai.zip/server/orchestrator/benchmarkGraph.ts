import crypto from 'node:crypto';
import type Database from 'better-sqlite3';
import type {
  AgentConfig,
  AgentExecution,
  BenchmarkCategory,
  BenchmarkSuite,
  EvaluationResult,
  PlatformSettings,
  ScoringWeights,
  TestCase,
} from '../../src/types/benchmark';
import { computeRunSummaries, DEFAULT_WEIGHTS, normalizeWeights } from '../../src/utils/scoring';
import { evaluateExecution } from '../evaluator/judgeEvaluator';
import { executeAgentTask } from '../providers/providerAdapter';

const activeCancellations = new Set<string>();

export function requestRunCancellation(runId: string): void {
  activeCancellations.add(runId);
}

interface OrchestratorJob {
  testCase: TestCase;
  agent: AgentConfig;
  repeatIndex: number;
}

/**
 * LangGraph-inspired deterministic state-graph benchmark orchestrator:
 * initialize -> dispatch_isolated_jobs -> execute_with_retry -> evaluate_hybrid -> aggregate_and_rank -> complete
 */
export async function launchBenchmarkOrchestrator(
  db: Database.Database,
  params: {
    suiteId: string;
    selectedAgentIds: string[];
    weights?: ScoringWeights;
    reliabilityRepeats?: number;
  }
): Promise<string> {
  const suiteRow = db
    .prepare('SELECT * FROM benchmark_suites WHERE id = ?')
    .get(params.suiteId) as Record<string, unknown> | undefined;

  if (!suiteRow) {
    throw new Error('Benchmark suite not found.');
  }

  const testCaseRows = db
    .prepare('SELECT * FROM test_cases WHERE suite_id = ? AND approved = 1 ORDER BY order_index ASC')
    .all(params.suiteId) as Record<string, unknown>[];

  if (testCaseRows.length === 0) {
    throw new Error('Benchmark suite has no approved test cases.');
  }

  const agents: AgentConfig[] = params.selectedAgentIds
    .map((id) => db.prepare('SELECT * FROM agent_configurations WHERE id = ?').get(id) as Record<string, unknown> | undefined)
    .filter((r): r is Record<string, unknown> => Boolean(r))
    .map(mapAgentRow);

  if (agents.length < 2) {
    throw new Error('Select at least 2 configured agents to run a benchmark comparison.');
  }

  const settingsRow = db
    .prepare("SELECT value_json FROM platform_settings WHERE key = 'global'")
    .get() as { value_json: string } | undefined;
  const settings: PlatformSettings = settingsRow
    ? JSON.parse(settingsRow.value_json)
    : {
        defaultWeights: DEFAULT_WEIGHTS,
        executionTimeoutMs: 45000,
        maxRetries: 1,
        concurrencyLimit: 1,
        judgeModel: 'gemini-4-hydrogen',
      };

  const weights = normalizeWeights(
    params.weights || JSON.parse(String(suiteRow.weights_json || JSON.stringify(DEFAULT_WEIGHTS)))
  );
  const repeats = Math.max(
    1,
    Math.min(3, Number(params.reliabilityRepeats ?? suiteRow.reliability_repeats ?? 1))
  );

  const testCases: TestCase[] = testCaseRows.map(mapTestCaseRow);
  const totalTasks = testCases.length * agents.length * repeats;
  const runId = `run-${crypto.randomUUID().slice(0, 8)}`;
  const startedAt = new Date().toISOString();

  db.prepare(`
    INSERT INTO benchmark_runs (
      id, suite_id, suite_name, suite_version, category, status, current_stage,
      progress_percent, completed_tasks, total_tasks, weights_json,
      selected_agent_ids_json, is_demo, started_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    runId,
    String(suiteRow.id),
    String(suiteRow.name),
    String(suiteRow.version),
    String(suiteRow.category),
    'running',
    'Graph node: dispatch_isolated_jobs',
    0,
    0,
    totalTasks,
    JSON.stringify(weights),
    JSON.stringify(agents.map((a) => a.id)),
    0,
    startedAt
  );

  // Execute asynchronously so UI can poll live graph progress
  void executeRunGraph(db, {
    runId,
    suite: {
      id: String(suiteRow.id),
      name: String(suiteRow.name),
      version: String(suiteRow.version),
      category: String(suiteRow.category) as BenchmarkCategory,
      description: String(suiteRow.description),
      weights,
      reliabilityRepeats: repeats,
      isDemo: false,
      createdAt: String(suiteRow.created_at),
    },
    testCases,
    agents,
    repeats,
    settings,
  });

  return runId;
}

async function executeRunGraph(
  db: Database.Database,
  ctx: {
    runId: string;
    suite: BenchmarkSuite;
    testCases: TestCase[];
    agents: AgentConfig[];
    repeats: number;
    settings: PlatformSettings;
  }
): Promise<void> {
  const { runId, suite, testCases, agents, repeats, settings } = ctx;
  const jobs: OrchestratorJob[] = [];

  for (const tc of testCases) {
    for (let r = 0; r < repeats; r++) {
      for (const agent of agents) {
        jobs.push({ testCase: tc, agent, repeatIndex: r });
      }
    }
  }

  const updateProgress = db.prepare(`
    UPDATE benchmark_runs
    SET current_stage = ?, progress_percent = ?, completed_tasks = ?
    WHERE id = ?
  `);

  const insertExec = db.prepare(`
    INSERT INTO agent_executions (
      id, run_id, test_case_id, agent_id, agent_name, provider, model_id,
      repeat_index, status, output, error_message, latency_ms, input_tokens,
      output_tokens, cost_usd, started_at, completed_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const insertToolEvent = db.prepare(`
    INSERT INTO tool_events (
      id, execution_id, sequence, timestamp, event_type, tool_name,
      input_summary, output_summary, duration_ms, success
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const insertEval = db.prepare(`
    INSERT INTO evaluation_results (
      id, execution_id, run_id, test_case_id, agent_id, accuracy_score,
      task_completed, tool_efficiency_score, deterministic_passed,
      deterministic_notes_json, judge_model, judge_reasoning, judge_evidence,
      judge_limitations, failure_category, improvement_recommendation, evaluated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const executions: AgentExecution[] = [];
  const evaluations: EvaluationResult[] = [];
  let completed = 0;
  let nextIndex = 0;

  const concurrency = Math.max(1, Math.min(5, settings.concurrencyLimit || 3));

  async function worker(): Promise<void> {
    while (nextIndex < jobs.length) {
      if (activeCancellations.has(runId)) return;

      const idx = nextIndex++;
      const job = jobs[idx];

      updateProgress.run(
        `Executing ${job.testCase.code} on ${job.agent.name}`,
        Math.round((completed / Math.max(1, jobs.length)) * 90),
        completed,
        runId
      );

      let execution: AgentExecution | null = null;
      const maxAttempts = 1 + Math.max(0, Math.min(2, settings.maxRetries));

      for (let attempt = 0; attempt < maxAttempts; attempt++) {
        execution = await executeAgentTask({
          runId,
          agent: job.agent,
          testCase: job.testCase,
          repeatIndex: job.repeatIndex,
          timeoutMs: settings.executionTimeoutMs || 25000,
        });
        if (execution.status === 'completed' || execution.status === 'provider_unavailable') {
          break;
        }
      }

      if (!execution) continue;

      const evaluation = await evaluateExecution({
        execution,
        testCase: job.testCase,
        judgeModel: settings.judgeModel,
      });

      const persistTx = db.transaction(() => {
        insertExec.run(
          execution!.id,
          execution!.runId,
          execution!.testCaseId,
          execution!.agentId,
          execution!.agentName,
          execution!.provider,
          execution!.modelId,
          execution!.repeatIndex,
          execution!.status,
          execution!.output,
          execution!.errorMessage || null,
          execution!.latencyMs,
          execution!.inputTokens,
          execution!.outputTokens,
          execution!.costUsd,
          execution!.startedAt,
          execution!.completedAt
        );

        for (const ev of execution!.toolEvents) {
          insertToolEvent.run(
            ev.id,
            ev.executionId,
            ev.sequence,
            ev.timestamp,
            ev.eventType,
            ev.toolName || null,
            ev.inputSummary || null,
            ev.outputSummary || null,
            ev.durationMs,
            ev.success ? 1 : 0
          );
        }

        insertEval.run(
          evaluation.id,
          evaluation.executionId,
          evaluation.runId,
          evaluation.testCaseId,
          evaluation.agentId,
          evaluation.accuracyScore,
          evaluation.taskCompleted ? 1 : 0,
          evaluation.toolEfficiencyScore,
          evaluation.deterministicPassed ? 1 : 0,
          JSON.stringify(evaluation.deterministicNotes),
          evaluation.judgeModel,
          evaluation.judgeReasoning,
          evaluation.judgeEvidence,
          evaluation.judgeLimitations,
          evaluation.failureCategory,
          evaluation.improvementRecommendation,
          evaluation.evaluatedAt
        );
      });
      persistTx();

      executions.push(execution);
      evaluations.push(evaluation);
      completed++;

      updateProgress.run(
        `Evaluated ${job.testCase.code} (${completed}/${jobs.length})`,
        Math.round((completed / Math.max(1, jobs.length)) * 95),
        completed,
        runId
      );
    }
  }

  try {
    await Promise.all(Array.from({ length: concurrency }, () => worker()));

    if (activeCancellations.has(runId)) {
      activeCancellations.delete(runId);
      db.prepare(`
        UPDATE benchmark_runs
        SET status = 'cancelled', current_stage = 'Cancelled by user', completed_at = ?
        WHERE id = ?
      `).run(new Date().toISOString(), runId);
      return;
    }

    updateProgress.run('Graph node: aggregate_and_rank', 98, completed, runId);

    const summaries = computeRunSummaries(executions, evaluations, suite.weights);
    const completedAt = new Date().toISOString();

    const insertRank = db.prepare(`
      INSERT INTO historical_rankings (
        id, run_id, suite_id, suite_name, suite_version, category, agent_id, agent_name,
        provider, model_id, rank, overall_score, task_completion_rate, accuracy_score,
        reliability_score, cost_efficiency_score, avg_latency_ms, avg_cost_per_task_usd,
        test_count, is_demo, recorded_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    const finalizeTx = db.transaction(() => {
      for (const s of summaries) {
        insertRank.run(
          crypto.randomUUID(),
          runId,
          suite.id,
          suite.name,
          suite.version,
          suite.category,
          s.agentId,
          s.agentName,
          s.provider,
          s.modelId,
          s.rank,
          s.overallScore,
          s.taskCompletionRate,
          s.accuracyScore,
          s.reliabilityScore,
          s.costEfficiencyScore,
          s.avgLatencyMs,
          s.avgCostPerTaskUsd,
          testCases.length,
          0,
          completedAt
        );
      }

      db.prepare(`
        UPDATE benchmark_runs
        SET status = 'completed', current_stage = 'Completed', progress_percent = 100,
            completed_tasks = ?, completed_at = ?
        WHERE id = ?
      `).run(completed, completedAt, runId);
    });

    finalizeTx();
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    db.prepare(`
      UPDATE benchmark_runs
      SET status = 'failed', current_stage = ?, completed_at = ?
      WHERE id = ?
    `).run(`Orchestrator error: ${msg.slice(0, 140)}`, new Date().toISOString(), runId);
  }
}

export function mapAgentRow(row: Record<string, unknown>): AgentConfig {
  return {
    id: String(row.id),
    name: String(row.name),
    provider: String(row.provider) as AgentConfig['provider'],
    modelId: String(row.model_id),
    description: String(row.description),
    systemPrompt: String(row.system_prompt),
    allowedTools: JSON.parse(String(row.allowed_tools_json || '[]')),
    supportsTools: Boolean(row.supports_tools),
    inputCostPer1M: row.input_cost_per_1m === null ? null : Number(row.input_cost_per_1m),
    outputCostPer1M: row.output_cost_per_1m === null ? null : Number(row.output_cost_per_1m),
    maxSteps: Number(row.max_steps || 4),
    isDemo: Boolean(row.is_demo),
    createdAt: String(row.created_at),
    updatedAt: String(row.updated_at),
  };
}

export function mapTestCaseRow(row: Record<string, unknown>): TestCase {
  return {
    id: String(row.id),
    suiteId: String(row.suite_id),
    code: String(row.code),
    title: String(row.title),
    instructions: String(row.instructions),
    expectedOutcome: String(row.expected_outcome),
    evaluationCriteria: String(row.evaluation_criteria),
    difficulty: String(row.difficulty) as TestCase['difficulty'],
    referenceAnswer: String(row.reference_answer),
    deterministicRules: JSON.parse(String(row.deterministic_rules_json || '{}')),
    approved: Boolean(row.approved),
    orderIndex: Number(row.order_index || 0),
  };
}
