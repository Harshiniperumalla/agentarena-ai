import crypto from 'node:crypto';
import type { Content } from '@google/genai';
import type {
  AgentConfig,
  AgentExecution,
  ProviderId,
  TestCase,
  ToolEvent,
} from '../../src/types/benchmark';
import { calculateExecutionCost } from '../../src/utils/scoring';
import {
  getAnthropicTools,
  getGeminiFunctionDeclarations,
  getOpenAITools,
  SANDBOX_TOOLS,
} from '../tools/sandboxTools';
import {
  callGeminiWithRetry,
  getGeminiClient,
  isGeminiConfigured,
} from './geminiClient';

function formatProviderError(err: unknown): string {
  const raw = err instanceof Error ? err.message : String(err);
  if (raw.includes('RESOURCE_EXHAUSTED') || raw.includes('"code":429')) {
    return 'Rate limit exceeded (429): Free-tier request quota reached. Reduce concurrency or retry shortly.';
  }
  if (raw.includes('PERMISSION_DENIED') || raw.includes('API_KEY_INVALID')) {
    return 'Provider authentication error: Verify server-side API key configuration.';
  }
  return raw.length > 260 ? `${raw.slice(0, 260)}...` : raw;
}

export function isProviderConfigured(provider: ProviderId): boolean {
  if (provider === 'gemini') return isGeminiConfigured();
  if (provider === 'openai') {
    const k = process.env.OPENAI_API_KEY;
    return Boolean(k && k.trim().length > 5);
  }
  if (provider === 'anthropic') {
    const k = process.env.ANTHROPIC_API_KEY;
    return Boolean(k && k.trim().length > 5);
  }
  return false;
}

function withTimeout<T>(promise: Promise<T>, timeoutMs: number, label: string): Promise<T> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      reject(new Error(`TIMEOUT: ${label} exceeded ${timeoutMs}ms limit.`));
    }, timeoutMs);
    promise
      .then((val) => {
        clearTimeout(timer);
        resolve(val);
      })
      .catch((err) => {
        clearTimeout(timer);
        reject(err);
      });
  });
}

function invokeSandboxedTool(
  agent: AgentConfig,
  executionId: string,
  sequenceRef: { seq: number },
  toolName: string,
  args: Record<string, unknown>,
  events: ToolEvent[]
): { result: Record<string, unknown>; allowed: boolean } {
  const callTs = new Date().toISOString();
  events.push({
    id: crypto.randomUUID(),
    executionId,
    sequence: sequenceRef.seq++,
    timestamp: callTs,
    eventType: 'tool_call',
    toolName,
    inputSummary: JSON.stringify(args).slice(0, 240),
    durationMs: 0,
    success: true,
  });

  const start = Date.now();
  const isAllowed = agent.allowedTools.includes(toolName as AgentConfig['allowedTools'][number]);
  const def = SANDBOX_TOOLS[toolName as keyof typeof SANDBOX_TOOLS];

  if (!isAllowed || !def) {
    const blocked = {
      error: `Permission denied: tool "${toolName}" is not approved for agent "${agent.name}".`,
    };
    events.push({
      id: crypto.randomUUID(),
      executionId,
      sequence: sequenceRef.seq++,
      timestamp: new Date().toISOString(),
      eventType: 'policy_block',
      toolName,
      outputSummary: blocked.error,
      durationMs: Date.now() - start,
      success: false,
    });
    return { result: blocked, allowed: false };
  }

  const output = def.execute(args);
  events.push({
    id: crypto.randomUUID(),
    executionId,
    sequence: sequenceRef.seq++,
    timestamp: new Date().toISOString(),
    eventType: 'tool_result',
    toolName,
    outputSummary: JSON.stringify(output).slice(0, 280),
    durationMs: Math.max(12, Date.now() - start),
    success: true,
  });

  return { result: output, allowed: true };
}

export async function executeAgentTask(params: {
  runId: string;
  agent: AgentConfig;
  testCase: TestCase;
  repeatIndex: number;
  timeoutMs: number;
}): Promise<AgentExecution> {
  const { runId, agent, testCase, repeatIndex, timeoutMs } = params;
  const executionId = crypto.randomUUID();
  const startedAt = new Date().toISOString();
  const startMs = Date.now();
  const events: ToolEvent[] = [];
  const seqRef = { seq: 0 };

  events.push({
    id: crypto.randomUUID(),
    executionId,
    sequence: seqRef.seq++,
    timestamp: startedAt,
    eventType: 'step',
    inputSummary: `Isolated task dispatch: ${testCase.code} (${testCase.difficulty})`,
    outputSummary: `Model: ${agent.modelId} · Tools enabled: ${agent.supportsTools ? agent.allowedTools.length : 0}`,
    durationMs: 0,
    success: true,
  });

  if (!isProviderConfigured(agent.provider)) {
    const completedAt = new Date().toISOString();
    const envVar =
      agent.provider === 'gemini'
        ? 'GEMINI_API_KEY'
        : agent.provider === 'openai'
          ? 'OPENAI_API_KEY'
          : 'ANTHROPIC_API_KEY';
    const msg = `Provider "${agent.provider}" is not configured (${envVar} missing in server environment).`;
    events.push({
      id: crypto.randomUUID(),
      executionId,
      sequence: seqRef.seq++,
      timestamp: completedAt,
      eventType: 'error',
      outputSummary: msg,
      durationMs: Date.now() - startMs,
      success: false,
    });
    return {
      id: executionId,
      runId,
      testCaseId: testCase.id,
      agentId: agent.id,
      agentName: agent.name,
      provider: agent.provider,
      modelId: agent.modelId,
      repeatIndex,
      status: 'provider_unavailable',
      output: '',
      errorMessage: msg,
      latencyMs: Date.now() - startMs,
      inputTokens: null,
      outputTokens: null,
      costUsd: null,
      startedAt,
      completedAt,
      toolEvents: events,
    };
  }

  try {
    let result: {
      output: string;
      inputTokens: number | null;
      outputTokens: number | null;
    };

    if (agent.provider === 'gemini') {
      result = await withTimeout(
        runGeminiAgent(agent, testCase, executionId, seqRef, events),
        timeoutMs,
        `${agent.name} / ${testCase.code}`
      );
    } else if (agent.provider === 'openai') {
      result = await withTimeout(
        runOpenAIAgent(agent, testCase, executionId, seqRef, events),
        timeoutMs,
        `${agent.name} / ${testCase.code}`
      );
    } else {
      result = await withTimeout(
        runAnthropicAgent(agent, testCase, executionId, seqRef, events),
        timeoutMs,
        `${agent.name} / ${testCase.code}`
      );
    }

    const completedAt = new Date().toISOString();
    const latencyMs = Date.now() - startMs;
    const costUsd = calculateExecutionCost(
      result.inputTokens,
      result.outputTokens,
      agent.inputCostPer1M,
      agent.outputCostPer1M
    );

    events.push({
      id: crypto.randomUUID(),
      executionId,
      sequence: seqRef.seq++,
      timestamp: completedAt,
      eventType: 'final_output',
      outputSummary: result.output.slice(0, 260),
      durationMs: 0,
      success: true,
    });

    return {
      id: executionId,
      runId,
      testCaseId: testCase.id,
      agentId: agent.id,
      agentName: agent.name,
      provider: agent.provider,
      modelId: agent.modelId,
      repeatIndex,
      status: 'completed',
      output: result.output,
      latencyMs,
      inputTokens: result.inputTokens,
      outputTokens: result.outputTokens,
      costUsd,
      startedAt,
      completedAt,
      toolEvents: events,
    };
  } catch (err) {
    const completedAt = new Date().toISOString();
    const message = formatProviderError(err);
    const isTimeout = message.startsWith('TIMEOUT:');

    events.push({
      id: crypto.randomUUID(),
      executionId,
      sequence: seqRef.seq++,
      timestamp: completedAt,
      eventType: 'error',
      outputSummary: message,
      durationMs: Date.now() - startMs,
      success: false,
    });

    return {
      id: executionId,
      runId,
      testCaseId: testCase.id,
      agentId: agent.id,
      agentName: agent.name,
      provider: agent.provider,
      modelId: agent.modelId,
      repeatIndex,
      status: isTimeout ? 'timeout' : 'failed',
      output: '',
      errorMessage: message,
      latencyMs: Date.now() - startMs,
      inputTokens: null,
      outputTokens: null,
      costUsd: null,
      startedAt,
      completedAt,
      toolEvents: events,
    };
  }
}

async function runGeminiAgent(
  agent: AgentConfig,
  testCase: TestCase,
  executionId: string,
  seqRef: { seq: number },
  events: ToolEvent[]
): Promise<{ output: string; inputTokens: number | null; outputTokens: number | null }> {
  const ai = getGeminiClient();
  const declarations =
    agent.supportsTools && agent.allowedTools.length > 0
      ? getGeminiFunctionDeclarations(agent.allowedTools)
      : [];

  const contents: Content[] = [
    {
      role: 'user',
      parts: [
        {
          text: `Task (${testCase.code} — ${testCase.title}):\n${testCase.instructions}\n\nRespond clearly with the verified resolution and cite exact IDs or policy details.`,
        },
      ],
    },
  ];

  let totalInput = 0;
  let totalOutput = 0;
  let hasUsage = false;
  let finalOutput = '';

  const maxTurns = Math.max(1, Math.min(5, agent.maxSteps || 4));
  for (let step = 0; step < maxTurns; step++) {
    const response = await callGeminiWithRetry(() =>
      ai.models.generateContent({
        model: agent.modelId,
        contents,
        config: {
          systemInstruction: agent.systemPrompt,
          tools: declarations.length > 0 ? [{ functionDeclarations: declarations }] : undefined,
        },
      })
    );

    if (response.usageMetadata) {
      hasUsage = true;
      totalInput += response.usageMetadata.promptTokenCount ?? 0;
      totalOutput += response.usageMetadata.candidatesTokenCount ?? 0;
    }

    const candidateContent = response.candidates?.[0]?.content;
    if (candidateContent) {
      contents.push(candidateContent);
    }

    const calls = response.functionCalls;
    if (calls && calls.length > 0 && step < maxTurns - 1) {
      const responseParts = calls.map((call) => {
        const { result } = invokeSandboxedTool(
          agent,
          executionId,
          seqRef,
          call.name || 'unknown',
          (call.args as Record<string, unknown>) || {},
          events
        );
        return {
          functionResponse: {
            id: call.id,
            name: call.name,
            response: result,
          },
        };
      });
      contents.push({ role: 'user', parts: responseParts });
      continue;
    }

    finalOutput = (response.text ?? '').trim();
    break;
  }

  return {
    output: finalOutput,
    inputTokens: hasUsage ? totalInput : null,
    outputTokens: hasUsage ? totalOutput : null,
  };
}

async function runOpenAIAgent(
  agent: AgentConfig,
  testCase: TestCase,
  executionId: string,
  seqRef: { seq: number },
  events: ToolEvent[]
): Promise<{ output: string; inputTokens: number | null; outputTokens: number | null }> {
  const apiKey = process.env.OPENAI_API_KEY!;
  const tools =
    agent.supportsTools && agent.allowedTools.length > 0
      ? getOpenAITools(agent.allowedTools)
      : undefined;

  const messages: Array<Record<string, unknown>> = [
    { role: 'system', content: agent.systemPrompt },
    {
      role: 'user',
      content: `Task (${testCase.code} — ${testCase.title}):\n${testCase.instructions}`,
    },
  ];

  let totalInput = 0;
  let totalOutput = 0;
  let hasUsage = false;
  let finalOutput = '';

  const maxTurns = Math.max(1, Math.min(5, agent.maxSteps || 4));
  for (let step = 0; step < maxTurns; step++) {
    const res = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: agent.modelId,
        messages,
        tools,
      }),
    });

    if (!res.ok) {
      const body = await res.text();
      throw new Error(`OpenAI API error (${res.status}): ${body.slice(0, 200)}`);
    }

    const data = (await res.json()) as {
      usage?: { prompt_tokens?: number; completion_tokens?: number };
      choices?: Array<{
        message?: {
          content?: string | null;
          tool_calls?: Array<{
            id: string;
            function: { name: string; arguments: string };
          }>;
        };
      }>;
    };

    if (data.usage) {
      hasUsage = true;
      totalInput += data.usage.prompt_tokens ?? 0;
      totalOutput += data.usage.completion_tokens ?? 0;
    }

    const msg = data.choices?.[0]?.message;
    if (!msg) break;

    if (msg.tool_calls && msg.tool_calls.length > 0 && step < maxTurns - 1) {
      messages.push({
        role: 'assistant',
        content: msg.content || '',
        tool_calls: msg.tool_calls,
      });

      for (const tc of msg.tool_calls) {
        let parsedArgs: Record<string, unknown> = {};
        try {
          parsedArgs = JSON.parse(tc.function.arguments || '{}');
        } catch {
          parsedArgs = {};
        }
        const { result } = invokeSandboxedTool(
          agent,
          executionId,
          seqRef,
          tc.function.name,
          parsedArgs,
          events
        );
        messages.push({
          role: 'tool',
          tool_call_id: tc.id,
          content: JSON.stringify(result),
        });
      }
      continue;
    }

    finalOutput = (msg.content ?? '').trim();
    break;
  }

  return {
    output: finalOutput,
    inputTokens: hasUsage ? totalInput : null,
    outputTokens: hasUsage ? totalOutput : null,
  };
}

async function runAnthropicAgent(
  agent: AgentConfig,
  testCase: TestCase,
  executionId: string,
  seqRef: { seq: number },
  events: ToolEvent[]
): Promise<{ output: string; inputTokens: number | null; outputTokens: number | null }> {
  const apiKey = process.env.ANTHROPIC_API_KEY!;
  const tools =
    agent.supportsTools && agent.allowedTools.length > 0
      ? getAnthropicTools(agent.allowedTools)
      : undefined;

  const messages: Array<Record<string, unknown>> = [
    {
      role: 'user',
      content: `Task (${testCase.code} — ${testCase.title}):\n${testCase.instructions}`,
    },
  ];

  let totalInput = 0;
  let totalOutput = 0;
  let hasUsage = false;
  let finalOutput = '';

  const maxTurns = Math.max(1, Math.min(5, agent.maxSteps || 4));
  for (let step = 0; step < maxTurns; step++) {
    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: agent.modelId,
        max_tokens: 1024,
        system: agent.systemPrompt,
        messages,
        tools,
      }),
    });

    if (!res.ok) {
      const body = await res.text();
      throw new Error(`Anthropic API error (${res.status}): ${body.slice(0, 200)}`);
    }

    const data = (await res.json()) as {
      usage?: { input_tokens?: number; output_tokens?: number };
      content?: Array<{
        type: 'text' | 'tool_use';
        text?: string;
        id?: string;
        name?: string;
        input?: Record<string, unknown>;
      }>;
    };

    if (data.usage) {
      hasUsage = true;
      totalInput += data.usage.input_tokens ?? 0;
      totalOutput += data.usage.output_tokens ?? 0;
    }

    const blocks = data.content || [];
    const toolUses = blocks.filter((b) => b.type === 'tool_use');

    if (toolUses.length > 0 && step < maxTurns - 1) {
      messages.push({ role: 'assistant', content: blocks });
      const toolResults = toolUses.map((tu) => {
        const { result } = invokeSandboxedTool(
          agent,
          executionId,
          seqRef,
          tu.name || 'unknown',
          tu.input || {},
          events
        );
        return {
          type: 'tool_result',
          tool_use_id: tu.id,
          content: JSON.stringify(result),
        };
      });
      messages.push({ role: 'user', content: toolResults });
      continue;
    }

    finalOutput = blocks
      .filter((b) => b.type === 'text')
      .map((b) => b.text || '')
      .join('\n')
      .trim();
    break;
  }

  return {
    output: finalOutput,
    inputTokens: hasUsage ? totalInput : null,
    outputTokens: hasUsage ? totalOutput : null,
  };
}
