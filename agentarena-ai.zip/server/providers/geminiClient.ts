import { GoogleGenAI } from '@google/genai';

let cachedClient: GoogleGenAI | null = null;

export function isGeminiConfigured(): boolean {
  const key = process.env.GEMINI_API_KEY;
  return Boolean(key && key.trim() && key !== 'MY_GEMINI_API_KEY');
}

export function getGeminiClient(): GoogleGenAI {
  if (!isGeminiConfigured()) {
    throw new Error('GEMINI_API_KEY is not configured in the server environment.');
  }
  if (!cachedClient) {
    cachedClient = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return cachedClient;
}

export async function callGeminiWithRetry<T>(
  fn: () => Promise<T>,
  maxRetries = 2
): Promise<T> {
  let lastError: unknown;
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      return await fn();
    } catch (err) {
      lastError = err;
      const msg = err instanceof Error ? err.message : String(err);
      const isRateLimit =
        msg.includes('429') || msg.includes('RESOURCE_EXHAUSTED');
      if (!isRateLimit || attempt === maxRetries) {
        throw err;
      }
      // Parse suggested retryDelay if short (<= 15s), otherwise use bounded backoff
      let delayMs = 3500 * Math.pow(2, attempt);
      const match = msg.match(/"retryDelay":"(\d+)s"/);
      if (match) {
        const parsedSec = Number(match[1]);
        if (parsedSec > 0 && parsedSec <= 15) {
          delayMs = parsedSec * 1000 + 500;
        }
      }
      await new Promise((resolve) => setTimeout(resolve, delayMs));
    }
  }
  throw lastError;
}
