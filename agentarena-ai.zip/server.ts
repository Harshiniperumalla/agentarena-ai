import 'dotenv/config';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import express, { type Request, type Response } from 'express';
import { createServer as createViteServer } from 'vite';
import { getDb } from './server/db/database';
import { generateStandardizedTasks } from './server/generator/taskGenerator';
import {
  launchBenchmarkOrchestrator,
  mapAgentRow,
  mapTestCaseRow,
  requestRunCancellation,
} from './server/orchestrator/benchmarkGraph';
import { isProviderConfigured } from './server/providers/providerAdapter';
import type {
  AgentExecution,
  BenchmarkCategory,
  BenchmarkRun,
  DataMode,
  EvaluationResult,
  HistoricalRanking,
  PlatformSettings,
  ProviderId,
  ProviderInfo,
  ScoringWeights,
  ToolEvent,
} from './src/types/benchmark';
import { computeRunSummaries, DEFAULT_WEIGHTS, normalizeWeights } from './src/utils/scoring';

const PORT = Number(process.env.APP_PORT || 3000);

function mapExecutionRows(
  db: ReturnType<typeof getDb>,
  runId: string
): AgentExecution[] {
  const execRows = db
    .prepare('SELECT * FROM agent_executions WHERE run_id = ? ORDER BY started_at ASC')
    .all(runId) as Record<string, unknown>[];

  const toolRows = db
    .prepare(
      `SELECT te.* FROM tool_events te
       INNER JOIN agent_executions ae ON ae.id = te.execution_id
       WHERE ae.run_id = ?
       ORDER BY te.sequence ASC`
    )
    .all(runId) as Record<string, unknown>[];

  const eventsByExec = new Map<string, ToolEvent[]>();
  for (const r of toolRows) {
    const execId = String(r.execution_id);
    const list = eventsByExec.get(execId) || [];
    list.push({
      id: String(r.id),
      executionId: execId,
      sequence: Number(r.sequence),
      timestamp: String(r.timestamp),
      eventType: String(r.event_type) as ToolEvent['eventType'],
      toolName: r.tool_name ? String(r.tool_name) : undefined,
      inputSummary: r.input_summary ? String(r.input_summary) : undefined,
      outputSummary: r.output_summary ? String(r.output_summary) : undefined,
      durationMs: Number(r.duration_ms || 0),
      success: Boolean(r.success),
    });
    eventsByExec.set(execId, list);
  }

  return execRows.map((r) => ({
    id: String(r.id),
    runId: String(r.run_id),
    testCaseId: String(r.test_case_id),
    agentId: String(r.agent_id),
    agentName: String(r.agent_name),
    provider: String(r.provider) as ProviderId,
    modelId: String(r.model_id),
    repeatIndex: Number(r.repeat_index || 0),
    status: String(r.status) as AgentExecution['status'],
    output: String(r.output || ''),
    errorMessage: r.error_message ? String(r.error_message) : undefined,
    latencyMs: Number(r.latency_ms || 0),
    inputTokens: r.input_tokens === null ? null : Number(r.input_tokens),
    outputTokens: r.output_tokens === null ? null : Number(r.output_tokens),
    costUsd: r.cost_usd === null ? null : Number(r.cost_usd),
    startedAt: String(r.started_at),
    completedAt: String(r.completed_at),
    toolEvents: eventsByExec.get(String(r.id)) || [],
  }));
}

function mapEvaluationRows(
  db: ReturnType<typeof getDb>,
  runId: string
): EvaluationResult[] {
  const rows = db
    .prepare('SELECT * FROM evaluation_results WHERE run_id = ?')
    .all(runId) as Record<string, unknown>[];
  return rows.map((r) => ({
    id: String(r.id),
    executionId: String(r.execution_id),
    runId: String(r.run_id),
    testCaseId: String(r.test_case_id),
    agentId: String(r.agent_id),
    accuracyScore: Number(r.accuracy_score),
    taskCompleted: Boolean(r.task_completed),
    toolEfficiencyScore:
      r.tool_efficiency_score === null ? null : Number(r.tool_efficiency_score),
    deterministicPassed: Boolean(r.deterministic_passed),
    deterministicNotes: JSON.parse(String(r.deterministic_notes_json || '[]')),
    judgeModel: String(r.judge_model),
    judgeReasoning: String(r.judge_reasoning),
    judgeEvidence: String(r.judge_evidence),
    judgeLimitations: String(r.judge_limitations),
    failureCategory: String(r.failure_category) as EvaluationResult['failureCategory'],
    improvementRecommendation: String(r.improvement_recommendation || ''),
    evaluatedAt: String(r.evaluated_at),
  }));
}

function hydrateRun(db: ReturnType<typeof getDb>, row: Record<string, unknown>, full = false): BenchmarkRun {
  const runId = String(row.id);
  const weights: ScoringWeights = JSON.parse(
    String(row.weights_json || JSON.stringify(DEFAULT_WEIGHTS))
  );
  const executions = mapExecutionRows(db, runId);
  const evaluations = mapEvaluationRows(db, runId);
  const summaries = computeRunSummaries(executions, evaluations, weights);

  const base: BenchmarkRun = {
    id: runId,
    suiteId: String(row.suite_id),
    suiteName: String(row.suite_name),
    suiteVersion: String(row.suite_version),
    category: String(row.category) as BenchmarkCategory,
    status: String(row.status) as BenchmarkRun['status'],
    currentStage: String(row.current_stage),
    progressPercent: Number(row.progress_percent || 0),
    completedTasks: Number(row.completed_tasks || 0),
    totalTasks: Number(row.total_tasks || 0),
    weights,
    selectedAgentIds: JSON.parse(String(row.selected_agent_ids_json || '[]')),
    isDemo: Boolean(row.is_demo),
    startedAt: String(row.started_at),
    completedAt: row.completed_at ? String(row.completed_at) : undefined,
    summaries,
  };

  if (full) {
    const tcRows = db
      .prepare('SELECT * FROM test_cases WHERE suite_id = ? ORDER BY order_index ASC')
      .all(base.suiteId) as Record<string, unknown>[];
    base.executions = executions;
    base.evaluations = evaluations;
    base.testCases = tcRows.map(mapTestCaseRow);
  }

  return base;
}

async function startServer() {
  const db = getDb();
  const app = express();

  app.use(express.json({ limit: '2mb' }));

  // Basic security headers
  app.use((_req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'SAMEORIGIN');
    next();
  });

  // Health & provider configuration status (never exposes keys)
  app.get('/api/health', (_req: Request, res: Response) => {
    const rows = db.prepare('SELECT * FROM providers ORDER BY id ASC').all() as Record<
      string,
      unknown
    >[];
    const providers: ProviderInfo[] = rows.map((r) => {
      const id = String(r.id) as ProviderId;
      return {
        id,
        name: String(r.name),
        envVar: String(r.env_var),
        configured: isProviderConfigured(id),
        supportedModels: JSON.parse(String(r.supported_models_json || '[]')),
      };
    });
    res.json({ ok: true, providers });
  });

  // Dashboard Overview (strictly separates live vs demo data)
  app.get('/api/dashboard', (req: Request, res: Response) => {
    const mode: DataMode = req.query.mode === 'demo' ? 'demo' : 'live';
    const isDemoFlag = mode === 'demo' ? 1 : 0;

    const runRows = db
      .prepare('SELECT * FROM benchmark_runs WHERE is_demo = ? ORDER BY started_at DESC LIMIT 20')
      .all(isDemoFlag) as Record<string, unknown>[];

    const runs = runRows.map((r) => hydrateRun(db, r, false));
    const allSummaries = runs.flatMap((r) => r.summaries || []);

    const agentMap = new Map<string, typeof allSummaries>();
    for (const s of allSummaries) {
      const arr = agentMap.get(s.agentId) || [];
      arr.push(s);
      agentMap.set(s.agentId, arr);
    }

    const totalRuns = runs.length;
    const agentsTested = agentMap.size;

    const avgTaskCompletionRate =
      allSummaries.length > 0
        ? Math.round(
            (allSummaries.reduce((a, b) => a + b.taskCompletionRate, 0) / allSummaries.length) *
              10
          ) / 10
        : 0;

    const avgLatencyMs =
      allSummaries.length > 0
        ? Math.round(
            allSummaries.reduce((a, b) => a + b.avgLatencyMs, 0) / allSummaries.length
          )
        : 0;

    const costValues = allSummaries
      .map((s) => s.totalCostUsd)
      .filter((c): c is number => c !== null);
    const totalCostUsd =
      costValues.length > 0
        ? Math.round(costValues.reduce((a, b) => a + b, 0) * 100000) / 100000
        : null;

    const latestCompleted = runs.find((r) => r.status === 'completed') || runs[0];
    const topAgents = latestCompleted?.summaries || [];

    res.json({
      mode,
      totalRuns,
      agentsTested,
      avgTaskCompletionRate,
      avgLatencyMs,
      totalCostUsd,
      recentRuns: runs,
      topAgents,
    });
  });

  // Agents CRUD
  app.get('/api/agents', (req: Request, res: Response) => {
    const includeDemo = req.query.includeDemo === 'true';
    const rows = includeDemo
      ? (db.prepare('SELECT * FROM agent_configurations ORDER BY is_demo ASC, created_at ASC').all() as Record<string, unknown>[])
      : (db.prepare('SELECT * FROM agent_configurations WHERE is_demo = 0 ORDER BY created_at ASC').all() as Record<string, unknown>[]);
    res.json({ agents: rows.map(mapAgentRow) });
  });

  app.post('/api/agents', (req: Request, res: Response) => {
    const body = req.body || {};
    if (!body.name || !body.provider || !body.modelId) {
      res.status(400).json({ error: 'name, provider, and modelId are required.' });
      return;
    }
    const validProviders = new Set(['gemini', 'openai', 'anthropic']);
    if (!validProviders.has(body.provider)) {
      res.status(400).json({ error: 'Invalid provider.' });
      return;
    }
    const id = `agent-${crypto.randomUUID().slice(0, 8)}`;
    const now = new Date().toISOString();

    db.prepare(`
      INSERT INTO agent_configurations (
        id, name, provider, model_id, description, system_prompt,
        allowed_tools_json, supports_tools, input_cost_per_1m, output_cost_per_1m,
        max_steps, is_demo, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?)
    `).run(
      id,
      String(body.name).slice(0, 100),
      body.provider,
      String(body.modelId).slice(0, 100),
      String(body.description || 'Custom configured AI agent.').slice(0, 400),
      String(body.systemPrompt || 'You are a helpful, accurate enterprise AI agent.').slice(0, 2000),
      JSON.stringify(Array.isArray(body.allowedTools) ? body.allowedTools : []),
      body.supportsTools === false ? 0 : 1,
      body.inputCostPer1M === null || body.inputCostPer1M === '' || body.inputCostPer1M === undefined
        ? null
        : Number(body.inputCostPer1M),
      body.outputCostPer1M === null || body.outputCostPer1M === '' || body.outputCostPer1M === undefined
        ? null
        : Number(body.outputCostPer1M),
      Math.max(1, Math.min(5, Number(body.maxSteps || 4))),
      now,
      now
    );

    const created = db
      .prepare('SELECT * FROM agent_configurations WHERE id = ?')
      .get(id) as Record<string, unknown>;
    res.status(201).json({ agent: mapAgentRow(created) });
  });

  app.put('/api/agents/:id', (req: Request, res: Response) => {
    const id = String(req.params.id);
    const existing = db
      .prepare('SELECT * FROM agent_configurations WHERE id = ?')
      .get(id) as Record<string, unknown> | undefined;
    if (!existing) {
      res.status(404).json({ error: 'Agent not found.' });
      return;
    }
    if (Boolean(existing.is_demo)) {
      res.status(403).json({ error: 'Demo sample agents cannot be modified.' });
      return;
    }
    const body = req.body || {};
    const now = new Date().toISOString();
    db.prepare(`
      UPDATE agent_configurations
      SET name = ?, provider = ?, model_id = ?, description = ?, system_prompt = ?,
          allowed_tools_json = ?, supports_tools = ?, input_cost_per_1m = ?,
          output_cost_per_1m = ?, max_steps = ?, updated_at = ?
      WHERE id = ?
    `).run(
      String(body.name ?? existing.name).slice(0, 100),
      String(body.provider ?? existing.provider),
      String(body.modelId ?? existing.model_id).slice(0, 100),
      String(body.description ?? existing.description).slice(0, 400),
      String(body.systemPrompt ?? existing.system_prompt).slice(0, 2000),
      JSON.stringify(
        Array.isArray(body.allowedTools)
          ? body.allowedTools
          : JSON.parse(String(existing.allowed_tools_json || '[]'))
      ),
      body.supportsTools === undefined
        ? Number(existing.supports_tools)
        : body.supportsTools
          ? 1
          : 0,
      body.inputCostPer1M === '' || body.inputCostPer1M === null
        ? null
        : body.inputCostPer1M === undefined
          ? existing.input_cost_per_1m
          : Number(body.inputCostPer1M),
      body.outputCostPer1M === '' || body.outputCostPer1M === null
        ? null
        : body.outputCostPer1M === undefined
          ? existing.output_cost_per_1m
          : Number(body.outputCostPer1M),
      Math.max(1, Math.min(5, Number(body.maxSteps ?? existing.max_steps))),
      now,
      id
    );

    const updated = db
      .prepare('SELECT * FROM agent_configurations WHERE id = ?')
      .get(id) as Record<string, unknown>;
    res.json({ agent: mapAgentRow(updated) });
  });

  app.delete('/api/agents/:id', (req: Request, res: Response) => {
    const id = String(req.params.id);
    const existing = db
      .prepare('SELECT * FROM agent_configurations WHERE id = ?')
      .get(id) as Record<string, unknown> | undefined;
    if (!existing) {
      res.status(404).json({ error: 'Agent not found.' });
      return;
    }
    if (Boolean(existing.is_demo)) {
      res.status(403).json({ error: 'Demo sample agents cannot be deleted.' });
      return;
    }
    const execRefs = (
      db.prepare('SELECT COUNT(*) as c FROM agent_executions WHERE agent_id = ?').get(id) as {
        c: number;
      }
    ).c;
    if (execRefs > 0) {
      res.status(409).json({
        error: 'Cannot delete an agent that has stored benchmark execution history.',
      });
      return;
    }
    db.prepare('DELETE FROM agent_configurations WHERE id = ?').run(id);
    res.json({ ok: true });
  });

  // Benchmark Suites & Task Generation
  app.get('/api/suites', (_req: Request, res: Response) => {
    const suites = db
      .prepare('SELECT * FROM benchmark_suites ORDER BY created_at DESC')
      .all() as Record<string, unknown>[];
    res.json({
      suites: suites.map((s) => ({
        id: String(s.id),
        name: String(s.name),
        version: String(s.version),
        category: String(s.category),
        description: String(s.description),
        weights: JSON.parse(String(s.weights_json || JSON.stringify(DEFAULT_WEIGHTS))),
        reliabilityRepeats: Number(s.reliability_repeats || 1),
        isDemo: Boolean(s.is_demo),
        createdAt: String(s.created_at),
      })),
    });
  });

  app.post('/api/suites', (req: Request, res: Response) => {
    const body = req.body || {};
    if (!body.name || !body.category) {
      res.status(400).json({ error: 'Benchmark name and category are required.' });
      return;
    }
    const id = `suite-${crypto.randomUUID().slice(0, 8)}`;
    const now = new Date().toISOString();
    const weights = normalizeWeights(body.weights || DEFAULT_WEIGHTS);
    const repeats = Math.max(1, Math.min(3, Number(body.reliabilityRepeats || 1)));

    db.prepare(`
      INSERT INTO benchmark_suites (
        id, name, version, category, description, weights_json,
        reliability_repeats, is_demo, created_by, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, 0, 'usr-default', ?)
    `).run(
      id,
      String(body.name).slice(0, 140),
      String(body.version || 'v1.0.0').slice(0, 24),
      String(body.category),
      String(body.description || '').slice(0, 600),
      JSON.stringify(weights),
      repeats,
      now
    );

    res.status(201).json({
      suite: {
        id,
        name: String(body.name).slice(0, 140),
        version: String(body.version || 'v1.0.0'),
        category: body.category,
        description: String(body.description || ''),
        weights,
        reliabilityRepeats: repeats,
        isDemo: false,
        createdAt: now,
      },
    });
  });

  app.post('/api/suites/:id/generate-tasks', async (req: Request, res: Response) => {
    const suiteId = String(req.params.id);
    const suiteRow = db
      .prepare('SELECT * FROM benchmark_suites WHERE id = ?')
      .get(suiteId) as Record<string, unknown> | undefined;

    if (!suiteRow) {
      res.status(404).json({ error: 'Benchmark suite not found.' });
      return;
    }

    const count = Math.max(3, Math.min(30, Number(req.body?.count || 20)));
    const result = await generateStandardizedTasks({
      suiteId,
      category: String(suiteRow.category) as BenchmarkCategory,
      description: String(suiteRow.description || ''),
      count,
    });

    const tx = db.transaction(() => {
      db.prepare('DELETE FROM test_cases WHERE suite_id = ?').run(suiteId);
      const insertCase = db.prepare(`
        INSERT INTO test_cases (
          id, suite_id, code, title, instructions, expected_outcome, evaluation_criteria,
          difficulty, reference_answer, deterministic_rules_json, approved, order_index
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);

      for (const tc of result.tasks) {
        insertCase.run(
          tc.id,
          tc.suiteId,
          tc.code,
          tc.title,
          tc.instructions,
          tc.expectedOutcome,
          tc.evaluationCriteria,
          tc.difficulty,
          tc.referenceAnswer,
          JSON.stringify(tc.deterministicRules),
          tc.approved ? 1 : 0,
          tc.orderIndex
        );
      }
    });
    tx();

    res.json({ tasks: result.tasks, source: result.source, note: result.note });
  });

  app.put('/api/test-cases/:id', (req: Request, res: Response) => {
    const id = String(req.params.id);
    const existing = db.prepare('SELECT * FROM test_cases WHERE id = ?').get(id) as
      | Record<string, unknown>
      | undefined;
    if (!existing) {
      res.status(404).json({ error: 'Test case not found.' });
      return;
    }
    const body = req.body || {};
    db.prepare(`
      UPDATE test_cases
      SET title = ?, instructions = ?, expected_outcome = ?, evaluation_criteria = ?,
          difficulty = ?, reference_answer = ?, approved = ?
      WHERE id = ?
    `).run(
      String(body.title ?? existing.title).slice(0, 140),
      String(body.instructions ?? existing.instructions).slice(0, 2000),
      String(body.expectedOutcome ?? existing.expected_outcome).slice(0, 1000),
      String(body.evaluationCriteria ?? existing.evaluation_criteria).slice(0, 1000),
      String(body.difficulty ?? existing.difficulty),
      String(body.referenceAnswer ?? existing.reference_answer).slice(0, 1500),
      body.approved === undefined ? Number(existing.approved) : body.approved ? 1 : 0,
      id
    );
    const updated = db.prepare('SELECT * FROM test_cases WHERE id = ?').get(id) as Record<
      string,
      unknown
    >;
    res.json({ testCase: mapTestCaseRow(updated) });
  });

  app.delete('/api/test-cases/:id', (req: Request, res: Response) => {
    db.prepare('DELETE FROM test_cases WHERE id = ?').run(String(req.params.id));
    res.json({ ok: true });
  });

  // Benchmark Runs
  app.get('/api/runs', (req: Request, res: Response) => {
    const modeFilter = req.query.mode as string | undefined;
    const rows =
      modeFilter === 'demo'
        ? (db.prepare('SELECT * FROM benchmark_runs WHERE is_demo = 1 ORDER BY started_at DESC').all() as Record<string, unknown>[])
        : modeFilter === 'live'
          ? (db.prepare('SELECT * FROM benchmark_runs WHERE is_demo = 0 ORDER BY started_at DESC').all() as Record<string, unknown>[])
          : (db.prepare('SELECT * FROM benchmark_runs ORDER BY is_demo ASC, started_at DESC').all() as Record<string, unknown>[]);

    res.json({ runs: rows.map((r) => hydrateRun(db, r, false)) });
  });

  app.post('/api/runs', async (req: Request, res: Response) => {
    try {
      const { suiteId, selectedAgentIds, weights, reliabilityRepeats } = req.body || {};
      if (!suiteId || !Array.isArray(selectedAgentIds) || selectedAgentIds.length < 2) {
        res.status(400).json({
          error: 'suiteId and at least 2 selectedAgentIds are required to run a benchmark.',
        });
        return;
      }

      const runId = await launchBenchmarkOrchestrator(db, {
        suiteId: String(suiteId),
        selectedAgentIds: selectedAgentIds.map(String),
        weights,
        reliabilityRepeats,
      });

      const runRow = db
        .prepare('SELECT * FROM benchmark_runs WHERE id = ?')
        .get(runId) as Record<string, unknown>;
      res.status(201).json({ run: hydrateRun(db, runRow, false) });
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      res.status(400).json({ error: msg });
    }
  });

  app.get('/api/runs/:id', (req: Request, res: Response) => {
    const row = db
      .prepare('SELECT * FROM benchmark_runs WHERE id = ?')
      .get(String(req.params.id)) as Record<string, unknown> | undefined;
    if (!row) {
      res.status(404).json({ error: 'Benchmark run not found.' });
      return;
    }
    res.json({ run: hydrateRun(db, row, true) });
  });

  app.post('/api/runs/:id/cancel', (req: Request, res: Response) => {
    const id = String(req.params.id);
    requestRunCancellation(id);
    res.json({ ok: true });
  });

  app.get('/api/runs/:id/export', (req: Request, res: Response) => {
    const id = String(req.params.id);
    const row = db.prepare('SELECT * FROM benchmark_runs WHERE id = ?').get(id) as
      | Record<string, unknown>
      | undefined;
    if (!row) {
      res.status(404).json({ error: 'Benchmark run not found.' });
      return;
    }
    const run = hydrateRun(db, row, true);
    const tcMap = new Map((run.testCases || []).map((t) => [t.id, t]));
    const evalMap = new Map((run.evaluations || []).map((e) => [e.executionId, e]));

    const header = [
      'RunID',
      'Mode',
      'Suite',
      'Category',
      'TestCase',
      'Difficulty',
      'Agent',
      'Provider',
      'Model',
      'Status',
      'Completed',
      'AccuracyScore',
      'LatencyMs',
      'InputTokens',
      'OutputTokens',
      'CostUSD',
      'FailureCategory',
    ].join(',');

    const escapeCsv = (val: unknown) => {
      const s = String(val ?? '');
      return `"${s.replace(/"/g, '""')}"`;
    };

    const lines = (run.executions || []).map((ex) => {
      const tc = tcMap.get(ex.testCaseId);
      const ev = evalMap.get(ex.id);
      return [
        run.id,
        run.isDemo ? 'DEMO' : 'LIVE',
        run.suiteName,
        run.category,
        tc?.code || ex.testCaseId,
        tc?.difficulty || '',
        ex.agentName,
        ex.provider,
        ex.modelId,
        ex.status,
        ev?.taskCompleted ? 'TRUE' : 'FALSE',
        ev?.accuracyScore ?? 0,
        ex.latencyMs,
        ex.inputTokens ?? 'UNAVAILABLE',
        ex.outputTokens ?? 'UNAVAILABLE',
        ex.costUsd ?? 'UNAVAILABLE',
        ev?.failureCategory || 'none',
      ]
        .map(escapeCsv)
        .join(',');
    });

    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader(
      'Content-Disposition',
      `attachment; filename="agentarena-${run.id}.csv"`
    );
    res.send([header, ...lines].join('\n'));
  });

  // Leaderboard
  app.get('/api/leaderboard', (req: Request, res: Response) => {
    const mode: DataMode = req.query.mode === 'demo' ? 'demo' : 'live';
    const category = req.query.category ? String(req.query.category) : 'All';
    const isDemoFlag = mode === 'demo' ? 1 : 0;

    const rows =
      category !== 'All'
        ? (db
            .prepare(
              'SELECT * FROM historical_rankings WHERE is_demo = ? AND category = ? ORDER BY recorded_at DESC, overall_score DESC'
            )
            .all(isDemoFlag, category) as Record<string, unknown>[])
        : (db
            .prepare(
              'SELECT * FROM historical_rankings WHERE is_demo = ? ORDER BY recorded_at DESC, overall_score DESC'
            )
            .all(isDemoFlag) as Record<string, unknown>[]);

    const rankings: HistoricalRanking[] = rows.map((r) => ({
      id: String(r.id),
      runId: String(r.run_id),
      suiteId: String(r.suite_id),
      suiteName: String(r.suite_name),
      suiteVersion: String(r.suite_version),
      category: String(r.category) as BenchmarkCategory,
      agentId: String(r.agent_id),
      agentName: String(r.agent_name),
      provider: String(r.provider) as ProviderId,
      modelId: String(r.model_id),
      rank: Number(r.rank),
      overallScore: Number(r.overall_score),
      taskCompletionRate: Number(r.task_completion_rate),
      accuracyScore: Number(r.accuracy_score),
      reliabilityScore: Number(r.reliability_score),
      costEfficiencyScore:
        r.cost_efficiency_score === null ? null : Number(r.cost_efficiency_score),
      avgLatencyMs: Number(r.avg_latency_ms),
      avgCostPerTaskUsd:
        r.avg_cost_per_task_usd === null ? null : Number(r.avg_cost_per_task_usd),
      testCount: Number(r.test_count),
      isDemo: Boolean(r.is_demo),
      recordedAt: String(r.recorded_at),
    }));

    res.json({ mode, rankings });
  });

  // Settings
  app.get('/api/settings', (_req: Request, res: Response) => {
    const row = db
      .prepare("SELECT value_json FROM platform_settings WHERE key = 'global'")
      .get() as { value_json: string } | undefined;
    const settings: PlatformSettings = row
      ? JSON.parse(row.value_json)
      : {
          defaultWeights: DEFAULT_WEIGHTS,
          executionTimeoutMs: 25000,
          maxRetries: 1,
          concurrencyLimit: 3,
          judgeModel: 'gemini-4-hydrogen',
        };
    res.json({ settings });
  });

  app.put('/api/settings', (req: Request, res: Response) => {
    const body = req.body || {};
    const next: PlatformSettings = {
      defaultWeights: normalizeWeights(body.defaultWeights || DEFAULT_WEIGHTS),
      executionTimeoutMs: Math.max(5000, Math.min(60000, Number(body.executionTimeoutMs || 25000))),
      maxRetries: Math.max(0, Math.min(2, Number(body.maxRetries ?? 1))),
      concurrencyLimit: Math.max(1, Math.min(5, Number(body.concurrencyLimit || 3))),
      judgeModel: String(body.judgeModel || 'gemini-4-hydrogen'),
    };
    db.prepare(
      "INSERT OR REPLACE INTO platform_settings (key, value_json, updated_at) VALUES ('global', ?, ?)"
    ).run(JSON.stringify(next), new Date().toISOString());
    res.json({ settings: next });
  });

  // Vite dev middleware or static dist serving
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.join(process.cwd(), 'dist');
    if (fs.existsSync(distDir)) {
      app.use(express.static(distDir));
      app.get('*', (_req, res) => {
        res.sendFile(path.join(distDir, 'index.html'));
      });
    }
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`AgentArena AI server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start AgentArena AI server:', err);
  process.exit(1);
});
