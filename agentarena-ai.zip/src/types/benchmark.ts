export type BenchmarkCategory =
  | 'Customer Support'
  | 'Software Development'
  | 'Research'
  | 'E-commerce'
  | 'Cybersecurity';

export type DifficultyLevel = 'easy' | 'medium' | 'hard' | 'adversarial';

export type ProviderId = 'gemini' | 'openai' | 'anthropic';

export type DataMode = 'live' | 'demo';

export type RecommendationPriority =
  | 'balanced'
  | 'accuracy'
  | 'cost'
  | 'speed'
  | 'reliability';

export type ToolName =
  | 'lookup_order'
  | 'check_policy'
  | 'process_refund'
  | 'query_kb'
  | 'escalate_ticket'
  | 'run_diagnostics'
  | 'search_docs'
  | 'inspect_alert';

export interface ScoringWeights {
  taskCompletion: number;
  accuracy: number;
  reliability: number;
  costEfficiency: number;
  latencyEfficiency: number;
}

export interface ProviderInfo {
  id: ProviderId;
  name: string;
  configured: boolean;
  envVar: string;
  supportedModels: {
    id: string;
    label: string;
    inputCostPer1M: number | null;
    outputCostPer1M: number | null;
  }[];
}

export interface AgentConfig {
  id: string;
  name: string;
  provider: ProviderId;
  modelId: string;
  description: string;
  systemPrompt: string;
  allowedTools: ToolName[];
  supportsTools: boolean;
  inputCostPer1M: number | null;
  outputCostPer1M: number | null;
  maxSteps: number;
  isDemo: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface DeterministicRule {
  requiredKeywords?: string[];
  forbiddenKeywords?: string[];
  requiredTools?: ToolName[];
  forbiddenTools?: ToolName[];
  mustNotFail?: boolean;
}

export interface TestCase {
  id: string;
  suiteId: string;
  code: string;
  title: string;
  instructions: string;
  expectedOutcome: string;
  evaluationCriteria: string;
  difficulty: DifficultyLevel;
  referenceAnswer: string;
  deterministicRules: DeterministicRule;
  approved: boolean;
  orderIndex: number;
}

export interface BenchmarkSuite {
  id: string;
  name: string;
  version: string;
  category: BenchmarkCategory;
  description: string;
  weights: ScoringWeights;
  reliabilityRepeats: number;
  isDemo: boolean;
  createdAt: string;
  testCases?: TestCase[];
}

export interface ToolEvent {
  id: string;
  executionId: string;
  sequence: number;
  timestamp: string;
  eventType: 'step' | 'tool_call' | 'tool_result' | 'policy_block' | 'error' | 'final_output';
  toolName?: string;
  inputSummary?: string;
  outputSummary?: string;
  durationMs: number;
  success: boolean;
}

export interface AgentExecution {
  id: string;
  runId: string;
  testCaseId: string;
  agentId: string;
  agentName: string;
  provider: ProviderId;
  modelId: string;
  repeatIndex: number;
  status: 'completed' | 'failed' | 'timeout' | 'provider_unavailable';
  output: string;
  errorMessage?: string;
  latencyMs: number;
  inputTokens: number | null;
  outputTokens: number | null;
  costUsd: number | null;
  startedAt: string;
  completedAt: string;
  toolEvents: ToolEvent[];
}

export interface EvaluationResult {
  id: string;
  executionId: string;
  runId: string;
  testCaseId: string;
  agentId: string;
  accuracyScore: number; // 0-100
  taskCompleted: boolean;
  toolEfficiencyScore: number | null; // 0-100 or null if no tools required/used
  deterministicPassed: boolean;
  deterministicNotes: string[];
  judgeModel: string;
  judgeReasoning: string;
  judgeEvidence: string;
  judgeLimitations: string;
  failureCategory:
    | 'none'
    | 'incorrect_output'
    | 'incomplete_task'
    | 'missing_tool_call'
    | 'unauthorized_tool'
    | 'timeout'
    | 'provider_error'
    | 'inconsistent_response';
  improvementRecommendation: string;
  evaluatedAt: string;
}

export interface AgentRunSummary {
  agentId: string;
  agentName: string;
  provider: ProviderId;
  modelId: string;
  rank: number;
  overallScore: number;
  taskCompletionRate: number; // 0-100
  accuracyScore: number; // 0-100
  reliabilityScore: number; // 0-100
  costEfficiencyScore: number | null; // 0-100 or null
  latencyEfficiencyScore: number; // 0-100
  toolEfficiencyScore: number | null; // 0-100 or null
  errorRate: number; // 0-100
  avgLatencyMs: number;
  totalInputTokens: number | null;
  totalOutputTokens: number | null;
  totalCostUsd: number | null;
  avgCostPerTaskUsd: number | null;
  completedCount: number;
  totalCount: number;
  missingMetrics: string[];
  rankExplanation: string;
}

export interface BenchmarkRun {
  id: string;
  suiteId: string;
  suiteName: string;
  suiteVersion: string;
  category: BenchmarkCategory;
  status: 'queued' | 'running' | 'completed' | 'failed' | 'cancelled';
  currentStage: string;
  progressPercent: number;
  completedTasks: number;
  totalTasks: number;
  weights: ScoringWeights;
  selectedAgentIds: string[];
  isDemo: boolean;
  startedAt: string;
  completedAt?: string;
  summaries?: AgentRunSummary[];
  executions?: AgentExecution[];
  evaluations?: EvaluationResult[];
  testCases?: TestCase[];
}

export interface HistoricalRanking {
  id: string;
  runId: string;
  suiteId: string;
  suiteName: string;
  suiteVersion: string;
  category: BenchmarkCategory;
  agentId: string;
  agentName: string;
  provider: ProviderId;
  modelId: string;
  rank: number;
  overallScore: number;
  taskCompletionRate: number;
  accuracyScore: number;
  reliabilityScore: number;
  costEfficiencyScore: number | null;
  avgLatencyMs: number;
  avgCostPerTaskUsd: number | null;
  testCount: number;
  isDemo: boolean;
  recordedAt: string;
}

export interface DashboardOverview {
  mode: DataMode;
  totalRuns: number;
  agentsTested: number;
  avgTaskCompletionRate: number;
  avgLatencyMs: number;
  totalCostUsd: number | null;
  recentRuns: BenchmarkRun[];
  topAgents: AgentRunSummary[];
}

export interface RecommendationResult {
  sufficientData: boolean;
  priority: RecommendationPriority;
  recommendedAgentId?: string;
  recommendedAgentName?: string;
  provider?: ProviderId;
  modelId?: string;
  overallScore?: number;
  headline: string;
  rationale: string;
  supportingMetrics: { label: string; value: string }[];
  tradeOffs: string[];
}

export interface PlatformSettings {
  defaultWeights: ScoringWeights;
  executionTimeoutMs: number;
  maxRetries: number;
  concurrencyLimit: number;
  judgeModel: string;
}
