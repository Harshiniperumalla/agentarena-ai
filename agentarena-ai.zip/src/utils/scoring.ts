import type {
  AgentExecution,
  AgentRunSummary,
  DeterministicRule,
  EvaluationResult,
  ProviderId,
  RecommendationPriority,
  RecommendationResult,
  ScoringWeights,
  TestCase,
} from '../types/benchmark';

export const DEFAULT_WEIGHTS: ScoringWeights = {
  taskCompletion: 30,
  accuracy: 25,
  reliability: 20,
  costEfficiency: 15,
  latencyEfficiency: 10,
};

/**
 * Validates and explicitly normalizes scoring weights so they total exactly 100.
 */
export function normalizeWeights(weights: ScoringWeights): ScoringWeights {
  const safe = {
    taskCompletion: Math.max(0, Number(weights.taskCompletion) || 0),
    accuracy: Math.max(0, Number(weights.accuracy) || 0),
    reliability: Math.max(0, Number(weights.reliability) || 0),
    costEfficiency: Math.max(0, Number(weights.costEfficiency) || 0),
    latencyEfficiency: Math.max(0, Number(weights.latencyEfficiency) || 0),
  };

  const sum =
    safe.taskCompletion +
    safe.accuracy +
    safe.reliability +
    safe.costEfficiency +
    safe.latencyEfficiency;

  if (sum <= 0) {
    return { ...DEFAULT_WEIGHTS };
  }

  if (Math.abs(sum - 100) < 0.001) {
    return safe;
  }

  const scale = 100 / sum;
  const normalized: ScoringWeights = {
    taskCompletion: Math.round(safe.taskCompletion * scale * 100) / 100,
    accuracy: Math.round(safe.accuracy * scale * 100) / 100,
    reliability: Math.round(safe.reliability * scale * 100) / 100,
    costEfficiency: Math.round(safe.costEfficiency * scale * 100) / 100,
    latencyEfficiency: 0,
  };
  normalized.latencyEfficiency = Math.max(
    0,
    Math.round(
      (100 -
        (normalized.taskCompletion +
          normalized.accuracy +
          normalized.reliability +
          normalized.costEfficiency)) *
        100
    ) / 100
  );
  return normalized;
}

/**
 * Computes execution cost in USD from token counts and configured per-1M token rates.
 * Returns null if pricing or token metadata is unavailable (never fabricates $0).
 */
export function calculateExecutionCost(
  inputTokens: number | null,
  outputTokens: number | null,
  inputCostPer1M: number | null,
  outputCostPer1M: number | null
): number | null {
  if (
    inputTokens === null ||
    outputTokens === null ||
    inputCostPer1M === null ||
    outputCostPer1M === null
  ) {
    return null;
  }
  const cost =
    (inputTokens / 1_000_000) * inputCostPer1M +
    (outputTokens / 1_000_000) * outputCostPer1M;
  return Math.round(cost * 1_000_000) / 1_000_000;
}

/**
 * Deterministic verification checks run before independent LLM-as-judge evaluation.
 */
export function runDeterministicChecks(
  testCase: TestCase,
  output: string,
  calledTools: string[],
  status: AgentExecution['status']
): {
  passed: boolean;
  notes: string[];
  toolEfficiencyScore: number | null;
  failureCategoryHint: EvaluationResult['failureCategory'];
} {
  const notes: string[] = [];
  let passed = true;
  let failureCategoryHint: EvaluationResult['failureCategory'] = 'none';

  if (status === 'timeout') {
    return {
      passed: false,
      notes: ['Execution exceeded configured timeout threshold.'],
      toolEfficiencyScore: 0,
      failureCategoryHint: 'timeout',
    };
  }

  if (status === 'provider_unavailable' || status === 'failed') {
    return {
      passed: false,
      notes: [`Execution failed with status: ${status}.`],
      toolEfficiencyScore: 0,
      failureCategoryHint: 'provider_error',
    };
  }

  const trimmed = (output || '').trim();
  if (!trimmed) {
    passed = false;
    notes.push('Agent returned an empty output.');
    failureCategoryHint = 'incomplete_task';
  }

  const rules: DeterministicRule = testCase.deterministicRules || {};
  const lowerOutput = trimmed.toLowerCase();

  if (rules.requiredKeywords && rules.requiredKeywords.length > 0) {
    const missing = rules.requiredKeywords.filter(
      (kw) => !lowerOutput.includes(kw.toLowerCase())
    );
    if (missing.length > 0) {
      passed = false;
      notes.push(`Missing expected terms: ${missing.join(', ')}`);
      if (failureCategoryHint === 'none') {
        failureCategoryHint = 'incorrect_output';
      }
    } else {
      notes.push(`Matched all ${rules.requiredKeywords.length} required terms.`);
    }
  }

  if (rules.forbiddenKeywords && rules.forbiddenKeywords.length > 0) {
    const found = rules.forbiddenKeywords.filter((kw) =>
      lowerOutput.includes(kw.toLowerCase())
    );
    if (found.length > 0) {
      passed = false;
      notes.push(`Forbidden terms detected: ${found.join(', ')}`);
      failureCategoryHint = 'incorrect_output';
    }
  }

  let toolEfficiencyScore: number | null = null;
  const requiredTools = rules.requiredTools || [];
  const forbiddenTools = rules.forbiddenTools || [];

  if (requiredTools.length > 0 || forbiddenTools.length > 0 || calledTools.length > 0) {
    let score = 100;
    const missingTools = requiredTools.filter((t) => !calledTools.includes(t));
    if (missingTools.length > 0) {
      passed = false;
      score -= Math.round((missingTools.length / Math.max(1, requiredTools.length)) * 70);
      notes.push(`Missing required tool calls: ${missingTools.join(', ')}`);
      failureCategoryHint = 'missing_tool_call';
    } else if (requiredTools.length > 0) {
      notes.push(`Invoked all required tools (${requiredTools.join(', ')}).`);
    }

    const badTools = forbiddenTools.filter((t) => calledTools.includes(t));
    if (badTools.length > 0) {
      passed = false;
      score -= 50;
      notes.push(`Invoked restricted or inappropriate tools: ${badTools.join(', ')}`);
      failureCategoryHint = 'unauthorized_tool';
    }

    // Penalize excessive redundant tool calls (> required + 3)
    const redundantCalls = Math.max(0, calledTools.length - Math.max(2, requiredTools.length + 2));
    if (redundantCalls > 0) {
      score -= Math.min(20, redundantCalls * 5);
      notes.push(`Observed ${redundantCalls} extra tool call(s) beyond expected minimum.`);
    }

    toolEfficiencyScore = Math.max(0, Math.min(100, score));
  }

  return {
    passed,
    notes,
    toolEfficiencyScore,
    failureCategoryHint,
  };
}

/**
 * Computes normalized 0-100 efficiency score where lower values (cost/latency) are better.
 * Uses relative anchor scaling against peers + reasonable bounds so scores are interpretable.
 */
function scoreLowerIsBetter(value: number, minPeer: number, maxPeer: number, floorAnchor: number): number {
  const best = Math.min(minPeer, floorAnchor);
  const worst = Math.max(maxPeer, best * 3);
  if (worst <= best) return 100;
  const ratio = (value - best) / (worst - best);
  return Math.round(Math.max(5, Math.min(100, 100 - ratio * 85)) * 10) / 10;
}

/**
 * Computes reliability (consistency across repeated runs or across task completion stability).
 */
export function computeReliabilityScore(
  executions: AgentExecution[],
  evaluations: EvaluationResult[]
): number {
  if (executions.length === 0) return 0;

  // Group by testCaseId to check repeatability consistency if repeats > 1
  const byTask = new Map<string, EvaluationResult[]>();
  for (const ev of evaluations) {
    const arr = byTask.get(ev.testCaseId) || [];
    arr.push(ev);
    byTask.set(ev.testCaseId, arr);
  }

  const evalByExec = new Map(evaluations.map((e) => [e.executionId, e]));
  const nonErrorRate =
    executions.filter((e) => e.status === 'completed').length / executions.length;

  let consistencyFactors: number[] = [];
  for (const [, list] of byTask.entries()) {
    if (list.length > 1) {
      const completionSet = new Set(list.map((l) => l.taskCompleted));
      const scores = list.map((l) => l.accuracyScore);
      const mean = scores.reduce((a, b) => a + b, 0) / scores.length;
      const variance =
        scores.reduce((acc, s) => acc + Math.pow(s - mean, 2), 0) / scores.length;
      const stdDev = Math.sqrt(variance);
      const repeatConsistency =
        (completionSet.size === 1 ? 100 : 60) - Math.min(40, stdDev * 1.2);
      consistencyFactors.push(Math.max(0, repeatConsistency));
    }
  }

  if (consistencyFactors.length > 0) {
    const avgRepeatConsistency =
      consistencyFactors.reduce((a, b) => a + b, 0) / consistencyFactors.length;
    return Math.round((nonErrorRate * 40 + (avgRepeatConsistency / 100) * 60) * 10) / 10;
  }

  // Single-run stability: blend non-error rate with deterministic check pass rate
  const detPassCount = executions.filter(
    (ex) => evalByExec.get(ex.id)?.deterministicPassed
  ).length;
  const detRate = detPassCount / executions.length;
  return Math.round((nonErrorRate * 60 + detRate * 40) * 10) / 10;
}

/**
 * Aggregates execution & evaluation records into ranked AgentRunSummary rows.
 * Handles missing cost/token metadata transparently by re-normalizing available weights
 * rather than silently assigning 100% for missing metrics.
 */
export function computeRunSummaries(
  executions: AgentExecution[],
  evaluations: EvaluationResult[],
  rawWeights: ScoringWeights
): AgentRunSummary[] {
  const weights = normalizeWeights(rawWeights);
  const evalMap = new Map(evaluations.map((e) => [e.executionId, e]));

  const agentGroups = new Map<
    string,
    {
      agentId: string;
      agentName: string;
      provider: ProviderId;
      modelId: string;
      execs: AgentExecution[];
      evals: EvaluationResult[];
    }
  >();

  for (const exec of executions) {
    const group = agentGroups.get(exec.agentId) || {
      agentId: exec.agentId,
      agentName: exec.agentName,
      provider: exec.provider,
      modelId: exec.modelId,
      execs: [],
      evals: [],
    };
    group.execs.push(exec);
    const ev = evalMap.get(exec.id);
    if (ev) group.evals.push(ev);
    agentGroups.set(exec.agentId, group);
  }

  const rawStats = Array.from(agentGroups.values()).map((g) => {
    const totalCount = g.execs.length;
    const completedExecs = g.execs.filter((e) => e.status === 'completed');
    const errorCount = totalCount - completedExecs.length;
    const errorRate = totalCount > 0 ? Math.round((errorCount / totalCount) * 1000) / 10 : 0;

    const avgLatencyMs =
      totalCount > 0
        ? Math.round(g.execs.reduce((s, e) => s + e.latencyMs, 0) / totalCount)
        : 0;

    const evals = g.evals;
    const taskCompletionRate =
      totalCount > 0
        ? Math.round(
            (evals.filter((e) => e.taskCompleted).length / Math.max(1, totalCount)) * 1000
          ) / 10
        : 0;

    const accuracyScore =
      evals.length > 0
        ? Math.round(
            (evals.reduce((s, e) => s + e.accuracyScore, 0) / evals.length) * 10
          ) / 10
        : 0;

    const reliabilityScore = computeReliabilityScore(g.execs, evals);

    const toolEvals = evals.filter((e) => e.toolEfficiencyScore !== null);
    const toolEfficiencyScore =
      toolEvals.length > 0
        ? Math.round(
            (toolEvals.reduce((s, e) => s + (e.toolEfficiencyScore ?? 0), 0) /
              toolEvals.length) *
              10
          ) / 10
        : null;

    const withTokens = g.execs.filter(
      (e) => e.inputTokens !== null && e.outputTokens !== null
    );
    const totalInputTokens =
      withTokens.length > 0
        ? withTokens.reduce((s, e) => s + (e.inputTokens ?? 0), 0)
        : null;
    const totalOutputTokens =
      withTokens.length > 0
        ? withTokens.reduce((s, e) => s + (e.outputTokens ?? 0), 0)
        : null;

    const withCost = g.execs.filter((e) => e.costUsd !== null);
    const totalCostUsd =
      withCost.length === totalCount && totalCount > 0
        ? Math.round(withCost.reduce((s, e) => s + (e.costUsd ?? 0), 0) * 1_000_000) /
          1_000_000
        : withCost.length > 0
          ? Math.round(withCost.reduce((s, e) => s + (e.costUsd ?? 0), 0) * 1_000_000) /
            1_000_000
          : null;

    const avgCostPerTaskUsd =
      totalCostUsd !== null && withCost.length > 0
        ? Math.round((totalCostUsd / withCost.length) * 1_000_000) / 1_000_000
        : null;

    const missingMetrics: string[] = [];
    if (totalInputTokens === null) missingMetrics.push('token_usage');
    if (avgCostPerTaskUsd === null) missingMetrics.push('execution_cost');
    if (toolEfficiencyScore === null) missingMetrics.push('tool_efficiency');

    return {
      ...g,
      totalCount,
      completedCount: evals.filter((e) => e.taskCompleted).length,
      errorRate,
      avgLatencyMs,
      taskCompletionRate,
      accuracyScore,
      reliabilityScore,
      toolEfficiencyScore,
      totalInputTokens,
      totalOutputTokens,
      totalCostUsd,
      avgCostPerTaskUsd,
      missingMetrics,
    };
  });

  if (rawStats.length === 0) return [];

  const validLatencies = rawStats.map((r) => r.avgLatencyMs).filter((l) => l > 0);
  const minLatency = validLatencies.length > 0 ? Math.min(...validLatencies) : 500;
  const maxLatency = validLatencies.length > 0 ? Math.max(...validLatencies) : 5000;

  const validCosts = rawStats
    .map((r) => r.avgCostPerTaskUsd)
    .filter((c): c is number => c !== null && c > 0);
  const minCost = validCosts.length > 0 ? Math.min(...validCosts) : 0.005;
  const maxCost = validCosts.length > 0 ? Math.max(...validCosts) : 0.05;

  const scored: AgentRunSummary[] = rawStats.map((r) => {
    const latencyEfficiencyScore =
      r.errorRate === 100
        ? 0
        : scoreLowerIsBetter(r.avgLatencyMs, minLatency, maxLatency, 600);

    const costEfficiencyScore =
      r.avgCostPerTaskUsd === null || r.errorRate === 100
        ? r.avgCostPerTaskUsd === null
          ? null
          : 0
        : scoreLowerIsBetter(r.avgCostPerTaskUsd, minCost, maxCost, 0.001);

    // Compute overall score using only available weighted components (never silently assigning 100 to missing cost)
    const components: { score: number; weight: number }[] = [
      { score: r.taskCompletionRate, weight: weights.taskCompletion },
      { score: r.accuracyScore, weight: weights.accuracy },
      { score: r.reliabilityScore, weight: weights.reliability },
      { score: latencyEfficiencyScore, weight: weights.latencyEfficiency },
    ];
    if (costEfficiencyScore !== null) {
      components.push({ score: costEfficiencyScore, weight: weights.costEfficiency });
    }

    const activeWeightSum = components.reduce((s, c) => s + c.weight, 0);
    const overallScore =
      activeWeightSum > 0
        ? Math.round(
            (components.reduce((s, c) => s + c.score * c.weight, 0) / activeWeightSum) *
              10
          ) / 10
        : 0;

    return {
      agentId: r.agentId,
      agentName: r.agentName,
      provider: r.provider,
      modelId: r.modelId,
      rank: 0,
      overallScore,
      taskCompletionRate: r.taskCompletionRate,
      accuracyScore: r.accuracyScore,
      reliabilityScore: r.reliabilityScore,
      costEfficiencyScore,
      latencyEfficiencyScore,
      toolEfficiencyScore: r.toolEfficiencyScore,
      errorRate: r.errorRate,
      avgLatencyMs: r.avgLatencyMs,
      totalInputTokens: r.totalInputTokens,
      totalOutputTokens: r.totalOutputTokens,
      totalCostUsd: r.totalCostUsd,
      avgCostPerTaskUsd: r.avgCostPerTaskUsd,
      completedCount: r.completedCount,
      totalCount: r.totalCount,
      missingMetrics: r.missingMetrics,
      rankExplanation: '',
    };
  });

  scored.sort((a, b) => {
    if (b.overallScore !== a.overallScore) return b.overallScore - a.overallScore;
    if (b.taskCompletionRate !== a.taskCompletionRate)
      return b.taskCompletionRate - a.taskCompletionRate;
    return a.avgLatencyMs - b.avgLatencyMs;
  });

  const leader = scored[0];
  scored.forEach((s, idx) => {
    s.rank = idx + 1;
    if (idx === 0) {
      const strengths: string[] = [];
      if (s.taskCompletionRate >= 85)
        strengths.push(`${s.taskCompletionRate}% task completion`);
      if (s.accuracyScore >= 85) strengths.push(`${s.accuracyScore}% accuracy`);
      if (s.reliabilityScore >= 85) strengths.push(`${s.reliabilityScore}% reliability`);
      if (s.costEfficiencyScore !== null && s.costEfficiencyScore >= 75)
        strengths.push(`strong cost efficiency`);
      s.rankExplanation =
        strengths.length > 0
          ? `Ranked #1 with ${s.overallScore}/100 overall score, driven by ${strengths.join(', ')}.`
          : `Ranked #1 with the highest weighted score (${s.overallScore}/100) across evaluated tasks.`;
    } else {
      const gap = Math.round((leader.overallScore - s.overallScore) * 10) / 10;
      const fasterThanLeader = s.avgLatencyMs < leader.avgLatencyMs;
      const cheaperThanLeader =
        s.avgCostPerTaskUsd !== null &&
        leader.avgCostPerTaskUsd !== null &&
        s.avgCostPerTaskUsd < leader.avgCostPerTaskUsd;
      const notes: string[] = [`${gap} pts behind ${leader.agentName}`];
      if (fasterThanLeader) notes.push(`faster avg latency (${s.avgLatencyMs}ms)`);
      if (cheaperThanLeader)
        notes.push(`lower cost/task ($${s.avgCostPerTaskUsd?.toFixed(4)})`);
      if (s.errorRate > 0) notes.push(`${s.errorRate}% error rate`);
      s.rankExplanation = `Ranked #${s.rank}: ${notes.join('; ')}.`;
    }
  });

  return scored;
}

/**
 * Generates an evidence-based Smart Agent Recommendation from actual benchmark summaries.
 * Refuses to recommend if insufficient data exists.
 */
export function recommendAgent(
  summaries: AgentRunSummary[],
  priority: RecommendationPriority
): RecommendationResult {
  const viable = summaries.filter((s) => s.totalCount > 0 && s.errorRate < 100);
  if (viable.length === 0) {
    return {
      sufficientData: false,
      priority,
      headline: 'Insufficient benchmark data for recommendation',
      rationale:
        'At least one agent must complete benchmark tasks without a 100% failure rate before AgentArena AI can issue an evidence-based deployment recommendation.',
      supportingMetrics: [],
      tradeOffs: ['Run a benchmark with configured agents to collect execution telemetry.'],
    };
  }

  let selected = viable[0];
  if (priority === 'accuracy') {
    selected = [...viable].sort((a, b) =>
      b.accuracyScore !== a.accuracyScore
        ? b.accuracyScore - a.accuracyScore
        : b.taskCompletionRate - a.taskCompletionRate
    )[0];
  } else if (priority === 'speed') {
    selected = [...viable].sort((a, b) => a.avgLatencyMs - b.avgLatencyMs)[0];
  } else if (priority === 'reliability') {
    selected = [...viable].sort((a, b) =>
      b.reliabilityScore !== a.reliabilityScore
        ? b.reliabilityScore - a.reliabilityScore
        : a.errorRate - b.errorRate
    )[0];
  } else if (priority === 'cost') {
    const withCost = viable.filter((v) => v.avgCostPerTaskUsd !== null);
    if (withCost.length === 0) {
      return {
        sufficientData: false,
        priority,
        headline: 'Cost data unavailable for cost-optimized recommendation',
        rationale:
          'None of the evaluated agents have verified model pricing metadata configured. Configure pricing rates in Agent Management to enable cost-optimized selection.',
        supportingMetrics: [],
        tradeOffs: ['Switch priority to Balanced, Accuracy, or Speed, or add token pricing.'],
      };
    }
    selected = [...withCost].sort(
      (a, b) => (a.avgCostPerTaskUsd ?? Infinity) - (b.avgCostPerTaskUsd ?? Infinity)
    )[0];
  }

  const tradeOffs: string[] = [];
  const fastest = [...viable].sort((a, b) => a.avgLatencyMs - b.avgLatencyMs)[0];
  const mostAccurate = [...viable].sort((a, b) => b.accuracyScore - a.accuracyScore)[0];
  const withCost = viable.filter((v) => v.avgCostPerTaskUsd !== null);
  const cheapest =
    withCost.length > 0
      ? [...withCost].sort(
          (a, b) => (a.avgCostPerTaskUsd ?? Infinity) - (b.avgCostPerTaskUsd ?? Infinity)
        )[0]
      : null;

  if (selected.agentId !== fastest.agentId) {
    tradeOffs.push(
      `Latency trade-off: ${fastest.agentName} is faster at ${fastest.avgLatencyMs}ms vs ${selected.avgLatencyMs}ms.`
    );
  }
  if (selected.agentId !== mostAccurate.agentId) {
    tradeOffs.push(
      `Accuracy trade-off: ${mostAccurate.agentName} scored higher on accuracy (${mostAccurate.accuracyScore}% vs ${selected.accuracyScore}%).`
    );
  }
  if (cheapest && selected.agentId !== cheapest.agentId) {
    tradeOffs.push(
      `Cost trade-off: ${cheapest.agentName} costs less per task ($${cheapest.avgCostPerTaskUsd?.toFixed(4)} vs $${selected.avgCostPerTaskUsd?.toFixed(4) ?? 'N/A'}).`
    );
  }
  if (selected.errorRate > 0) {
    tradeOffs.push(`Observed ${selected.errorRate}% execution error rate; review failure trace before rollout.`);
  }
  if (tradeOffs.length === 0) {
    tradeOffs.push('Outperformed all peer agents on the selected objective with zero observed regressions.');
  }

  const priorityLabels: Record<RecommendationPriority, string> = {
    balanced: 'Balanced Overall Performance',
    accuracy: 'Highest Accuracy',
    cost: 'Lowest Cost per Task',
    speed: 'Fastest Response Latency',
    reliability: 'Maximum Reliability',
  };

  return {
    sufficientData: true,
    priority,
    recommendedAgentId: selected.agentId,
    recommendedAgentName: selected.agentName,
    provider: selected.provider,
    modelId: selected.modelId,
    overallScore: selected.overallScore,
    headline: `Deploy ${selected.agentName} for ${priorityLabels[priority]}`,
    rationale: `Across ${selected.totalCount} standardized task executions, ${selected.agentName} (${selected.modelId}) achieved ${selected.taskCompletionRate}% task completion, ${selected.accuracyScore}% accuracy, and ${selected.reliabilityScore}% reliability with an average latency of ${(selected.avgLatencyMs / 1000).toFixed(2)}s.`,
    supportingMetrics: [
      { label: 'Overall Score', value: `${selected.overallScore}/100` },
      { label: 'Task Completion', value: `${selected.taskCompletionRate}%` },
      { label: 'Accuracy', value: `${selected.accuracyScore}%` },
      { label: 'Avg Latency', value: `${(selected.avgLatencyMs / 1000).toFixed(2)}s` },
      {
        label: 'Cost / Task',
        value:
          selected.avgCostPerTaskUsd !== null
            ? `$${selected.avgCostPerTaskUsd.toFixed(4)}`
            : 'Unavailable',
      },
      { label: 'Reliability', value: `${selected.reliabilityScore}%` },
    ],
    tradeOffs,
  };
}
