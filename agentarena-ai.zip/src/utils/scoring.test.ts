import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateExecutionCost,
  computeRunSummaries,
  DEFAULT_WEIGHTS,
  normalizeWeights,
  recommendAgent,
  runDeterministicChecks,
} from './scoring';
import type { AgentExecution, EvaluationResult, TestCase } from '../types/benchmark';

test('normalizeWeights scales unequal weights to sum to 100', () => {
  const normalized = normalizeWeights({
    taskCompletion: 60,
    accuracy: 50,
    reliability: 40,
    costEfficiency: 30,
    latencyEfficiency: 20,
  });
  const total =
    normalized.taskCompletion +
    normalized.accuracy +
    normalized.reliability +
    normalized.costEfficiency +
    normalized.latencyEfficiency;
  assert.ok(Math.abs(total - 100) < 0.01);
  assert.equal(normalized.taskCompletion, 30);
  assert.equal(normalized.accuracy, 25);
});

test('calculateExecutionCost returns null when pricing or token usage is missing', () => {
  assert.equal(calculateExecutionCost(null, 200, 0.1, 0.4), null);
  assert.equal(calculateExecutionCost(1000, 500, null, 0.4), null);
  const cost = calculateExecutionCost(1_000_000, 500_000, 0.5, 2.0);
  assert.equal(cost, 1.5);
});

test('runDeterministicChecks detects missing required tools and forbidden terms', () => {
  const tc: TestCase = {
    id: 'tc-1',
    suiteId: 'suite-1',
    code: 'CS-01',
    title: 'Refund eligibility',
    instructions: 'Check order ORD-101 and process refund if eligible',
    expectedOutcome: 'Order checked and refunded',
    evaluationCriteria: 'Verify order first',
    difficulty: 'medium',
    referenceAnswer: 'Refund approved for ORD-101',
    deterministicRules: {
      requiredKeywords: ['ORD-101', 'refund'],
      forbiddenKeywords: ['guaranteed free forever'],
      requiredTools: ['lookup_order', 'process_refund'],
    },
    approved: true,
    orderIndex: 0,
  };

  const missingTool = runDeterministicChecks(
    tc,
    'Your refund for ORD-101 has been processed.',
    ['lookup_order'],
    'completed'
  );
  assert.equal(missingTool.passed, false);
  assert.equal(missingTool.failureCategoryHint, 'missing_tool_call');

  const passed = runDeterministicChecks(
    tc,
    'Checked ORD-101 and issued the refund.',
    ['lookup_order', 'process_refund'],
    'completed'
  );
  assert.equal(passed.passed, true);
  assert.equal(passed.toolEfficiencyScore, 100);
});

test('computeRunSummaries ranks agents transparently and handles missing cost metadata', () => {
  const execs: AgentExecution[] = [
    {
      id: 'ex-1',
      runId: 'run-1',
      testCaseId: 'tc-1',
      agentId: 'a-1',
      agentName: 'Agent Alpha',
      provider: 'gemini',
      modelId: 'gemini-4-hydrogen',
      repeatIndex: 0,
      status: 'completed',
      output: 'Done',
      latencyMs: 1200,
      inputTokens: 400,
      outputTokens: 150,
      costUsd: 0.002,
      startedAt: '2026-11-13T10:00:00Z',
      completedAt: '2026-11-13T10:00:01Z',
      toolEvents: [],
    },
    {
      id: 'ex-2',
      runId: 'run-1',
      testCaseId: 'tc-1',
      agentId: 'a-2',
      agentName: 'Agent Beta',
      provider: 'openai',
      modelId: 'gpt-4o',
      repeatIndex: 0,
      status: 'completed',
      output: 'Partial',
      latencyMs: 2500,
      inputTokens: null,
      outputTokens: null,
      costUsd: null,
      startedAt: '2026-11-13T10:00:00Z',
      completedAt: '2026-11-13T10:00:02Z',
      toolEvents: [],
    },
  ];

  const evals: EvaluationResult[] = [
    {
      id: 'ev-1',
      executionId: 'ex-1',
      runId: 'run-1',
      testCaseId: 'tc-1',
      agentId: 'a-1',
      accuracyScore: 95,
      taskCompleted: true,
      toolEfficiencyScore: 100,
      deterministicPassed: true,
      deterministicNotes: [],
      judgeModel: 'gemini-4-hydrogen',
      judgeReasoning: 'Accurate and complete.',
      judgeEvidence: 'Matched criteria.',
      judgeLimitations: 'Single judge pass.',
      failureCategory: 'none',
      improvementRecommendation: '',
      evaluatedAt: '2026-11-13T10:00:02Z',
    },
    {
      id: 'ev-2',
      executionId: 'ex-2',
      runId: 'run-1',
      testCaseId: 'tc-1',
      agentId: 'a-2',
      accuracyScore: 72,
      taskCompleted: false,
      toolEfficiencyScore: 50,
      deterministicPassed: false,
      deterministicNotes: ['Missing keyword'],
      judgeModel: 'gemini-4-hydrogen',
      judgeReasoning: 'Partial answer.',
      judgeEvidence: 'Missed step 2.',
      judgeLimitations: 'Single judge pass.',
      failureCategory: 'incomplete_task',
      improvementRecommendation: 'Include order verification.',
      evaluatedAt: '2026-11-13T10:00:03Z',
    },
  ];

  const summaries = computeRunSummaries(execs, evals, DEFAULT_WEIGHTS);
  assert.equal(summaries.length, 2);
  assert.equal(summaries[0].agentId, 'a-1');
  assert.equal(summaries[0].rank, 1);
  assert.equal(summaries[1].costEfficiencyScore, null);
  assert.ok(summaries[1].missingMetrics.includes('execution_cost'));
});

test('recommendAgent refuses recommendation when no viable data exists', () => {
  const emptyRec = recommendAgent([], 'balanced');
  assert.equal(emptyRec.sufficientData, false);
});
