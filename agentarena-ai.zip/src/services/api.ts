import { jsPDF } from 'jspdf';
import type {
  AgentConfig,
  BenchmarkCategory,
  BenchmarkRun,
  BenchmarkSuite,
  DataMode,
  DashboardOverview,
  HistoricalRanking,
  PlatformSettings,
  ProviderInfo,
  ScoringWeights,
  TestCase,
} from '../types/benchmark';

async function apiJson<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    ...init,
    headers: {
      'Content-Type': 'application/json',
      ...(init?.headers || {}),
    },
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error((data as { error?: string }).error || `Request failed (${res.status})`);
  }
  return data as T;
}

export const api = {
  getHealth: () => apiJson<{ ok: boolean; providers: ProviderInfo[] }>('/api/health'),
  getDashboard: (mode: DataMode) =>
    apiJson<DashboardOverview>(`/api/dashboard?mode=${mode}`),

  getAgents: (includeDemo = false) =>
    apiJson<{ agents: AgentConfig[] }>(`/api/agents?includeDemo=${includeDemo}`),
  createAgent: (payload: Partial<AgentConfig>) =>
    apiJson<{ agent: AgentConfig }>('/api/agents', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  updateAgent: (id: string, payload: Partial<AgentConfig>) =>
    apiJson<{ agent: AgentConfig }>(`/api/agents/${id}`, {
      method: 'PUT',
      body: JSON.stringify(payload),
    }),
  deleteAgent: (id: string) =>
    apiJson<{ ok: boolean }>(`/api/agents/${id}`, { method: 'DELETE' }),

  getSuites: () => apiJson<{ suites: BenchmarkSuite[] }>('/api/suites'),
  createSuite: (payload: {
    name: string;
    version?: string;
    category: BenchmarkCategory;
    description: string;
    weights: ScoringWeights;
    reliabilityRepeats: number;
  }) =>
    apiJson<{ suite: BenchmarkSuite }>('/api/suites', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  generateTasks: (suiteId: string, count: number) =>
    apiJson<{ tasks: TestCase[]; source: string; note: string }>(
      `/api/suites/${suiteId}/generate-tasks`,
      {
        method: 'POST',
        body: JSON.stringify({ count }),
      }
    ),
  updateTestCase: (id: string, payload: Partial<TestCase>) =>
    apiJson<{ testCase: TestCase }>(`/api/test-cases/${id}`, {
      method: 'PUT',
      body: JSON.stringify(payload),
    }),
  deleteTestCase: (id: string) =>
    apiJson<{ ok: boolean }>(`/api/test-cases/${id}`, { method: 'DELETE' }),

  getRuns: (mode?: DataMode) =>
    apiJson<{ runs: BenchmarkRun[] }>(mode ? `/api/runs?mode=${mode}` : '/api/runs'),
  launchRun: (payload: {
    suiteId: string;
    selectedAgentIds: string[];
    weights: ScoringWeights;
    reliabilityRepeats: number;
  }) =>
    apiJson<{ run: BenchmarkRun }>('/api/runs', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  getRun: (id: string) => apiJson<{ run: BenchmarkRun }>(`/api/runs/${id}`),
  cancelRun: (id: string) =>
    apiJson<{ ok: boolean }>(`/api/runs/${id}/cancel`, { method: 'POST' }),

  getLeaderboard: (mode: DataMode, category: string) =>
    apiJson<{ mode: DataMode; rankings: HistoricalRanking[] }>(
      `/api/leaderboard?mode=${mode}&category=${encodeURIComponent(category)}`
    ),

  getSettings: () => apiJson<{ settings: PlatformSettings }>('/api/settings'),
  updateSettings: (settings: PlatformSettings) =>
    apiJson<{ settings: PlatformSettings }>('/api/settings', {
      method: 'PUT',
      body: JSON.stringify(settings),
    }),
};

export function exportRunPdf(run: BenchmarkRun): void {
  const doc = new jsPDF();
  let y = 18;

  doc.setFontSize(18);
  doc.text('AgentArena AI — Benchmark Evaluation Report', 14, y);
  y += 8;

  doc.setFontSize(10);
  doc.text(
    `Suite: ${run.suiteName} (${run.suiteVersion}) | Category: ${run.category}`,
    14,
    y
  );
  y += 6;
  doc.text(
    `Run ID: ${run.id} | Mode: ${run.isDemo ? 'DEMO SAMPLE DATA' : 'LIVE EXECUTION'} | Status: ${run.status.toUpperCase()}`,
    14,
    y
  );
  y += 6;
  doc.text(`Started: ${new Date(run.startedAt).toLocaleString()}`, 14, y);
  y += 10;

  doc.setFontSize(12);
  doc.text('Agent Performance Comparison', 14, y);
  y += 7;

  doc.setFontSize(9);
  for (const s of run.summaries || []) {
    if (y > 265) {
      doc.addPage();
      y = 18;
    }
    const costStr =
      s.avgCostPerTaskUsd !== null ? `$${s.avgCostPerTaskUsd.toFixed(4)}/task` : 'Unavailable';
    doc.text(
      `#${s.rank} ${s.agentName} (${s.modelId}) — Overall: ${s.overallScore}/100 | Completion: ${s.taskCompletionRate}% | Accuracy: ${s.accuracyScore}% | Reliability: ${s.reliabilityScore}% | Latency: ${s.avgLatencyMs}ms | Cost: ${costStr}`,
      14,
      y,
      { maxWidth: 182 }
    );
    y += 10;
  }

  const failures = (run.evaluations || []).filter((e) => !e.taskCompleted);
  y += 4;
  if (y > 260) {
    doc.addPage();
    y = 18;
  }
  doc.setFontSize(12);
  doc.text(`Failure Breakdown (${failures.length} failed executions)`, 14, y);
  y += 7;
  doc.setFontSize(8.5);

  const tcMap = new Map((run.testCases || []).map((t) => [t.id, t]));
  const execMap = new Map((run.executions || []).map((e) => [e.id, e]));

  for (const f of failures.slice(0, 20)) {
    if (y > 265) {
      doc.addPage();
      y = 18;
    }
    const tc = tcMap.get(f.testCaseId);
    const ex = execMap.get(f.executionId);
    doc.text(
      `[${tc?.code || f.testCaseId}] ${ex?.agentName || f.agentId} (${f.failureCategory}): ${f.judgeReasoning}`,
      14,
      y,
      { maxWidth: 182 }
    );
    y += 10;
  }

  doc.save(`agentarena-${run.id}.pdf`);
}
