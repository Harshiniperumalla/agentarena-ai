import { useCallback, useEffect, useState } from 'react';
import { AgentManagementPage } from './components/AgentManagementPage';
import { BenchmarkHistoryPage } from './components/BenchmarkHistoryPage';
import { LeaderboardPage } from './components/LeaderboardPage';
import { NewBenchmarkWizard } from './components/NewBenchmarkWizard';
import { OverviewPage } from './components/OverviewPage';
import { ResultsAnalyticsPage } from './components/ResultsAnalyticsPage';
import { SettingsPage } from './components/SettingsPage';
import { Sidebar, type NavSection } from './components/Sidebar';
import { TopBar } from './components/TopBar';
import { api } from './services/api';
import type {
  AgentConfig,
  BenchmarkRun,
  DataMode,
  DashboardOverview,
  ProviderInfo,
} from './types/benchmark';

export default function App() {
  const [section, setSection] = useState<NavSection>('overview');
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [mode, setMode] = useState<DataMode>('demo');

  const [dashboard, setDashboard] = useState<DashboardOverview | null>(null);
  const [loadingDashboard, setLoadingDashboard] = useState(true);
  const [providers, setProviders] = useState<ProviderInfo[]>([]);
  const [agents, setAgents] = useState<AgentConfig[]>([]);
  const [runs, setRuns] = useState<BenchmarkRun[]>([]);
  const [selectedRunId, setSelectedRunId] = useState<string | null>(null);

  const loadCoreData = useCallback(async (activeMode: DataMode) => {
    setLoadingDashboard(true);
    try {
      const [healthRes, dashRes, agentsRes, runsRes] = await Promise.all([
        api.getHealth(),
        api.getDashboard(activeMode),
        api.getAgents(false),
        api.getRuns(),
      ]);
      setProviders(healthRes.providers);
      setDashboard(dashRes);
      setAgents(agentsRes.agents);
      setRuns(runsRes.runs);
    } finally {
      setLoadingDashboard(false);
    }
  }, []);

  useEffect(() => {
    void loadCoreData(mode);
  }, [mode, loadCoreData]);

  const handleInspectRun = (runId: string) => {
    setSelectedRunId(runId);
    setSection('results');
  };

  const handleRunCompleted = async (runId: string) => {
    setMode('live');
    await loadCoreData('live');
    setSelectedRunId(runId);
    setSection('results');
  };

  return (
    <div className="flex min-h-screen bg-[#070B14] text-slate-100">
      <Sidebar
        active={section}
        onSelect={setSection}
        mobileOpen={mobileNavOpen}
        onCloseMobile={() => setMobileNavOpen(false)}
      />

      <div className="flex min-w-0 flex-1 flex-col">
        <TopBar
          activeSection={section}
          onOpenMobileNav={() => setMobileNavOpen(true)}
          onStartNewBenchmark={() => setSection('new-benchmark')}
        />

        <main className="mx-auto w-full max-w-7xl flex-1 px-4 py-6 sm:px-8">
          {section === 'overview' && (
            <OverviewPage
              data={dashboard}
              loading={loadingDashboard}
              mode={mode}
              onModeChange={setMode}
              onNavigateNewBenchmark={() => setSection('new-benchmark')}
              onInspectRun={handleInspectRun}
            />
          )}

          {section === 'new-benchmark' && (
            <NewBenchmarkWizard
              agents={agents}
              providers={providers}
              onRunCompleted={handleRunCompleted}
            />
          )}

          {section === 'agents' && (
            <AgentManagementPage
              agents={agents}
              providers={providers}
              onRefresh={() => loadCoreData(mode)}
            />
          )}

          {section === 'history' && (
            <BenchmarkHistoryPage runs={runs} onInspectRun={handleInspectRun} />
          )}

          {section === 'results' && (
            <ResultsAnalyticsPage
              runs={runs}
              selectedRunId={selectedRunId}
              onSelectRunId={setSelectedRunId}
            />
          )}

          {section === 'leaderboard' && (
            <LeaderboardPage
              mode={mode}
              onModeChange={setMode}
              onInspectRun={handleInspectRun}
            />
          )}

          {section === 'settings' && <SettingsPage providers={providers} />}
        </main>
      </div>
    </div>
  );
}
