import { useState } from 'react';
import { Bot, CheckCircle2, Plus, Trash2, Wrench } from 'lucide-react';
import { api } from '../services/api';
import type {
  AgentConfig,
  ProviderId,
  ProviderInfo,
  ToolName,
} from '../types/benchmark';

interface AgentManagementPageProps {
  agents: AgentConfig[];
  providers: ProviderInfo[];
  onRefresh: () => void;
}

const ALL_TOOLS: ToolName[] = [
  'lookup_order',
  'check_policy',
  'process_refund',
  'query_kb',
  'escalate_ticket',
  'run_diagnostics',
  'search_docs',
  'inspect_alert',
];

export function AgentManagementPage({
  agents,
  providers,
  onRefresh,
}: AgentManagementPageProps) {
  const [showCreate, setShowCreate] = useState(false);
  const [editingAgent, setEditingAgent] = useState<AgentConfig | null>(null);
  const [error, setError] = useState<string | null>(null);

  const liveAgents = agents.filter((a) => !a.isDemo);
  const providerMap = new Map(providers.map((p) => [p.id, p]));

  const handleDelete = async (id: string, name: string) => {
    setError(null);
    try {
      await api.deleteAgent(id);
      onRefresh();
    } catch (err) {
      setError(
        err instanceof Error ? err.message : `Could not delete agent ${name}.`
      );
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 rounded-xl border border-slate-800/80 bg-[#0D1426] p-6 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-lg font-semibold text-slate-100">
            Configured AI Agents & Provider Adapters
          </h2>
          <p className="mt-1 text-xs text-slate-400">
            Configure autonomous agent architectures, sandboxed tool permissions, and
            token pricing rates across Gemini, OpenAI, and Anthropic.
          </p>
        </div>

        <button
          type="button"
          onClick={() => {
            setEditingAgent(null);
            setShowCreate(true);
          }}
          className="inline-flex items-center gap-2 rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-500 whitespace-nowrap shrink-0"
        >
          <Plus className="h-4 w-4" />
          <span>Add Agent</span>
        </button>
      </div>

      {/* Server Provider Adapter Status */}
      <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
        {providers.map((p) => (
          <div
            key={p.id}
            className="rounded-xl border border-slate-800/80 bg-[#0D1426] p-4"
          >
            <div className="flex items-center justify-between">
              <span className="text-sm font-semibold text-slate-100">{p.name}</span>
              <span
                className={`text-xs font-medium ${
                  p.configured ? 'text-emerald-400' : 'text-amber-400'
                }`}
              >
                {p.configured ? 'Ready' : 'Env Key Missing'}
              </span>
            </div>
            <div className="mt-1 font-mono text-[11px] text-slate-400">
              Server var: {p.envVar}
            </div>
            <div className="mt-2 text-xs text-slate-500">
              Models: {p.supportedModels.map((m) => m.id).join(', ')}
            </div>
          </div>
        ))}
      </div>

      {error && (
        <div
          role="alert"
          className="rounded-lg border border-rose-500/40 bg-rose-950/30 px-4 py-3 text-sm text-rose-200"
        >
          {error}
        </div>
      )}

      {(showCreate || editingAgent) && (
        <AgentFormModal
          initial={editingAgent}
          providers={providers}
          onClose={() => {
            setShowCreate(false);
            setEditingAgent(null);
          }}
          onSaved={() => {
            setShowCreate(false);
            setEditingAgent(null);
            onRefresh();
          }}
        />
      )}

      {/* Agent Cards */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        {liveAgents.map((agent) => {
          const prov = providerMap.get(agent.provider);
          return (
            <div
              key={agent.id}
              className="flex flex-col justify-between rounded-xl border border-slate-800/80 bg-[#0D1426] p-5"
            >
              <div>
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-start gap-3">
                    <div className="mt-0.5 rounded-lg border border-slate-700 bg-slate-800/70 p-2 text-cyan-400">
                      <Bot className="h-4 w-4" aria-hidden="true" />
                    </div>
                    <div>
                      <h3 className="text-base font-semibold text-slate-100">
                        {agent.name}
                      </h3>
                      <div className="mt-0.5 text-xs text-slate-400">
                        {agent.provider.toUpperCase()} · {agent.modelId} ·{' '}
                        <span
                          className={
                            prov?.configured ? 'text-emerald-400' : 'text-amber-400'
                          }
                        >
                          {prov?.configured ? 'Connected' : 'Missing Key'}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => {
                        setShowCreate(false);
                        setEditingAgent(agent);
                      }}
                      className="rounded-lg border border-slate-700 px-3 py-1 text-xs font-medium text-slate-200 hover:bg-slate-800"
                    >
                      Configure
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDelete(agent.id, agent.name)}
                      aria-label={`Delete ${agent.name}`}
                      className="rounded-lg border border-slate-800 p-1.5 text-slate-400 hover:border-rose-500/40 hover:text-rose-400"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>

                <p className="mt-3 text-xs leading-relaxed text-slate-300">
                  {agent.description}
                </p>

                <div className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-1 border-t border-slate-800/70 pt-3 text-xs text-slate-400">
                  <span className="inline-flex items-center gap-1.5">
                    <Wrench className="h-3.5 w-3.5 text-slate-500" />
                    Tools ({agent.allowedTools.length}):{' '}
                    <span className="font-mono text-slate-300">
                      {agent.allowedTools.join(', ') || 'None (LLM-only)'}
                    </span>
                  </span>
                </div>
              </div>

              <div className="mt-3 flex items-center justify-between text-xs text-slate-500">
                <span className="font-mono">
                  Pricing:{' '}
                  {agent.inputCostPer1M !== null && agent.outputCostPer1M !== null
                    ? `$${agent.inputCostPer1M}/1M in · $${agent.outputCostPer1M}/1M out`
                    : 'Pricing unavailable'}
                </span>
                <span className="font-mono">Max steps: {agent.maxSteps}</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function AgentFormModal({
  initial,
  providers,
  onClose,
  onSaved,
}: {
  initial: AgentConfig | null;
  providers: ProviderInfo[];
  onClose: () => void;
  onSaved: () => void;
}) {
  const [name, setName] = useState(initial?.name || '');
  const [provider, setProvider] = useState<ProviderId>(initial?.provider || 'gemini');
  const [modelId, setModelId] = useState(
    initial?.modelId || 'gemini-4-hydrogen'
  );
  const [description, setDescription] = useState(initial?.description || '');
  const [systemPrompt, setSystemPrompt] = useState(
    initial?.systemPrompt ||
      'You are an autonomous enterprise agent. Always verify records via approved tools before making commitments.'
  );
  const [allowedTools, setAllowedTools] = useState<ToolName[]>(
    initial?.allowedTools || ['lookup_order', 'check_policy', 'query_kb']
  );
  const [inputCost, setInputCost] = useState<string>(
    initial?.inputCostPer1M !== null && initial?.inputCostPer1M !== undefined
      ? String(initial.inputCostPer1M)
      : '0.15'
  );
  const [outputCost, setOutputCost] = useState<string>(
    initial?.outputCostPer1M !== null && initial?.outputCostPer1M !== undefined
      ? String(initial.outputCostPer1M)
      : '0.60'
  );
  const [maxSteps, setMaxSteps] = useState(initial?.maxSteps || 4);
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const selectedProvider = providers.find((p) => p.id === provider);

  const handleProviderChange = (nextProv: ProviderId) => {
    setProvider(nextProv);
    const info = providers.find((p) => p.id === nextProv);
    if (info && info.supportedModels[0]) {
      setModelId(info.supportedModels[0].id);
      setInputCost(
        info.supportedModels[0].inputCostPer1M !== null
          ? String(info.supportedModels[0].inputCostPer1M)
          : ''
      );
      setOutputCost(
        info.supportedModels[0].outputCostPer1M !== null
          ? String(info.supportedModels[0].outputCostPer1M)
          : ''
      );
    }
  };

  const toggleTool = (t: ToolName) => {
    setAllowedTools((prev) =>
      prev.includes(t) ? prev.filter((item) => item !== t) : [...prev, t]
    );
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !modelId.trim()) {
      setErr('Agent name and model identifier are required.');
      return;
    }
    setSaving(true);
    setErr(null);
    try {
      const payload = {
        name: name.trim(),
        provider,
        modelId: modelId.trim(),
        description: description.trim(),
        systemPrompt: systemPrompt.trim(),
        allowedTools,
        supportsTools: allowedTools.length > 0,
        inputCostPer1M: inputCost.trim() === '' ? null : Number(inputCost),
        outputCostPer1M: outputCost.trim() === '' ? null : Number(outputCost),
        maxSteps,
      };
      if (initial) {
        await api.updateAgent(initial.id, payload);
      } else {
        await api.createAgent(payload);
      }
      onSaved();
    } catch (error) {
      setErr(error instanceof Error ? error.message : 'Failed to save agent.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="rounded-xl border border-blue-500/40 bg-[#0D1426] p-6 space-y-4"
    >
      <div className="flex items-center justify-between">
        <h3 className="text-base font-semibold text-slate-100">
          {initial ? `Configure ${initial.name}` : 'Register New AI Agent'}
        </h3>
        <button
          type="button"
          onClick={onClose}
          className="text-xs text-slate-400 hover:text-slate-200"
        >
          Cancel
        </button>
      </div>

      {err && <div className="text-xs text-rose-400">{err}</div>}

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <div>
          <label className="block text-xs text-slate-300">Agent Name</label>
          <input
            type="text"
            required
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="e.g. Gemini Hydrogen Concierge"
            className="mt-1 w-full rounded-lg border border-slate-700 bg-[#070B14] px-3 py-2 text-sm text-slate-100"
          />
        </div>
        <div>
          <label className="block text-xs text-slate-300">Provider Adapter</label>
          <select
            value={provider}
            onChange={(e) => handleProviderChange(e.target.value as ProviderId)}
            className="mt-1 w-full rounded-lg border border-slate-700 bg-[#070B14] px-3 py-2 text-sm text-slate-100"
          >
            {providers.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-xs text-slate-300">Model Identifier</label>
          <select
            value={modelId}
            onChange={(e) => setModelId(e.target.value)}
            className="mt-1 w-full rounded-lg border border-slate-700 bg-[#070B14] px-3 py-2 text-sm text-slate-100"
          >
            {(selectedProvider?.supportedModels || []).map((m) => (
              <option key={m.id} value={m.id}>
                {m.label} ({m.id})
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <div>
          <label className="block text-xs text-slate-300">
            Input Cost ($ per 1M tokens)
          </label>
          <input
            type="number"
            step="0.001"
            value={inputCost}
            onChange={(e) => setInputCost(e.target.value)}
            placeholder="Leave blank if unknown"
            className="mt-1 w-full rounded-lg border border-slate-700 bg-[#070B14] px-3 py-2 font-mono text-sm text-slate-100"
          />
        </div>
        <div>
          <label className="block text-xs text-slate-300">
            Output Cost ($ per 1M tokens)
          </label>
          <input
            type="number"
            step="0.001"
            value={outputCost}
            onChange={(e) => setOutputCost(e.target.value)}
            placeholder="Leave blank if unknown"
            className="mt-1 w-full rounded-lg border border-slate-700 bg-[#070B14] px-3 py-2 font-mono text-sm text-slate-100"
          />
        </div>
        <div>
          <label className="block text-xs text-slate-300">Max Tool Steps</label>
          <input
            type="number"
            min={1}
            max={5}
            value={maxSteps}
            onChange={(e) => setMaxSteps(Number(e.target.value))}
            className="mt-1 w-full rounded-lg border border-slate-700 bg-[#070B14] px-3 py-2 font-mono text-sm text-slate-100"
          />
        </div>
      </div>

      <div>
        <label className="block text-xs text-slate-300">Description</label>
        <input
          type="text"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          className="mt-1 w-full rounded-lg border border-slate-700 bg-[#070B14] px-3 py-2 text-sm text-slate-100"
        />
      </div>

      <div>
        <label className="block text-xs text-slate-300">System Prompt</label>
        <textarea
          rows={3}
          value={systemPrompt}
          onChange={(e) => setSystemPrompt(e.target.value)}
          className="mt-1 w-full rounded-lg border border-slate-700 bg-[#070B14] px-3 py-2 text-sm text-slate-100"
        />
      </div>

      <div>
        <div className="mb-2 text-xs font-medium text-slate-300">
          Approved Sandboxed Tool Permissions
        </div>
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
          {ALL_TOOLS.map((tool) => (
            <label
              key={tool}
              className="flex cursor-pointer items-center gap-2 rounded-md border border-slate-800 bg-[#070B14] px-2.5 py-1.5 font-mono text-xs text-slate-300"
            >
              <input
                type="checkbox"
                checked={allowedTools.includes(tool)}
                onChange={() => toggleTool(tool)}
                className="accent-cyan-400"
              />
              <span className="truncate">{tool}</span>
            </label>
          ))}
        </div>
      </div>

      <div className="flex justify-end gap-3 pt-2">
        <button
          type="button"
          onClick={onClose}
          className="rounded-lg border border-slate-700 px-4 py-2 text-xs font-medium text-slate-300"
        >
          Cancel
        </button>
        <button
          type="submit"
          disabled={saving}
          className="inline-flex items-center gap-1.5 rounded-lg bg-blue-600 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-500"
        >
          <CheckCircle2 className="h-3.5 w-3.5" />
          <span>{saving ? 'Saving...' : 'Save Agent'}</span>
        </button>
      </div>
    </form>
  );
}
