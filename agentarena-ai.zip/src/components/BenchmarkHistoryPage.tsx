import { useState } from 'react';
import { ArrowRight, Search } from 'lucide-react';
import type { BenchmarkRun } from '../types/benchmark';

interface BenchmarkHistoryPageProps {
  runs: BenchmarkRun[];
  onInspectRun: (runId: string) => void;
}

export function BenchmarkHistoryPage({
  runs,
  onInspectRun,
}: BenchmarkHistoryPageProps) {
  const [search, setSearch] = useState('');
  const [modeFilter, setModeFilter] = useState<'all' | 'live' | 'demo'>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('All');

  const filtered = runs.filter((run) => {
    if (modeFilter === 'live' && run.isDemo) return false;
    if (modeFilter === 'demo' && !run.isDemo) return false;
    if (categoryFilter !== 'All' && run.category !== categoryFilter) return false;
    if (
      search.trim() &&
      !run.suiteName.toLowerCase().includes(search.toLowerCase()) &&
      !run.id.toLowerCase().includes(search.toLowerCase())
    ) {
      return false;
    }
    return true;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 rounded-xl border border-slate-800/80 bg-[#0D1426] p-5 lg:flex-row lg:items-center lg:justify-between">
        <div className="relative w-full max-w-sm">
          <Search
            className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500"
            aria-hidden="true"
          />
          <input
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Filter by suite name or run ID..."
            aria-label="Filter benchmark runs"
            className="w-full rounded-lg border border-slate-700/80 bg-[#070B14] py-2 pl-9 pr-3 text-sm text-slate-100 placeholder:text-slate-500 focus:border-blue-500 focus:outline-none"
          />
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div
            role="group"
            aria-label="Filter by data source"
            className="inline-flex rounded-lg border border-slate-800 bg-[#070B14] p-1"
          >
            {(['all', 'live', 'demo'] as const).map((m) => (
              <button
                key={m}
                type="button"
                onClick={() => setModeFilter(m)}
                className={`rounded-md px-3 py-1 text-xs font-medium capitalize transition-colors ${
                  modeFilter === m
                    ? 'bg-blue-600 text-white'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {m === 'all' ? 'All Runs' : m === 'live' ? 'Live Only' : 'Demo Sample'}
              </button>
            ))}
          </div>

          <select
            aria-label="Filter by category"
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="rounded-lg border border-slate-700/80 bg-[#070B14] px-3 py-1.5 text-xs text-slate-200"
          >
            <option value="All">All Categories</option>
            <option value="Customer Support">Customer Support</option>
            <option value="Software Development">Software Development</option>
            <option value="Research">Research</option>
            <option value="E-commerce">E-commerce</option>
            <option value="Cybersecurity">Cybersecurity</option>
          </select>
        </div>
      </div>

      <div className="rounded-xl border border-slate-800/80 bg-[#0D1426]">
        {filtered.length === 0 ? (
          <div className="p-10 text-center text-sm text-slate-400">
            No benchmark runs match the current filters.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="border-b border-slate-800 text-xs text-slate-400">
                  <th className="px-6 py-3 font-medium">Run / Suite</th>
                  <th className="px-4 py-3 font-medium">Category</th>
                  <th className="px-4 py-3 font-medium">Source</th>
                  <th className="px-4 py-3 font-medium">Status</th>
                  <th className="px-4 py-3 text-right font-medium">Progress</th>
                  <th className="px-4 py-3 text-right font-medium">Leading Agent</th>
                  <th className="px-6 py-3 text-right font-medium">Inspect</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filtered.map((run) => {
                  const leader = run.summaries?.[0];
                  return (
                    <tr key={run.id} className="hover:bg-slate-800/35">
                      <td className="px-6 py-3.5">
                        <div className="font-medium text-slate-100">
                          {run.suiteName}
                        </div>
                        <div className="font-mono text-[11px] text-slate-500">
                          {run.id} · {run.suiteVersion} ·{' '}
                          {new Date(run.startedAt).toLocaleString()}
                        </div>
                      </td>
                      <td className="px-4 py-3.5 text-xs text-slate-300">
                        {run.category}
                      </td>
                      <td className="px-4 py-3.5 text-xs">
                        <span
                          className={
                            run.isDemo ? 'text-violet-400' : 'text-blue-400'
                          }
                        >
                          {run.isDemo ? 'Demo Sample' : 'Live Run'}
                        </span>
                      </td>
                      <td className="px-4 py-3.5 text-xs capitalize">
                        <span
                          className={
                            run.status === 'completed'
                              ? 'text-emerald-400'
                              : run.status === 'running'
                                ? 'text-cyan-400'
                                : 'text-rose-400'
                          }
                        >
                          {run.status}
                        </span>
                      </td>
                      <td className="px-4 py-3.5 text-right font-mono text-xs text-slate-300">
                        {run.completedTasks}/{run.totalTasks}
                      </td>
                      <td className="px-4 py-3.5 text-right text-xs text-slate-200">
                        {leader
                          ? `${leader.agentName} (${leader.overallScore})`
                          : '—'}
                      </td>
                      <td className="px-6 py-3.5 text-right">
                        <button
                          type="button"
                          onClick={() => onInspectRun(run.id)}
                          className="inline-flex items-center gap-1 text-xs font-medium text-cyan-400 hover:text-cyan-300 whitespace-nowrap"
                        >
                          <span>Analyze</span>
                          <ArrowRight className="h-3.5 w-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
