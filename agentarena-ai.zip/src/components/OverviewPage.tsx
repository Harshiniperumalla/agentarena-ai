import { ArrowRight, Play, ShieldCheck, Sparkles } from 'lucide-react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import type { BenchmarkRun, DataMode, DashboardOverview } from '../types/benchmark';

interface OverviewPageProps {
  data: DashboardOverview | null;
  loading: boolean;
  mode: DataMode;
  onModeChange: (mode: DataMode) => void;
  onNavigateNewBenchmark: () => void;
  onInspectRun: (runId: string) => void;
}

export function OverviewPage({
  data,
  loading,
  mode,
  onModeChange,
  onNavigateNewBenchmark,
  onInspectRun,
}: OverviewPageProps) {
  const topAgents = data?.topAgents || [];
  const recentRuns: BenchmarkRun[] = data?.recentRuns || [];
  const leader = topAgents[0];

  const chartData = topAgents.map((a) => ({
    name: a.agentName.replace(' (Sample)', ''),
    Overall: a.overallScore,
    Completion: a.taskCompletionRate,
    Accuracy: a.accuracyScore,
    Reliability: a.reliabilityScore,
  }));

  return (
    <div className="space-y-8">
      {/* Hero Banner & Mode Switcher */}
      <div className="flex flex-col gap-5 rounded-xl border border-slate-800/90 bg-[#0D1426] p-6 lg:flex-row lg:items-center lg:justify-between">
        <div className="max-w-2xl space-y-2">
          <p className="text-xs font-medium text-cyan-400">
            Autonomous AI Agent Evaluation Platform
          </p>
          <h2 className="text-2xl font-bold tracking-tight text-slate-50 sm:text-3xl">
            Don't Just Trust the Agent. Test It.
          </h2>
          <p className="text-sm leading-relaxed text-slate-300">
            Evaluate competing AI agents across identical standardized tasks—measuring
            accuracy, task completion, tool usage, latency, execution cost, and
            reliability before deploying to production.
          </p>
        </div>

        <div className="flex flex-col items-start gap-3 sm:items-end shrink-0">
          <div
            role="group"
            aria-label="Data Mode Selector"
            className="inline-flex items-center rounded-lg border border-slate-800 bg-[#070B14] p-1"
          >
            <button
              type="button"
              onClick={() => onModeChange('demo')}
              className={`rounded-md px-3.5 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                mode === 'demo'
                  ? 'bg-violet-600/90 text-white'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Demo Sample Data
            </button>
            <button
              type="button"
              onClick={() => onModeChange('live')}
              className={`rounded-md px-3.5 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                mode === 'live'
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Live Executions
            </button>
          </div>
          <p className="text-xs text-slate-400">
            {mode === 'demo'
              ? 'Viewing labelled sample Customer Support data (20 scenarios).'
              : 'Viewing persisted live benchmark runs executed via configured APIs.'}
          </p>
        </div>
      </div>

      {/* Explicit Mode Separation Banner */}
      {mode === 'demo' ? (
        <div className="flex flex-col gap-3 rounded-lg border border-violet-500/30 bg-violet-950/25 px-4 py-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-2.5 text-xs text-violet-200">
            <Sparkles className="h-4 w-4 shrink-0 text-violet-400" aria-hidden="true" />
            <span>
              <strong>Demo Mode Active:</strong> Metrics below come from the pre-loaded
              20-scenario Customer Support sample dataset and are strictly separated from
              live execution benchmarks.
            </span>
          </div>
          <button
            type="button"
            onClick={onNavigateNewBenchmark}
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-cyan-300 hover:text-cyan-200 whitespace-nowrap shrink-0"
          >
            <span>Run a Live Benchmark</span>
            <ArrowRight className="h-3.5 w-3.5" />
          </button>
        </div>
      ) : (
        <div className="flex items-center gap-2.5 rounded-lg border border-blue-500/30 bg-blue-950/20 px-4 py-3 text-xs text-blue-200">
          <ShieldCheck className="h-4 w-4 shrink-0 text-blue-400" aria-hidden="true" />
          <span>
            <strong>Live Mode Active:</strong> Only verified executions stored in the
            database are displayed below.
          </span>
        </div>
      )}

      {/* KPI Strip */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-5">
        <div className="rounded-xl border border-slate-800/80 bg-[#0D1426] p-5">
          <div className="text-xs text-slate-400">Total Benchmark Runs</div>
          <div className="mt-2 font-mono text-2xl font-bold text-slate-50">
            {loading ? '—' : data?.totalRuns ?? 0}
          </div>
          <div className="mt-1 text-xs text-slate-500">
            {mode === 'demo' ? 'Sample suite runs' : 'Live recorded runs'}
          </div>
        </div>

        <div className="rounded-xl border border-slate-800/80 bg-[#0D1426] p-5">
          <div className="text-xs text-slate-400">Agents Tested</div>
          <div className="mt-2 font-mono text-2xl font-bold text-slate-50">
            {loading ? '—' : data?.agentsTested ?? 0}
          </div>
          <div className="mt-1 text-xs text-slate-500">Distinct configurations</div>
        </div>

        <div className="rounded-xl border border-slate-800/80 bg-[#0D1426] p-5">
          <div className="text-xs text-slate-400">Avg Task Completion</div>
          <div className="mt-2 font-mono text-2xl font-bold text-cyan-300">
            {loading ? '—' : `${data?.avgTaskCompletionRate ?? 0}%`}
          </div>
          <div className="mt-1 text-xs text-slate-500">Verified outcomes</div>
        </div>

        <div className="rounded-xl border border-slate-800/80 bg-[#0D1426] p-5">
          <div className="text-xs text-slate-400">Avg Response Latency</div>
          <div className="mt-2 font-mono text-2xl font-bold text-slate-50">
            {loading ? '—' : `${((data?.avgLatencyMs ?? 0) / 1000).toFixed(2)}s`}
          </div>
          <div className="mt-1 text-xs text-slate-500">End-to-end execution</div>
        </div>

        <div className="rounded-xl border border-slate-800/80 bg-[#0D1426] p-5">
          <div className="text-xs text-slate-400">Total Execution Cost</div>
          <div className="mt-2 font-mono text-2xl font-bold text-slate-50">
            {loading
              ? '—'
              : data?.totalCostUsd !== null && data?.totalCostUsd !== undefined
                ? `$${data.totalCostUsd.toFixed(4)}`
                : 'Unavailable'}
          </div>
          <div className="mt-1 text-xs text-slate-500">From provider token usage</div>
        </div>
      </div>

      {/* Empty State for Live Mode when no live runs exist yet */}
      {!loading && recentRuns.length === 0 ? (
        <div className="rounded-xl border border-slate-800/90 bg-[#0D1426] p-10 text-center">
          <h3 className="text-lg font-semibold text-slate-100">
            No Live Benchmark Runs Recorded Yet
          </h3>
          <p className="mx-auto mt-2 max-w-lg text-sm text-slate-400">
            Live Mode never displays simulated results. Launch a standardized benchmark
            against configured AI agents to capture real latency, token usage, tool
            traces, and independent evaluation scores, or switch to Demo Sample Data
            above to explore the 20-scenario Customer Support showcase.
          </p>
          <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
            <button
              type="button"
              onClick={onNavigateNewBenchmark}
              className="inline-flex items-center gap-2 rounded-lg bg-blue-600 px-4 py-2.5 text-sm font-medium text-white hover:bg-blue-500 whitespace-nowrap"
            >
              <Play className="h-4 w-4" aria-hidden="true" />
              <span>Launch First Live Benchmark</span>
            </button>
            <button
              type="button"
              onClick={() => onModeChange('demo')}
              className="rounded-lg border border-slate-700 px-4 py-2.5 text-sm font-medium text-slate-200 hover:bg-slate-800 whitespace-nowrap"
            >
              Inspect Demo Sample Data
            </button>
          </div>
        </div>
      ) : (
        <>
          {/* Performance Comparison Chart & Top Performing Agent */}
          <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
            <div className="rounded-xl border border-slate-800/80 bg-[#0D1426] p-6 lg:col-span-2">
              <div className="mb-4 flex items-center justify-between gap-4">
                <div>
                  <h3 className="text-base font-semibold text-slate-100">
                    Latest Benchmark Agent Comparison
                  </h3>
                  <p className="text-xs text-slate-400">
                    {recentRuns[0]?.suiteName || 'Selected suite'} · Overall, Completion,
                    Accuracy, and Reliability (0–100)
                  </p>
                </div>
                {recentRuns[0] && (
                  <button
                    type="button"
                    onClick={() => onInspectRun(recentRuns[0].id)}
                    className="text-xs font-medium text-cyan-400 hover:text-cyan-300 whitespace-nowrap shrink-0"
                  >
                    Inspect Full Results
                  </button>
                )}
              </div>

              <div className="h-80 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={chartData}
                    margin={{ top: 10, right: 16, left: -12, bottom: 16 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" />
                    <XAxis
                      dataKey="name"
                      tick={{ fill: '#94A3B8', fontSize: 12 }}
                      axisLine={{ stroke: '#334155' }}
                    />
                    <YAxis
                      domain={[0, 100]}
                      tick={{ fill: '#94A3B8', fontSize: 12 }}
                      axisLine={{ stroke: '#334155' }}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#0B1120',
                        borderColor: '#334155',
                        borderRadius: '8px',
                        color: '#F1F5F9',
                        fontSize: '12px',
                      }}
                    />
                    <Legend wrapperStyle={{ fontSize: '12px', color: '#CBD5E1' }} />
                    <Bar dataKey="Overall" fill="#3B82F6" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="Completion" fill="#06B6D4" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="Accuracy" fill="#8B5CF6" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="Reliability" fill="#10B981" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="flex flex-col justify-between rounded-xl border border-slate-800/80 bg-[#0D1426] p-6">
              <div>
                <div className="text-xs font-medium text-cyan-400">
                  Top-Performing Agent
                </div>
                {leader ? (
                  <>
                    <h3 className="mt-2 text-xl font-bold text-slate-50">
                      {leader.agentName}
                    </h3>
                    <p className="mt-1 text-xs text-slate-400">
                      {leader.provider.toUpperCase()} · {leader.modelId}
                    </p>

                    <div className="mt-5 grid grid-cols-2 gap-3 border-y border-slate-800/80 py-4">
                      <div>
                        <div className="text-[11px] text-slate-400">Overall Score</div>
                        <div className="font-mono text-xl font-bold text-blue-400">
                          {leader.overallScore}/100
                        </div>
                      </div>
                      <div>
                        <div className="text-[11px] text-slate-400">Task Completion</div>
                        <div className="font-mono text-xl font-bold text-slate-100">
                          {leader.taskCompletionRate}%
                        </div>
                      </div>
                      <div>
                        <div className="text-[11px] text-slate-400">Avg Latency</div>
                        <div className="font-mono text-base font-semibold text-slate-200">
                          {(leader.avgLatencyMs / 1000).toFixed(2)}s
                        </div>
                      </div>
                      <div>
                        <div className="text-[11px] text-slate-400">Cost / Task</div>
                        <div className="font-mono text-base font-semibold text-slate-200">
                          {leader.avgCostPerTaskUsd !== null
                            ? `$${leader.avgCostPerTaskUsd.toFixed(4)}`
                            : 'Unavailable'}
                        </div>
                      </div>
                    </div>

                    <p className="mt-4 text-xs leading-relaxed text-slate-300">
                      {leader.rankExplanation}
                    </p>
                  </>
                ) : (
                  <p className="mt-3 text-sm text-slate-400">
                    Run a benchmark to identify the leading agent.
                  </p>
                )}
              </div>

              {recentRuns[0] && (
                <button
                  type="button"
                  onClick={() => onInspectRun(recentRuns[0].id)}
                  className="mt-6 inline-flex w-full items-center justify-center gap-2 rounded-lg border border-blue-500/40 bg-blue-500/10 px-4 py-2 text-xs font-medium text-blue-300 hover:bg-blue-500/20 whitespace-nowrap"
                >
                  <span>Open Detailed Trace & Failures</span>
                  <ArrowRight className="h-3.5 w-3.5" />
                </button>
              )}
            </div>
          </div>

          {/* Recent Benchmark Runs Grid */}
          <div className="rounded-xl border border-slate-800/80 bg-[#0D1426]">
            <div className="flex items-center justify-between border-b border-slate-800/80 px-6 py-4">
              <div>
                <h3 className="text-base font-semibold text-slate-100">
                  Recent Benchmark Runs
                </h3>
                <p className="text-xs text-slate-400">
                  Click any run to inspect metrics, failure analysis, and execution traces.
                </p>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="border-b border-slate-800/80 text-xs text-slate-400">
                    <th className="px-6 py-3 font-medium">Benchmark Suite</th>
                    <th className="px-4 py-3 font-medium">Category</th>
                    <th className="px-4 py-3 font-medium">Status</th>
                    <th className="px-4 py-3 text-right font-medium">Executions</th>
                    <th className="px-4 py-3 text-right font-medium">Top Agent</th>
                    <th className="px-6 py-3 text-right font-medium">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {recentRuns.map((run) => {
                    const top = run.summaries?.[0];
                    return (
                      <tr
                        key={run.id}
                        className="transition-colors hover:bg-slate-800/35"
                      >
                        <td className="px-6 py-3.5">
                          <div className="font-medium text-slate-100">
                            {run.suiteName}
                          </div>
                          <div className="text-xs text-slate-400">
                            {run.isDemo ? 'Demo Sample' : 'Live Run'} · {run.suiteVersion} ·{' '}
                            {new Date(run.startedAt).toLocaleString()}
                          </div>
                        </td>
                        <td className="px-4 py-3.5 text-xs text-slate-300">
                          {run.category}
                        </td>
                        <td className="px-4 py-3.5 text-xs">
                          <span
                            className={
                              run.status === 'completed'
                                ? 'text-emerald-400'
                                : run.status === 'running'
                                  ? 'text-cyan-400'
                                  : 'text-rose-400'
                            }
                          >
                            {run.status.charAt(0).toUpperCase() + run.status.slice(1)}
                          </span>
                        </td>
                        <td className="px-4 py-3.5 text-right font-mono text-xs text-slate-300">
                          {run.completedTasks}/{run.totalTasks}
                        </td>
                        <td className="px-4 py-3.5 text-right text-xs text-slate-200">
                          {top
                            ? `${top.agentName} (${top.overallScore})`
                            : '—'}
                        </td>
                        <td className="px-6 py-3.5 text-right">
                          <button
                            type="button"
                            onClick={() => onInspectRun(run.id)}
                            className="text-xs font-medium text-blue-400 hover:text-blue-300 whitespace-nowrap"
                          >
                            View Results
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
