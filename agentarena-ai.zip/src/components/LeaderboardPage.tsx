import { useEffect, useState } from 'react';
import { Info } from 'lucide-react';
import { api } from '../services/api';
import type { DataMode, HistoricalRanking } from '../types/benchmark';

interface LeaderboardPageProps {
  mode: DataMode;
  onModeChange: (mode: DataMode) => void;
  onInspectRun: (runId: string) => void;
}

type SortBy = 'overall' | 'completion' | 'reliability' | 'cost';

export function LeaderboardPage({
  mode,
  onModeChange,
  onInspectRun,
}: LeaderboardPageProps) {
  const [category, setCategory] = useState<string>('All');
  const [sortBy, setSortBy] = useState<SortBy>('overall');
  const [rankings, setRankings] = useState<HistoricalRanking[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    api
      .getLeaderboard(mode, category)
      .then((res) => {
        if (!cancelled) setRankings(res.rankings);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [mode, category]);

  const sorted = [...rankings].sort((a, b) => {
    if (sortBy === 'completion') return b.taskCompletionRate - a.taskCompletionRate;
    if (sortBy === 'reliability') return b.reliabilityScore - a.reliabilityScore;
    if (sortBy === 'cost') {
      return (b.costEfficiencyScore ?? -1) - (a.costEfficiencyScore ?? -1);
    }
    return b.overallScore - a.overallScore;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 rounded-xl border border-slate-800/80 bg-[#0D1426] p-5 lg:flex-row lg:items-center lg:justify-between">
        <div>
          <h2 className="text-base font-semibold text-slate-100">
            Agent Benchmark Leaderboard
          </h2>
          <p className="mt-1 text-xs text-slate-400">
            Rankings grouped by benchmark suite version and test count so incomparable
            test suites are never blended blindly.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div
            role="group"
            aria-label="Leaderboard Data Mode"
            className="inline-flex rounded-lg border border-slate-800 bg-[#070B14] p-1"
          >
            <button
              type="button"
              onClick={() => onModeChange('demo')}
              className={`rounded-md px-3 py-1 text-xs font-medium ${
                mode === 'demo'
                  ? 'bg-violet-600 text-white'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Demo Sample
            </button>
            <button
              type="button"
              onClick={() => onModeChange('live')}
              className={`rounded-md px-3 py-1 text-xs font-medium ${
                mode === 'live'
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Live Runs
            </button>
          </div>

          <select
            aria-label="Leaderboard Category"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="rounded-lg border border-slate-700 bg-[#070B14] px-3 py-1.5 text-xs text-slate-200"
          >
            <option value="All">All Categories</option>
            <option value="Customer Support">Customer Support</option>
            <option value="Software Development">Software Development</option>
            <option value="Research">Research</option>
            <option value="E-commerce">E-commerce</option>
            <option value="Cybersecurity">Cybersecurity</option>
          </select>

          <select
            aria-label="Sort leaderboard by"
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as SortBy)}
            className="rounded-lg border border-slate-700 bg-[#070B14] px-3 py-1.5 text-xs text-slate-200"
          >
            <option value="overall">Overall Score</option>
            <option value="completion">Task Completion</option>
            <option value="reliability">Reliability</option>
            <option value="cost">Cost Efficiency</option>
          </select>
        </div>
      </div>

      <div className="flex items-center gap-2 rounded-lg border border-slate-800 bg-[#0D1426] px-4 py-2.5 text-xs text-slate-300">
        <Info className="h-4 w-4 shrink-0 text-cyan-400" />
        <span>
          Each row lists the exact benchmark suite version, test count, and timestamp.
          Compare agents directly only within matching suite versions.
        </span>
      </div>

      <div className="rounded-xl border border-slate-800/80 bg-[#0D1426]">
        {loading ? (
          <div className="p-10 text-center text-sm text-slate-400">
            Loading leaderboard...
          </div>
        ) : sorted.length === 0 ? (
          <div className="p-10 text-center text-sm text-slate-400">
            No {mode === 'live' ? 'live' : 'demo'} rankings recorded for this filter yet.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="border-b border-slate-800 text-xs text-slate-400">
                  <th className="px-6 py-3 font-medium">#</th>
                  <th className="px-4 py-3 font-medium">Agent & Model</th>
                  <th className="px-4 py-3 font-medium">Suite & Version</th>
                  <th className="px-4 py-3 text-right font-medium">Tests</th>
                  <th className="px-4 py-3 text-right font-medium">Overall</th>
                  <th className="px-4 py-3 text-right font-medium">Completion</th>
                  <th className="px-4 py-3 text-right font-medium">Reliability</th>
                  <th className="px-4 py-3 text-right font-medium">Avg Cost</th>
                  <th className="px-6 py-3 text-right font-medium">Last Run</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {sorted.map((row, idx) => (
                  <tr key={row.id} className="hover:bg-slate-800/30">
                    <td className="px-6 py-3.5 font-mono text-xs font-bold text-cyan-400">
                      #{idx + 1}
                    </td>
                    <td className="px-4 py-3.5">
                      <div className="font-medium text-slate-100">{row.agentName}</div>
                      <div className="text-xs text-slate-400">
                        {row.provider.toUpperCase()} · {row.modelId}
                      </div>
                    </td>
                    <td className="px-4 py-3.5">
                      <button
                        type="button"
                        onClick={() => onInspectRun(row.runId)}
                        className="text-left text-xs font-medium text-blue-400 hover:text-blue-300"
                      >
                        {row.suiteName}
                      </button>
                      <div className="text-[11px] text-slate-500">
                        {row.category} · {row.suiteVersion} ·{' '}
                        {row.isDemo ? 'Demo Sample' : 'Live'}
                      </div>
                    </td>
                    <td className="px-4 py-3.5 text-right font-mono text-xs text-slate-300">
                      {row.testCount}
                    </td>
                    <td className="px-4 py-3.5 text-right font-mono font-bold text-blue-400">
                      {row.overallScore}
                    </td>
                    <td className="px-4 py-3.5 text-right font-mono text-slate-200">
                      {row.taskCompletionRate}%
                    </td>
                    <td className="px-4 py-3.5 text-right font-mono text-slate-200">
                      {row.reliabilityScore}%
                    </td>
                    <td className="px-4 py-3.5 text-right font-mono text-xs text-slate-300">
                      {row.avgCostPerTaskUsd !== null
                        ? `$${row.avgCostPerTaskUsd.toFixed(4)}`
                        : 'Unavailable'}
                    </td>
                    <td className="px-6 py-3.5 text-right font-mono text-xs text-slate-400">
                      {new Date(row.recordedAt).toLocaleDateString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
