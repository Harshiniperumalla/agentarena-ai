import { useEffect, useState } from 'react';
import {
  AlertTriangle,
  Award,
  CheckCircle2,
  Clock,
  Download,
  FileText,
  Sparkles,
  Terminal,
  X,
} from 'lucide-react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  PolarAngleAxis,
  PolarGrid,
  PolarRadiusAxis,
  Radar,
  RadarChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { api, exportRunPdf } from '../services/api';
import type {
  AgentExecution,
  BenchmarkRun,
  DifficultyLevel,
  EvaluationResult,
  RecommendationPriority,
  TestCase,
} from '../types/benchmark';
import { recommendAgent } from '../utils/scoring';

interface ResultsAnalyticsPageProps {
  runs: BenchmarkRun[];
  selectedRunId: string | null;
  onSelectRunId: (id: string) => void;
}

const COLORS = ['#3B82F6', '#06B6D4', '#8B5CF6', '#10B981'];

export function ResultsAnalyticsPage({
  runs,
  selectedRunId,
  onSelectRunId,
}: ResultsAnalyticsPageProps) {
  const [runDetail, setRunDetail] = useState<BenchmarkRun | null>(null);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<'overview' | 'failures' | 'executions'>(
    'overview'
  );
  const [priority, setPriority] = useState<RecommendationPriority>('balanced');
  const [agentFilter, setAgentFilter] = useState<string>('all');
  const [difficultyFilter, setDifficultyFilter] = useState<DifficultyLevel | 'all'>('all');
  const [traceExec, setTraceExec] = useState<AgentExecution | null>(null);

  const effectiveRunId = selectedRunId || runs[0]?.id || null;

  useEffect(() => {
    if (!effectiveRunId) {
      setRunDetail(null);
      return;
    }
    let cancelled = false;
    setLoading(true);
    api
      .getRun(effectiveRunId)
      .then(({ run }) => {
        if (!cancelled) setRunDetail(run);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [effectiveRunId]);

  if (runs.length === 0) {
    return (
      <div className="rounded-xl border border-slate-800/80 bg-[#0D1426] p-10 text-center text-sm text-slate-400">
        No benchmark runs available yet. Launch a benchmark to analyze results.
      </div>
    );
  }

  const summaries = runDetail?.summaries || [];
  const executions = runDetail?.executions || [];
  const evaluations = runDetail?.evaluations || [];
  const testCases = runDetail?.testCases || [];

  const tcMap = new Map<string, TestCase>(testCases.map((t) => [t.id, t]));
  const evalMap = new Map<string, EvaluationResult>(
    evaluations.map((e) => [e.executionId, e])
  );

  const recommendation = recommendAgent(summaries, priority);

  const barData = summaries.map((s) => ({
    name: s.agentName.replace(' (Sample)', ''),
    Overall: s.overallScore,
    Completion: s.taskCompletionRate,
    Accuracy: s.accuracyScore,
    Reliability: s.reliabilityScore,
  }));

  const latencyCostData = summaries.map((s) => ({
    name: s.agentName.replace(' (Sample)', ''),
    LatencyMs: s.avgLatencyMs,
    CostMillicents:
      s.avgCostPerTaskUsd !== null ? Math.round(s.avgCostPerTaskUsd * 10000) : 0,
  }));

  const radarDimensions = [
    'Completion',
    'Accuracy',
    'Reliability',
    'Latency Eff.',
    'Cost Eff.',
  ];
  const radarData = radarDimensions.map((dim) => {
    const row: Record<string, string | number> = { metric: dim };
    summaries.forEach((s) => {
      const key = s.agentName.replace(' (Sample)', '');
      if (dim === 'Completion') row[key] = s.taskCompletionRate;
      else if (dim === 'Accuracy') row[key] = s.accuracyScore;
      else if (dim === 'Reliability') row[key] = s.reliabilityScore;
      else if (dim === 'Latency Eff.') row[key] = s.latencyEfficiencyScore;
      else row[key] = s.costEfficiencyScore ?? 0;
    });
    return row;
  });

  const filteredExecutions = executions.filter((ex) => {
    if (agentFilter !== 'all' && ex.agentId !== agentFilter) return false;
    const tc = tcMap.get(ex.testCaseId);
    if (difficultyFilter !== 'all' && tc?.difficulty !== difficultyFilter) return false;
    return true;
  });

  const failedExecutions = filteredExecutions.filter((ex) => {
    const ev = evalMap.get(ex.id);
    return !ev?.taskCompleted || ex.status !== 'completed';
  });

  return (
    <div className="space-y-6">
      {/* Run Selector & Export Toolbar */}
      <div className="flex flex-col gap-4 rounded-xl border border-slate-800/80 bg-[#0D1426] p-5 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:gap-4 min-w-0">
          <label
            htmlFor="results-run-select"
            className="text-xs font-medium text-slate-400 whitespace-nowrap"
          >
            Benchmark Run
          </label>
          <select
            id="results-run-select"
            value={effectiveRunId || ''}
            onChange={(e) => onSelectRunId(e.target.value)}
            className="w-full max-w-xl rounded-lg border border-slate-700 bg-[#070B14] px-3 py-2 text-sm text-slate-100"
          >
            {runs.map((r) => (
              <option key={r.id} value={r.id}>
                [{r.isDemo ? 'DEMO' : 'LIVE'}] {r.suiteName} ({r.category})
              </option>
            ))}
          </select>
        </div>

        {runDetail && (
          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            <a
              href={`/api/runs/${runDetail.id}/export`}
              className="inline-flex items-center gap-1.5 rounded-lg border border-slate-700 px-3.5 py-2 text-xs font-medium text-slate-200 hover:bg-slate-800 whitespace-nowrap"
            >
              <Download className="h-3.5 w-3.5" />
              <span>Export CSV</span>
            </a>
            <button
              type="button"
              onClick={() => exportRunPdf(runDetail)}
              className="inline-flex items-center gap-1.5 rounded-lg border border-blue-500/40 bg-blue-500/10 px-3.5 py-2 text-xs font-medium text-blue-300 hover:bg-blue-500/20 whitespace-nowrap"
            >
              <FileText className="h-3.5 w-3.5" />
              <span>Export PDF</span>
            </button>
          </div>
        )}
      </div>

      {runDetail && (
        <div
          className={`flex items-center justify-between rounded-lg border px-4 py-2.5 text-xs ${
            runDetail.isDemo
              ? 'border-violet-500/35 bg-violet-950/25 text-violet-200'
              : 'border-blue-500/35 bg-blue-950/20 text-blue-200'
          }`}
        >
          <span>
            {runDetail.isDemo
              ? 'DEMO SAMPLE DATA — Pre-loaded Customer Support benchmark for demonstration.'
              : `LIVE BENCHMARK EXECUTION — Real captured outputs and telemetry (${runDetail.id}).`}
          </span>
          <span className="font-mono text-slate-300">
            {runDetail.category} · {runDetail.suiteVersion}
          </span>
        </div>
      )}

      {/* Sub-view Segmented Tabs */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div
          role="tablist"
          aria-label="Results Views"
          className="inline-flex rounded-lg border border-slate-800 bg-[#0D1426] p-1"
        >
          {[
            { id: 'overview', label: 'Comparison & Charts' },
            { id: 'failures', label: `Failure Analysis (${failedExecutions.length})` },
            { id: 'executions', label: `Execution Traces (${filteredExecutions.length})` },
          ].map((t) => (
            <button
              key={t.id}
              type="button"
              role="tab"
              aria-selected={activeTab === t.id}
              onClick={() => setActiveTab(t.id as typeof activeTab)}
              className={`rounded-md px-4 py-1.5 text-xs font-medium transition-colors whitespace-nowrap ${
                activeTab === t.id
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <select
            aria-label="Filter by agent"
            value={agentFilter}
            onChange={(e) => setAgentFilter(e.target.value)}
            className="rounded-lg border border-slate-700/80 bg-[#0D1426] px-3 py-1.5 text-xs text-slate-200"
          >
            <option value="all">All Agents</option>
            {summaries.map((s) => (
              <option key={s.agentId} value={s.agentId}>
                {s.agentName}
              </option>
            ))}
          </select>

          <select
            aria-label="Filter by difficulty"
            value={difficultyFilter}
            onChange={(e) =>
              setDifficultyFilter(e.target.value as DifficultyLevel | 'all')
            }
            className="rounded-lg border border-slate-700/80 bg-[#0D1426] px-3 py-1.5 text-xs text-slate-200"
          >
            <option value="all">All Difficulties</option>
            <option value="easy">easy</option>
            <option value="medium">medium</option>
            <option value="hard">hard</option>
            <option value="adversarial">adversarial</option>
          </select>
        </div>
      </div>

      {loading ? (
        <div className="rounded-xl border border-slate-800/80 bg-[#0D1426] p-10 text-center text-sm text-slate-400">
          Loading benchmark telemetry...
        </div>
      ) : (
        <>
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* Comparison Matrix Table */}
              <div className="rounded-xl border border-slate-800/80 bg-[#0D1426]">
                <div className="border-b border-slate-800/80 px-6 py-4">
                  <h3 className="text-base font-semibold text-slate-100">
                    Weighted Agent Ranking & Metrics Breakdown
                  </h3>
                  <p className="mt-0.5 text-xs text-slate-400">
                    Weights: Completion {runDetail?.weights.taskCompletion}% · Accuracy{' '}
                    {runDetail?.weights.accuracy}% · Reliability{' '}
                    {runDetail?.weights.reliability}% · Cost{' '}
                    {runDetail?.weights.costEfficiency}% · Latency{' '}
                    {runDetail?.weights.latencyEfficiency}%
                  </p>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-sm">
                    <thead>
                      <tr className="border-b border-slate-800 text-xs text-slate-400">
                        <th className="px-6 py-3 font-medium">Rank</th>
                        <th className="px-4 py-3 font-medium">Agent</th>
                        <th className="px-4 py-3 text-right font-medium">Overall</th>
                        <th className="px-4 py-3 text-right font-medium">Completion</th>
                        <th className="px-4 py-3 text-right font-medium">Accuracy</th>
                        <th className="px-4 py-3 text-right font-medium">Reliability</th>
                        <th className="px-4 py-3 text-right font-medium">Tool Eff.</th>
                        <th className="px-4 py-3 text-right font-medium">Avg Latency</th>
                        <th className="px-4 py-3 text-right font-medium">Cost / Task</th>
                        <th className="px-6 py-3 text-right font-medium">Error Rate</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60">
                      {summaries.map((s) => (
                        <tr key={s.agentId} className="hover:bg-slate-800/30">
                          <td className="px-6 py-3.5 font-mono text-xs font-bold text-cyan-400">
                            #{s.rank}
                          </td>
                          <td className="px-4 py-3.5">
                            <div className="font-medium text-slate-100">
                              {s.agentName}
                            </div>
                            <div className="text-xs text-slate-400">
                              {s.provider.toUpperCase()} · {s.modelId}
                            </div>
                            <div className="mt-1 text-[11px] text-slate-500">
                              {s.rankExplanation}
                            </div>
                          </td>
                          <td className="px-4 py-3.5 text-right font-mono font-bold text-blue-400">
                            {s.overallScore}
                          </td>
                          <td className="px-4 py-3.5 text-right font-mono text-slate-200">
                            {s.taskCompletionRate}%
                          </td>
                          <td className="px-4 py-3.5 text-right font-mono text-slate-200">
                            {s.accuracyScore}%
                          </td>
                          <td className="px-4 py-3.5 text-right font-mono text-slate-200">
                            {s.reliabilityScore}%
                          </td>
                          <td className="px-4 py-3.5 text-right font-mono text-slate-300">
                            {s.toolEfficiencyScore !== null
                              ? `${s.toolEfficiencyScore}%`
                              : 'N/A'}
                          </td>
                          <td className="px-4 py-3.5 text-right font-mono text-slate-200">
                            {(s.avgLatencyMs / 1000).toFixed(2)}s
                          </td>
                          <td className="px-4 py-3.5 text-right font-mono text-slate-200">
                            {s.avgCostPerTaskUsd !== null
                              ? `$${s.avgCostPerTaskUsd.toFixed(4)}`
                              : 'Unavailable'}
                          </td>
                          <td className="px-6 py-3.5 text-right font-mono text-xs">
                            <span
                              className={
                                s.errorRate > 0 ? 'text-rose-400' : 'text-emerald-400'
                              }
                            >
                              {s.errorRate}%
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Charts Row */}
              <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
                <div className="rounded-xl border border-slate-800/80 bg-[#0D1426] p-6">
                  <h3 className="mb-4 text-sm font-semibold text-slate-100">
                    Quality & Completion Comparison
                  </h3>
                  <div className="h-72">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={barData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" />
                        <XAxis
                          dataKey="name"
                          tick={{ fill: '#94A3B8', fontSize: 11 }}
                        />
                        <YAxis domain={[0, 100]} tick={{ fill: '#94A3B8', fontSize: 11 }} />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: '#0B1120',
                            borderColor: '#334155',
                            borderRadius: '8px',
                            fontSize: '12px',
                          }}
                        />
                        <Legend wrapperStyle={{ fontSize: '12px' }} />
                        <Bar dataKey="Overall" fill="#3B82F6" radius={[4, 4, 0, 0]} />
                        <Bar dataKey="Completion" fill="#06B6D4" radius={[4, 4, 0, 0]} />
                        <Bar dataKey="Accuracy" fill="#8B5CF6" radius={[4, 4, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                <div className="rounded-xl border border-slate-800/80 bg-[#0D1426] p-6">
                  <h3 className="mb-4 text-sm font-semibold text-slate-100">
                    Multi-Dimensional Capability Radar
                  </h3>
                  <div className="h-72">
                    <ResponsiveContainer width="100%" height="100%">
                      <RadarChart data={radarData}>
                        <PolarGrid stroke="#334155" />
                        <PolarAngleAxis
                          dataKey="metric"
                          tick={{ fill: '#94A3B8', fontSize: 11 }}
                        />
                        <PolarRadiusAxis
                          domain={[0, 100]}
                          tick={{ fill: '#64748B', fontSize: 10 }}
                        />
                        {summaries.map((s, idx) => (
                          <Radar
                            key={s.agentId}
                            name={s.agentName.replace(' (Sample)', '')}
                            dataKey={s.agentName.replace(' (Sample)', '')}
                            stroke={COLORS[idx % COLORS.length]}
                            fill={COLORS[idx % COLORS.length]}
                            fillOpacity={0.2}
                          />
                        ))}
                        <Legend wrapperStyle={{ fontSize: '12px' }} />
                      </RadarChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>

              {/* Latency & Cost + Smart Agent Recommendation */}
              <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
                <div className="rounded-xl border border-slate-800/80 bg-[#0D1426] p-6">
                  <h3 className="mb-1 text-sm font-semibold text-slate-100">
                    Average Latency (ms) Comparison
                  </h3>
                  <p className="mb-4 text-xs text-slate-400">
                    Lower bars indicate faster end-to-end tool and reasoning completion.
                  </p>
                  <div className="h-60">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={latencyCostData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" />
                        <XAxis
                          dataKey="name"
                          tick={{ fill: '#94A3B8', fontSize: 11 }}
                        />
                        <YAxis tick={{ fill: '#94A3B8', fontSize: 11 }} />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: '#0B1120',
                            borderColor: '#334155',
                            borderRadius: '8px',
                            fontSize: '12px',
                          }}
                        />
                        <Bar
                          dataKey="LatencyMs"
                          name="Avg Latency (ms)"
                          fill="#06B6D4"
                          radius={[4, 4, 0, 0]}
                        />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* Smart Agent Recommendation Engine */}
                <div className="rounded-xl border border-slate-800/80 bg-[#0D1426] p-6">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div className="flex items-center gap-2">
                      <Award className="h-4 w-4 text-cyan-400" aria-hidden="true" />
                      <h3 className="text-sm font-semibold text-slate-100">
                        Smart Agent Recommendation
                      </h3>
                    </div>

                    <select
                      aria-label="Optimization priority"
                      value={priority}
                      onChange={(e) =>
                        setPriority(e.target.value as RecommendationPriority)
                      }
                      className="rounded-lg border border-slate-700 bg-[#070B14] px-3 py-1 text-xs text-slate-200"
                    >
                      <option value="balanced">Balanced Performance</option>
                      <option value="accuracy">Highest Accuracy</option>
                      <option value="cost">Lowest Cost</option>
                      <option value="speed">Fastest Response</option>
                      <option value="reliability">Maximum Reliability</option>
                    </select>
                  </div>

                  <div className="mt-4">
                    <div className="text-base font-bold text-slate-50">
                      {recommendation.headline}
                    </div>
                    <p className="mt-1.5 text-xs leading-relaxed text-slate-300">
                      {recommendation.rationale}
                    </p>

                    {recommendation.supportingMetrics.length > 0 && (
                      <div className="mt-4 grid grid-cols-3 gap-2 border-y border-slate-800/70 py-3">
                        {recommendation.supportingMetrics.map((m) => (
                          <div key={m.label}>
                            <div className="text-[11px] text-slate-400">{m.label}</div>
                            <div className="font-mono text-xs font-semibold text-slate-100">
                              {m.value}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}

                    <div className="mt-3 space-y-1">
                      <div className="text-[11px] font-medium text-slate-400">
                        Trade-offs & Considerations
                      </div>
                      {recommendation.tradeOffs.map((t, i) => (
                        <div key={i} className="text-xs text-slate-300">
                          · {t}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* FAILURE ANALYSIS TAB */}
          {activeTab === 'failures' && (
            <div className="space-y-4">
              {failedExecutions.length === 0 ? (
                <div className="rounded-xl border border-slate-800/80 bg-[#0D1426] p-10 text-center">
                  <CheckCircle2 className="mx-auto h-8 w-8 text-emerald-400" />
                  <h3 className="mt-3 text-base font-semibold text-slate-100">
                    Zero Failures Observed
                  </h3>
                  <p className="mt-1 text-xs text-slate-400">
                    All executions in this filter passed verification criteria.
                  </p>
                </div>
              ) : (
                failedExecutions.map((ex) => {
                  const tc = tcMap.get(ex.testCaseId);
                  const ev = evalMap.get(ex.id);
                  return (
                    <div
                      key={ex.id}
                      className="rounded-xl border border-rose-500/25 bg-[#0D1426] p-5 space-y-4"
                    >
                      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                        <div>
                          <div className="flex flex-wrap items-center gap-2 text-xs">
                            <AlertTriangle className="h-4 w-4 text-rose-400" />
                            <span className="font-mono font-semibold text-cyan-400">
                              {tc?.code}
                            </span>
                            <span className="text-slate-600">·</span>
                            <span className="font-semibold text-slate-100">
                              {ex.agentName}
                            </span>
                            <span className="text-slate-600">·</span>
                            <span className="text-rose-400">
                              {ev?.failureCategory || ex.status}
                            </span>
                          </div>
                          <div className="mt-1 text-sm font-medium text-slate-200">
                            {tc?.title}
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={() => setTraceExec(ex)}
                          className="inline-flex items-center gap-1.5 rounded-lg border border-slate-700 px-3 py-1.5 text-xs font-medium text-slate-200 hover:bg-slate-800 whitespace-nowrap shrink-0"
                        >
                          <Terminal className="h-3.5 w-3.5" />
                          <span>Inspect Trace</span>
                        </button>
                      </div>

                      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
                        <div className="rounded-lg border border-slate-800 bg-[#070B14] p-3.5">
                          <div className="text-[11px] font-medium text-emerald-400">
                            Expected Outcome
                          </div>
                          <p className="mt-1 text-xs leading-relaxed text-slate-300">
                            {tc?.expectedOutcome}
                          </p>
                        </div>
                        <div className="rounded-lg border border-slate-800 bg-[#070B14] p-3.5">
                          <div className="text-[11px] font-medium text-rose-400">
                            Actual Agent Output
                          </div>
                          <p className="mt-1 text-xs leading-relaxed text-slate-300">
                            {ex.output || ex.errorMessage || '(Empty output)'}
                          </p>
                        </div>
                      </div>

                      {ev && (
                        <div className="space-y-1.5 border-t border-slate-800/80 pt-3 text-xs">
                          <div className="text-slate-300">
                            <strong>Verified Checks:</strong>{' '}
                            {ev.deterministicNotes.join(' ') || 'None'}
                          </div>
                          <div className="text-slate-300">
                            <strong>Judge Evaluation ({ev.judgeModel}):</strong>{' '}
                            {ev.judgeReasoning}
                          </div>
                          <div className="text-slate-400">
                            <strong>Limitations:</strong> {ev.judgeLimitations}
                          </div>
                          {ev.improvementRecommendation && (
                            <div className="text-cyan-300">
                              <strong>Recommendation:</strong>{' '}
                              {ev.improvementRecommendation}
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          )}

          {/* ALL EXECUTIONS & TRACES TAB */}
          {activeTab === 'executions' && (
            <div className="rounded-xl border border-slate-800/80 bg-[#0D1426]">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead>
                    <tr className="border-b border-slate-800 text-xs text-slate-400">
                      <th className="px-6 py-3 font-medium">Scenario</th>
                      <th className="px-4 py-3 font-medium">Agent</th>
                      <th className="px-4 py-3 font-medium">Result</th>
                      <th className="px-4 py-3 text-right font-medium">Accuracy</th>
                      <th className="px-4 py-3 text-right font-medium">Latency</th>
                      <th className="px-4 py-3 text-right font-medium">Tokens</th>
                      <th className="px-6 py-3 text-right font-medium">Trace</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {filteredExecutions.map((ex) => {
                      const tc = tcMap.get(ex.testCaseId);
                      const ev = evalMap.get(ex.id);
                      const totalTok =
                        ex.inputTokens !== null && ex.outputTokens !== null
                          ? ex.inputTokens + ex.outputTokens
                          : null;
                      return (
                        <tr key={ex.id} className="hover:bg-slate-800/30">
                          <td className="px-6 py-3">
                            <div className="font-mono text-xs text-cyan-400">
                              {tc?.code || ex.testCaseId} · {tc?.difficulty}
                            </div>
                            <div className="text-xs text-slate-200">{tc?.title}</div>
                          </td>
                          <td className="px-4 py-3 text-xs text-slate-200">
                            {ex.agentName}
                          </td>
                          <td className="px-4 py-3 text-xs">
                            <span
                              className={
                                ev?.taskCompleted
                                  ? 'text-emerald-400'
                                  : 'text-rose-400'
                              }
                            >
                              {ev?.taskCompleted ? 'Passed' : 'Failed'}
                            </span>
                          </td>
                          <td className="px-4 py-3 text-right font-mono text-xs text-slate-200">
                            {ev?.accuracyScore ?? 0}%
                          </td>
                          <td className="px-4 py-3 text-right font-mono text-xs text-slate-300">
                            {ex.latencyMs}ms
                          </td>
                          <td className="px-4 py-3 text-right font-mono text-xs text-slate-300">
                            {totalTok !== null ? totalTok : 'N/A'}
                          </td>
                          <td className="px-6 py-3 text-right">
                            <button
                              type="button"
                              onClick={() => setTraceExec(ex)}
                              className="text-xs font-medium text-blue-400 hover:text-blue-300 whitespace-nowrap"
                            >
                              View Trace ({ex.toolEvents.length})
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </>
      )}

      {/* Execution Trace Inspector Drawer / Modal */}
      {traceExec && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Execution Trace Inspector"
          className="fixed inset-0 z-50 flex justify-end bg-black/70"
        >
          <div className="flex h-full w-full max-w-2xl flex-col border-l border-slate-800 bg-[#0B1120]">
            <div className="flex items-center justify-between border-b border-slate-800 px-6 py-4">
              <div>
                <div className="font-mono text-xs text-cyan-400">
                  Execution Trace · {traceExec.id.slice(0, 12)}
                </div>
                <h3 className="text-base font-semibold text-slate-100">
                  {traceExec.agentName} ({traceExec.modelId})
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setTraceExec(null)}
                aria-label="Close trace inspector"
                className="rounded-lg border border-slate-800 p-1.5 text-slate-400 hover:bg-slate-800 hover:text-slate-100"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              <div className="grid grid-cols-3 gap-3 rounded-lg border border-slate-800 bg-[#070B14] p-4 text-xs">
                <div>
                  <div className="text-slate-400">Status</div>
                  <div className="mt-1 font-mono font-semibold text-slate-100">
                    {traceExec.status}
                  </div>
                </div>
                <div>
                  <div className="text-slate-400">Latency</div>
                  <div className="mt-1 font-mono font-semibold text-slate-100">
                    {traceExec.latencyMs}ms
                  </div>
                </div>
                <div>
                  <div className="text-slate-400">Tokens (In/Out)</div>
                  <div className="mt-1 font-mono font-semibold text-slate-100">
                    {traceExec.inputTokens ?? 'N/A'} / {traceExec.outputTokens ?? 'N/A'}
                  </div>
                </div>
              </div>

              <div>
                <h4 className="mb-3 flex items-center gap-2 text-xs font-semibold text-slate-300">
                  <Clock className="h-3.5 w-3.5 text-cyan-400" />
                  <span>Observable Action & Tool Timeline</span>
                </h4>
                <div className="space-y-3">
                  {traceExec.toolEvents.map((ev) => (
                    <div
                      key={ev.id}
                      className="rounded-lg border border-slate-800 bg-[#0D1426] p-3.5 text-xs"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-mono font-semibold text-cyan-300">
                          [{ev.sequence}] {ev.eventType.toUpperCase()}
                          {ev.toolName ? ` · ${ev.toolName}` : ''}
                        </span>
                        <span className="font-mono text-[11px] text-slate-500">
                          {ev.durationMs}ms · {new Date(ev.timestamp).toLocaleTimeString()}
                        </span>
                      </div>
                      {ev.inputSummary && (
                        <div className="mt-1.5 font-mono text-[11px] text-slate-300">
                          Input: {ev.inputSummary}
                        </div>
                      )}
                      {ev.outputSummary && (
                        <div className="mt-1 font-mono text-[11px] text-slate-400">
                          Output: {ev.outputSummary}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="mb-2 flex items-center gap-2 text-xs font-semibold text-slate-300">
                  <Sparkles className="h-3.5 w-3.5 text-blue-400" />
                  <span>Evaluation Evidence</span>
                </h4>
                {(() => {
                  const ev = evalMap.get(traceExec.id);
                  if (!ev) return null;
                  return (
                    <div className="rounded-lg border border-slate-800 bg-[#070B14] p-4 text-xs space-y-2">
                      <div className="text-slate-200">
                        <strong>Judge ({ev.judgeModel}):</strong> {ev.judgeReasoning}
                      </div>
                      <div className="text-slate-400">
                        <strong>Evidence:</strong> {ev.judgeEvidence}
                      </div>
                      <div className="text-slate-500">
                        <strong>Limitations:</strong> {ev.judgeLimitations}
                      </div>
                    </div>
                  );
                })()}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
