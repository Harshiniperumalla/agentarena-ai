import { useEffect, useState } from 'react';
import { CheckCircle2, Shield } from 'lucide-react';
import { api } from '../services/api';
import type { PlatformSettings, ProviderInfo } from '../types/benchmark';
import { DEFAULT_WEIGHTS, normalizeWeights } from '../utils/scoring';

interface SettingsPageProps {
  providers: ProviderInfo[];
}

export function SettingsPage({ providers }: SettingsPageProps) {
  const [settings, setSettings] = useState<PlatformSettings>({
    defaultWeights: { ...DEFAULT_WEIGHTS },
    executionTimeoutMs: 25000,
    maxRetries: 1,
    concurrencyLimit: 3,
    judgeModel: 'gemini-4-hydrogen',
  });
  const [savedMsg, setSavedMsg] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    api.getSettings().then(({ settings: loaded }) => setSettings(loaded));
  }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setSavedMsg(null);
    try {
      const normalized = {
        ...settings,
        defaultWeights: normalizeWeights(settings.defaultWeights),
      };
      const res = await api.updateSettings(normalized);
      setSettings(res.settings);
      setSavedMsg('Platform evaluation settings updated.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6 max-w-4xl">
      {/* Read-Only Provider Environment Readiness */}
      <div className="rounded-xl border border-slate-800/80 bg-[#0D1426] p-6">
        <div className="flex items-center gap-2">
          <Shield className="h-4 w-4 text-cyan-400" aria-hidden="true" />
          <h2 className="text-base font-semibold text-slate-100">
            Server-Side Provider Environment Status
          </h2>
        </div>
        <p className="mt-1 text-xs text-slate-400">
          Credentials are managed strictly through server environment variables and are
          never stored or exposed in browser requests.
        </p>

        <div className="mt-4 divide-y divide-slate-800/70">
          {providers.map((p) => (
            <div
              key={p.id}
              className="flex items-center justify-between py-3 text-sm"
            >
              <div>
                <div className="font-medium text-slate-100">{p.name}</div>
                <div className="font-mono text-xs text-slate-500">{p.envVar}</div>
              </div>
              <span
                className={`text-xs font-medium ${
                  p.configured ? 'text-emerald-400' : 'text-amber-400'
                }`}
              >
                {p.configured ? 'Configured on Server' : 'Not Configured'}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Orchestrator & Scoring Policy Configuration */}
      <form
        onSubmit={handleSave}
        className="rounded-xl border border-slate-800/80 bg-[#0D1426] p-6 space-y-5"
      >
        <div>
          <h3 className="text-base font-semibold text-slate-100">
            Orchestrator & Evaluation Defaults
          </h3>
          <p className="mt-1 text-xs text-slate-400">
            Configure request timeouts, retry limits, concurrency, and independent judge
            model selection.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div>
            <label
              htmlFor="timeout-ms"
              className="block text-xs font-medium text-slate-300"
            >
              Task Execution Timeout (ms)
            </label>
            <input
              id="timeout-ms"
              type="number"
              min={5000}
              max={60000}
              step={1000}
              value={settings.executionTimeoutMs}
              onChange={(e) =>
                setSettings((s) => ({
                  ...s,
                  executionTimeoutMs: Number(e.target.value),
                }))
              }
              className="mt-1.5 w-full rounded-lg border border-slate-700 bg-[#070B14] px-3 py-2 font-mono text-sm text-slate-100"
            />
          </div>

          <div>
            <label
              htmlFor="max-retries"
              className="block text-xs font-medium text-slate-300"
            >
              Max Retries on Transient Failure
            </label>
            <select
              id="max-retries"
              value={settings.maxRetries}
              onChange={(e) =>
                setSettings((s) => ({ ...s, maxRetries: Number(e.target.value) }))
              }
              className="mt-1.5 w-full rounded-lg border border-slate-700 bg-[#070B14] px-3 py-2 text-sm text-slate-100"
            >
              <option value={0}>0 retries (Strict single attempt)</option>
              <option value={1}>1 retry</option>
              <option value={2}>2 retries</option>
            </select>
          </div>

          <div>
            <label
              htmlFor="concurrency-limit"
              className="block text-xs font-medium text-slate-300"
            >
              Worker Concurrency Limit
            </label>
            <input
              id="concurrency-limit"
              type="number"
              min={1}
              max={5}
              value={settings.concurrencyLimit}
              onChange={(e) =>
                setSettings((s) => ({
                  ...s,
                  concurrencyLimit: Number(e.target.value),
                }))
              }
              className="mt-1.5 w-full rounded-lg border border-slate-700 bg-[#070B14] px-3 py-2 font-mono text-sm text-slate-100"
            />
          </div>

          <div>
            <label
              htmlFor="judge-model"
              className="block text-xs font-medium text-slate-300"
            >
              Independent LLM Judge Model
            </label>
            <select
              id="judge-model"
              value={settings.judgeModel}
              onChange={(e) =>
                setSettings((s) => ({ ...s, judgeModel: e.target.value }))
              }
              className="mt-1.5 w-full rounded-lg border border-slate-700 bg-[#070B14] px-3 py-2 text-sm text-slate-100"
            >
              <option value="gemini-4-hydrogen">gemini-4-hydrogen</option>
              <option value="gemini-3.1-flash-lite">gemini-3.1-flash-lite</option>
            </select>
          </div>
        </div>

        <div className="flex items-center justify-between border-t border-slate-800/80 pt-4">
          {savedMsg ? (
            <span className="inline-flex items-center gap-1.5 text-xs text-emerald-400">
              <CheckCircle2 className="h-4 w-4" />
              <span>{savedMsg}</span>
            </span>
          ) : (
            <span />
          )}

          <button
            type="submit"
            disabled={saving}
            className="rounded-lg bg-blue-600 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-500"
          >
            {saving ? 'Saving...' : 'Save Settings'}
          </button>
        </div>
      </form>
    </div>
  );
}
