import {
  Activity,
  Award,
  BarChart3,
  Bot,
  History,
  LayoutDashboard,
  PlusCircle,
  Settings,
  X,
} from 'lucide-react';

export type NavSection =
  | 'overview'
  | 'new-benchmark'
  | 'agents'
  | 'history'
  | 'results'
  | 'leaderboard'
  | 'settings';

interface SidebarProps {
  active: NavSection;
  onSelect: (section: NavSection) => void;
  mobileOpen: boolean;
  onCloseMobile: () => void;
}

const NAV_ITEMS: Array<{
  id: NavSection;
  label: string;
  icon: typeof LayoutDashboard;
}> = [
  { id: 'overview', label: 'Overview', icon: LayoutDashboard },
  { id: 'new-benchmark', label: 'New Benchmark', icon: PlusCircle },
  { id: 'agents', label: 'Agent Management', icon: Bot },
  { id: 'history', label: 'Benchmark History', icon: History },
  { id: 'results', label: 'Results & Analytics', icon: BarChart3 },
  { id: 'leaderboard', label: 'Leaderboard', icon: Award },
  { id: 'settings', label: 'Settings', icon: Settings },
];

export function Sidebar({ active, onSelect, mobileOpen, onCloseMobile }: SidebarProps) {
  const navContent = (
    <div className="flex h-full flex-col justify-between border-r border-slate-800/80 bg-[#0B1120] px-4 py-6">
      <div>
        <div className="mb-8 flex items-center justify-between px-2">
          <div className="flex items-center gap-2.5">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg border border-blue-500/40 bg-blue-500/15 text-blue-400">
              <Activity className="h-4 w-4" aria-hidden="true" />
            </div>
            <div>
              <div className="text-base font-bold tracking-tight text-slate-50 whitespace-nowrap">
                AgentArena AI
              </div>
              <div className="text-[11px] text-slate-400 whitespace-nowrap">
                Agent Evaluation Suite
              </div>
            </div>
          </div>
          <button
            type="button"
            onClick={onCloseMobile}
            aria-label="Close navigation menu"
            className="rounded-md p-1.5 text-slate-400 hover:bg-slate-800 hover:text-slate-100 lg:hidden"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <nav aria-label="Main Navigation" className="space-y-1">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const isActive = active === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  onSelect(item.id);
                  onCloseMobile();
                }}
                className={`flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors whitespace-nowrap shrink-0 ${
                  isActive
                    ? 'border border-blue-500/35 bg-blue-500/12 text-blue-300'
                    : 'border border-transparent text-slate-400 hover:bg-slate-800/60 hover:text-slate-100'
                }`}
              >
                <Icon className="h-4 w-4 shrink-0" aria-hidden="true" />
                <span className="truncate">{item.label}</span>
              </button>
            );
          })}
        </nav>
      </div>

      <div className="border-t border-slate-800/80 px-2 pt-4">
        <p className="text-xs font-medium text-slate-300">
          Don't Just Trust the Agent. Test It.
        </p>
        <p className="mt-1 text-[11px] text-slate-500">
          Measure · Compare · Evaluate · Deploy
        </p>
      </div>
    </div>
  );

  return (
    <>
      <aside className="hidden w-64 shrink-0 lg:block">{navContent}</aside>
      {mobileOpen && (
        <div className="fixed inset-0 z-50 flex lg:hidden">
          <div
            className="fixed inset-0 bg-black/70"
            onClick={onCloseMobile}
            aria-hidden="true"
          />
          <aside className="relative z-10 w-64 max-w-[80vw]">{navContent}</aside>
        </div>
      )}
    </>
  );
}
