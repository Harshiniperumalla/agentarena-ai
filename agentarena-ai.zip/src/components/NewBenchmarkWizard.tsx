import { useEffect, useState } from 'react';
import {
  AlertCircle,
  Check,
  CheckCircle2,
  Loader2,
  Play,
  Sliders,
  Sparkles,
  Trash2,
  XCircle,
} from 'lucide-react';
import { api } from '../services/api';
import type {
  AgentConfig,
  BenchmarkCategory,
  BenchmarkRun,
  DifficultyLevel,
  ProviderInfo,
  ScoringWeights,
  TestCase,
} from '../types/benchmark';
import { DEFAULT_WEIGHTS, normalizeWeights } from '../utils/scoring';

interface NewBenchmarkWizardProps {
  agents: AgentConfig[];
  providers: ProviderInfo[];
  onRunCompleted: (runId: string) => void;
}

const CATEGORIES: Array<{
  id: BenchmarkCategory;
  subtitle: string;
  defaultPrompt: string;
}> = [
  {
    id: 'Customer Support',
    subtitle: 'Refunds, warranty exceptions, SLA escalations, adversarial policy bypasses',
    defaultPrompt:
      'Evaluate autonomous support agents on order lookup, return eligibility, duplicate billing resolution, SLA escalations, and prompt injection resistance.',
  },
  {
    id: 'Software Development',
    subtitle: 'Diagnostics, debugging, webhook troubleshooting, auth configuration checks',
    defaultPrompt:
      'Evaluate engineering agents on microservice failure triage, documentation lookup, root-cause accuracy, and remediation completeness.',
  },
  {
    id: 'Research',
    subtitle: 'Policy synthesis, multi-document verification, comparative compliance analysis',
    defaultPrompt:
      'Evaluate research agents on gathering verified rules across internal knowledge bases and producing evidence-backed comparisons.',
  },
  {
    id: 'E-commerce',
    subtitle: 'Order cancellations, damaged item claims, final-sale rules, shipping disputes',
    defaultPrompt:
      'Evaluate commerce agents on partial order cancellations, damaged transit refunds, currency handling, and policy adherence.',
  },
  {
    id: 'Cybersecurity',
    subtitle: 'Alert triage, credential stuffing classification, social engineering defense',
    defaultPrompt:
      'Evaluate security operations agents on alert severity classification, threat containment recommendations, and escalation accuracy.',
  },
];

export function NewBenchmarkWizard({
  agents,
  providers,
  onRunCompleted,
}: NewBenchmarkWizardProps) {
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [category, setCategory] = useState<BenchmarkCategory>('Customer Support');
  const [name, setName] = useState('Customer Support Production Readiness Eval');
  const [description, setDescription] = useState(CATEGORIES[0].defaultPrompt);
  const [taskCount, setTaskCount] = useState(5);
  const [repeats, setRepeats] = useState(1);
  const [weights, setWeights] = useState<ScoringWeights>({ ...DEFAULT_WEIGHTS });

  const liveAgents = agents.filter((a) => !a.isDemo);
  const providerReadyMap = new Map(providers.map((p) => [p.id, p.configured]));

  const [selectedAgentIds, setSelectedAgentIds] = useState<string[]>(() =>
    liveAgents
      .filter((a) => providerReadyMap.get(a.provider))
      .slice(0, 3)
      .map((a) => a.id)
  );

  useEffect(() => {
    if (selectedAgentIds.length === 0 && liveAgents.length >= 2) {
      const configuredIds = liveAgents
        .filter((a) => providerReadyMap.get(a.provider))
        .slice(0, 3)
        .map((a) => a.id);
      if (configuredIds.length >= 2) {
        setSelectedAgentIds(configuredIds);
      } else {
        setSelectedAgentIds(liveAgents.slice(0, 2).map((a) => a.id));
      }
    }
  }, [agents, providers]);

  const [suiteId, setSuiteId] = useState<string | null>(null);
  const [tasks, setTasks] = useState<TestCase[]>([]);
  const [generationNote, setGenerationNote] = useState('');
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [editingTaskId, setEditingTaskId] = useState<string | null>(null);

  const [activeRun, setActiveRun] = useState<BenchmarkRun | null>(null);
  const [launching, setLaunching] = useState(false);

  const weightSum =
    weights.taskCompletion +
    weights.accuracy +
    weights.reliability +
    weights.costEfficiency +
    weights.latencyEfficiency;

  const handleCategoryPick = (cat: BenchmarkCategory) => {
    setCategory(cat);
    const meta = CATEGORIES.find((c) => c.id === cat);
    if (meta) {
      setName(`${cat} Agent Benchmark`);
      setDescription(meta.defaultPrompt);
    }
  };

  const toggleAgent = (id: string) => {
    setSelectedAgentIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleGenerateTasks = async () => {
    setError(null);
    if (!name.trim()) {
      setError('Please provide a benchmark name.');
      return;
    }
    if (selectedAgentIds.length < 2) {
      setError('Select at least 2 configured agents to compare.');
      return;
    }

    setGenerating(true);
    try {
      const normalized = normalizeWeights(weights);
      setWeights(normalized);

      const { suite } = await api.createSuite({
        name: name.trim(),
        version: 'v1.0.0',
        category,
        description: description.trim(),
        weights: normalized,
        reliabilityRepeats: repeats,
      });
      setSuiteId(suite.id);

      const gen = await api.generateTasks(suite.id, taskCount);
      setTasks(gen.tasks);
      setGenerationNote(gen.note);
      setStep(2);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to generate tasks.');
    } finally {
      setGenerating(false);
    }
  };

  const handleSaveTask = async (task: TestCase) => {
    try {
      const { testCase } = await api.updateTestCase(task.id, task);
      setTasks((prev) => prev.map((t) => (t.id === task.id ? testCase : t)));
      setEditingTaskId(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save task edit.');
    }
  };

  const handleToggleApprove = async (task: TestCase) => {
    try {
      const { testCase } = await api.updateTestCase(task.id, {
        approved: !task.approved,
      });
      setTasks((prev) => prev.map((t) => (t.id === task.id ? testCase : t)));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update approval.');
    }
  };

  const handleDeleteTask = async (id: string) => {
    try {
      await api.deleteTestCase(id);
      setTasks((prev) => prev.filter((t) => t.id !== id));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete task.');
    }
  };

  const handleLaunchRun = async () => {
    if (!suiteId) return;
    const approvedTasks = tasks.filter((t) => t.approved);
    if (approvedTasks.length === 0) {
      setError('Approve at least 1 standardized test case before launching.');
      return;
    }

    setError(null);
    setLaunching(true);
    try {
      const normalized = normalizeWeights(weights);
      const { run } = await api.launchRun({
        suiteId,
        selectedAgentIds,
        weights: normalized,
        reliabilityRepeats: repeats,
      });
      setActiveRun(run);
      setStep(3);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to launch benchmark.');
    } finally {
      setLaunching(false);
    }
  };

  useEffect(() => {
    if (step !== 3 || !activeRun) return;
    if (
      activeRun.status === 'completed' ||
      activeRun.status === 'failed' ||
      activeRun.status === 'cancelled'
    ) {
      return;
    }

    const interval = setInterval(async () => {
      try {
        const { run } = await api.getRun(activeRun.id);
        setActiveRun(run);
      } catch {
        // Ignore transient poll error
      }
    }, 1200);

    return () => clearInterval(interval);
  }, [step, activeRun?.id, activeRun?.status]);

  return (
    <div className="space-y-6">
      {/* Stepper Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-slate-800/80 bg-[#0D1426] px-6 py-4">
        <div className="flex flex-wrap items-center gap-6 text-sm">
          {[
            { num: 1, label: '01. Configure Benchmark' },
            { num: 2, label: '02. Review Standardized Tasks' },
            { num: 3, label: '03. Live Execution Monitor' },
          ].map((s) => (
            <div
              key={s.num}
              className={`font-medium ${
                step === s.num
                  ? 'text-cyan-300'
                  : step > s.num
                    ? 'text-emerald-400'
                    : 'text-slate-500'
              }`}
            >
              {s.label}
            </div>
          ))}
        </div>
        <div className="text-xs text-slate-400">
          {selectedAgentIds.length} agents · {taskCount} scenarios · {repeats}x repeat
        </div>
      </div>

      {error && (
        <div
          role="alert"
          className="flex items-center gap-2.5 rounded-lg border border-rose-500/40 bg-rose-950/30 px-4 py-3 text-sm text-rose-200"
        >
          <AlertCircle className="h-4 w-4 shrink-0 text-rose-400" />
          <span>{error}</span>
        </div>
      )}

      {/* STEP 1: Configure Benchmark */}
      {step === 1 && (
        <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
          <div className="space-y-6 xl:col-span-2">
            {/* Industry / Category */}
            <div className="rounded-xl border border-slate-800/80 bg-[#0D1426] p-6">
              <h3 className="text-base font-semibold text-slate-100">
                1. Industry Domain
              </h3>
              <p className="mt-1 text-xs text-slate-400">
                Select a domain to tailor standardized scenario generation and tool checks.
              </p>

              <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2">
                {CATEGORIES.map((cat) => {
                  const active = category === cat.id;
                  return (
                    <button
                      key={cat.id}
                      type="button"
                      onClick={() => handleCategoryPick(cat.id)}
                      className={`rounded-lg border p-4 text-left transition-colors ${
                        active
                          ? 'border-blue-500 bg-blue-500/10'
                          : 'border-slate-800 bg-[#070B14]/60 hover:border-slate-700'
                      }`}
                    >
                      <div className="text-sm font-semibold text-slate-100">
                        {cat.id}
                      </div>
                      <div className="mt-1 text-xs text-slate-400">{cat.subtitle}</div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Suite Details */}
            <div className="rounded-xl border border-slate-800/80 bg-[#0D1426] p-6 space-y-4">
              <h3 className="text-base font-semibold text-slate-100">
                2. Benchmark Parameters
              </h3>

              <div>
                <label
                  htmlFor="benchmark-name"
                  className="block text-xs font-medium text-slate-300"
                >
                  Benchmark Name
                </label>
                <input
                  id="benchmark-name"
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="mt-1.5 w-full rounded-lg border border-slate-700/80 bg-[#070B14] px-3.5 py-2 text-sm text-slate-100 focus:border-blue-500 focus:outline-none"
                />
              </div>

              <div>
                <label
                  htmlFor="benchmark-desc"
                  className="block text-xs font-medium text-slate-300"
                >
                  Task Focus & Instructions
                </label>
                <textarea
                  id="benchmark-desc"
                  rows={3}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="mt-1.5 w-full rounded-lg border border-slate-700/80 bg-[#070B14] px-3.5 py-2 text-sm text-slate-100 focus:border-blue-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <label
                    htmlFor="task-count"
                    className="block text-xs font-medium text-slate-300"
                  >
                    Standardized Test Scenarios ({taskCount})
                  </label>
                  <input
                    id="task-count"
                    type="range"
                    min={3}
                    max={30}
                    value={taskCount}
                    onChange={(e) => setTaskCount(Number(e.target.value))}
                    className="mt-2 w-full accent-blue-500"
                  />
                  <div className="mt-1 flex justify-between font-mono text-[11px] text-slate-500">
                    <span>3 (Fast)</span>
                    <span>20 (Standard)</span>
                    <span>30 (Full)</span>
                  </div>
                </div>

                <div>
                  <label
                    htmlFor="repeat-count"
                    className="block text-xs font-medium text-slate-300"
                  >
                    Reliability Repeats per Task
                  </label>
                  <select
                    id="repeat-count"
                    value={repeats}
                    onChange={(e) => setRepeats(Number(e.target.value))}
                    className="mt-1.5 w-full rounded-lg border border-slate-700/80 bg-[#070B14] px-3 py-2 text-sm text-slate-100 focus:border-blue-500 focus:outline-none"
                  >
                    <option value={1}>1x pass (Fast comparison)</option>
                    <option value={2}>2x repeats (Consistency check)</option>
                    <option value={3}>3x repeats (Strict reliability)</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Agent Selection */}
            <div className="rounded-xl border border-slate-800/80 bg-[#0D1426] p-6">
              <div className="flex items-center justify-between gap-4">
                <div>
                  <h3 className="text-base font-semibold text-slate-100">
                    3. Select Competing Agents (Min 2)
                  </h3>
                  <p className="mt-1 text-xs text-slate-400">
                    All selected agents execute identical tasks in strict isolation.
                  </p>
                </div>
                <span className="font-mono text-xs text-cyan-400">
                  {selectedAgentIds.length} selected
                </span>
              </div>

              <div className="mt-4 space-y-2.5">
                {liveAgents.map((agent) => {
                  const checked = selectedAgentIds.includes(agent.id);
                  const configured = providerReadyMap.get(agent.provider) ?? false;
                  return (
                    <label
                      key={agent.id}
                      className={`flex cursor-pointer items-start justify-between gap-4 rounded-lg border p-3.5 transition-colors ${
                        checked
                          ? 'border-blue-500/70 bg-blue-500/10'
                          : 'border-slate-800 bg-[#070B14]/50 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        <input
                          type="checkbox"
                          checked={checked}
                          onChange={() => toggleAgent(agent.id)}
                          className="mt-1 h-4 w-4 accent-blue-500"
                        />
                        <div>
                          <div className="text-sm font-medium text-slate-100">
                            {agent.name}
                          </div>
                          <div className="mt-0.5 text-xs text-slate-400">
                            {agent.provider.toUpperCase()} · {agent.modelId} ·{' '}
                            {agent.allowedTools.length} tools
                          </div>
                        </div>
                      </div>
                      <span
                        className={`text-xs font-medium whitespace-nowrap ${
                          configured ? 'text-emerald-400' : 'text-amber-400'
                        }`}
                      >
                        {configured ? 'Key Ready' : 'Key Not Set'}
                      </span>
                    </label>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Right Column: Scoring Weights */}
          <div className="space-y-6">
            <div className="rounded-xl border border-slate-800/80 bg-[#0D1426] p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Sliders className="h-4 w-4 text-cyan-400" aria-hidden="true" />
                  <h3 className="text-base font-semibold text-slate-100">
                    Scoring Weights
                  </h3>
                </div>
                <span
                  className={`font-mono text-xs font-semibold ${
                    Math.abs(weightSum - 100) < 0.1
                      ? 'text-emerald-400'
                      : 'text-amber-400'
                  }`}
                >
                  Total: {weightSum}%
                </span>
              </div>

              <p className="mt-1 text-xs text-slate-400">
                Adjust priorities for your organization. Weights automatically normalize to
                100% upon generation.
              </p>

              <div className="mt-5 space-y-4">
                {(
                  [
                    ['taskCompletion', 'Task Completion'],
                    ['accuracy', 'Accuracy'],
                    ['reliability', 'Reliability'],
                    ['costEfficiency', 'Cost Efficiency'],
                    ['latencyEfficiency', 'Latency Efficiency'],
                  ] as const
                ).map(([key, label]) => (
                  <div key={key}>
                    <div className="flex justify-between text-xs">
                      <span className="text-slate-300">{label}</span>
                      <span className="font-mono text-slate-100">{weights[key]}%</span>
                    </div>
                    <input
                      type="range"
                      min={0}
                      max={60}
                      step={5}
                      value={weights[key]}
                      onChange={(e) =>
                        setWeights((prev) => ({
                          ...prev,
                          [key]: Number(e.target.value),
                        }))
                      }
                      aria-label={label}
                      className="mt-1.5 w-full accent-cyan-400"
                    />
                  </div>
                ))}
              </div>

              {Math.abs(weightSum - 100) >= 0.1 && (
                <button
                  type="button"
                  onClick={() => setWeights(normalizeWeights(weights))}
                  className="mt-4 w-full rounded-lg border border-amber-500/40 bg-amber-500/10 py-2 text-xs font-medium text-amber-300 hover:bg-amber-500/20"
                >
                  Normalize Weights to 100%
                </button>
              )}

              <button
                type="button"
                disabled={generating}
                onClick={handleGenerateTasks}
                className="mt-6 inline-flex w-full items-center justify-center gap-2 rounded-lg bg-blue-600 px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-blue-500 disabled:opacity-60 whitespace-nowrap"
              >
                {generating ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    <span>Generating Scenarios...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="h-4 w-4" />
                    <span>Generate Standardized Tasks</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* STEP 2: Review & Approve Standardized Tasks */}
      {step === 2 && (
        <div className="space-y-4">
          <div className="flex flex-col gap-4 rounded-xl border border-slate-800/80 bg-[#0D1426] p-5 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h3 className="text-base font-semibold text-slate-100">
                Review & Approve Standardized Scenarios ({tasks.filter((t) => t.approved).length}{' '}
                / {tasks.length} approved)
              </h3>
              <p className="mt-1 text-xs text-slate-400">{generationNote}</p>
            </div>

            <div className="flex flex-wrap items-center gap-3 shrink-0">
              <button
                type="button"
                onClick={() => setStep(1)}
                className="rounded-lg border border-slate-700 px-3.5 py-2 text-xs font-medium text-slate-300 hover:bg-slate-800 whitespace-nowrap"
              >
                Back to Config
              </button>
              <button
                type="button"
                disabled={launching || tasks.filter((t) => t.approved).length === 0}
                onClick={handleLaunchRun}
                className="inline-flex items-center gap-2 rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-500 disabled:opacity-60 whitespace-nowrap"
              >
                {launching ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    <span>Launching...</span>
                  </>
                ) : (
                  <>
                    <Play className="h-4 w-4" />
                    <span>Launch Benchmark</span>
                  </>
                )}
              </button>
            </div>
          </div>

          <div className="space-y-3">
            {tasks.map((task) => {
              const isEditing = editingTaskId === task.id;
              return (
                <div
                  key={task.id}
                  className="rounded-xl border border-slate-800/80 bg-[#0D1426] p-5"
                >
                  {isEditing ? (
                    <TaskEditorForm
                      task={task}
                      onSave={handleSaveTask}
                      onCancel={() => setEditingTaskId(null)}
                    />
                  ) : (
                    <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
                      <div className="space-y-1.5 min-w-0">
                        <div className="flex flex-wrap items-center gap-2 text-xs">
                          <span className="font-mono font-semibold text-cyan-400">
                            {task.code}
                          </span>
                          <span className="text-slate-600" aria-hidden="true">
                            ·
                          </span>
                          <span className="font-medium text-slate-100">
                            {task.title}
                          </span>
                          <span className="text-slate-600" aria-hidden="true">
                            ·
                          </span>
                          <span
                            className={
                              task.difficulty === 'adversarial'
                                ? 'text-rose-400'
                                : task.difficulty === 'hard'
                                  ? 'text-amber-400'
                                  : 'text-slate-400'
                            }
                          >
                            {task.difficulty}
                          </span>
                        </div>

                        <p className="text-sm text-slate-300">{task.instructions}</p>
                        <p className="text-xs text-slate-400">
                          <strong>Expected Outcome:</strong> {task.expectedOutcome}
                        </p>
                        {task.deterministicRules?.requiredTools &&
                          task.deterministicRules.requiredTools.length > 0 && (
                            <p className="font-mono text-[11px] text-slate-500">
                              Required Tools:{' '}
                              {task.deterministicRules.requiredTools.join(', ')}
                            </p>
                          )}
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          type="button"
                          onClick={() => handleToggleApprove(task)}
                          className={`inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-medium whitespace-nowrap ${
                            task.approved
                              ? 'border-emerald-500/40 bg-emerald-500/10 text-emerald-300'
                              : 'border-slate-700 bg-slate-800/50 text-slate-400'
                          }`}
                        >
                          <Check className="h-3.5 w-3.5" />
                          <span>{task.approved ? 'Approved' : 'Skipped'}</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setEditingTaskId(task.id)}
                          className="rounded-lg border border-slate-700 px-3 py-1.5 text-xs font-medium text-slate-300 hover:bg-slate-800 whitespace-nowrap"
                        >
                          Edit
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteTask(task.id)}
                          aria-label={`Delete task ${task.code}`}
                          className="rounded-lg border border-slate-800 p-1.5 text-slate-400 hover:border-rose-500/40 hover:text-rose-400"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* STEP 3: Live Orchestrator Execution Monitor */}
      {step === 3 && activeRun && (
        <div className="rounded-xl border border-slate-800/80 bg-[#0D1426] p-8 space-y-6">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <div className="font-mono text-xs text-cyan-400">
                Run ID: {activeRun.id}
              </div>
              <h3 className="mt-1 text-xl font-bold text-slate-50">
                {activeRun.suiteName}
              </h3>
              <p className="mt-1 text-sm text-slate-400">
                Stage: {activeRun.currentStage}
              </p>
            </div>

            <div className="flex items-center gap-3 shrink-0">
              {activeRun.status === 'running' && (
                <button
                  type="button"
                  onClick={() => api.cancelRun(activeRun.id)}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-rose-500/40 bg-rose-500/10 px-3.5 py-2 text-xs font-medium text-rose-300 hover:bg-rose-500/20 whitespace-nowrap"
                >
                  <XCircle className="h-4 w-4" />
                  <span>Cancel Run</span>
                </button>
              )}
              {activeRun.status === 'completed' && (
                <button
                  type="button"
                  onClick={() => onRunCompleted(activeRun.id)}
                  className="inline-flex items-center gap-2 rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-500 whitespace-nowrap"
                >
                  <CheckCircle2 className="h-4 w-4" />
                  <span>Inspect Full Results</span>
                </button>
              )}
            </div>
          </div>

          {/* Progress Bar */}
          <div>
            <div className="mb-2 flex justify-between text-xs">
              <span className="text-slate-300">
                Status:{' '}
                <strong className="uppercase text-cyan-300">
                  {activeRun.status}
                </strong>
              </span>
              <span className="font-mono text-slate-300">
                {activeRun.completedTasks} / {activeRun.totalTasks} executions (
                {activeRun.progressPercent}%)
              </span>
            </div>
            <div className="h-2.5 w-full overflow-hidden rounded-full bg-slate-800">
              <div
                className="h-full bg-gradient-to-r from-blue-500 to-cyan-400 transition-all duration-300"
                style={{ width: `${activeRun.progressPercent}%` }}
              />
            </div>
          </div>

          {activeRun.summaries && activeRun.summaries.length > 0 && (
            <div className="overflow-x-auto border-t border-slate-800/80 pt-5">
              <h4 className="mb-3 text-sm font-semibold text-slate-200">
                Live Agent Standings
              </h4>
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="border-b border-slate-800 text-xs text-slate-400">
                    <th className="py-2 pr-4">Rank</th>
                    <th className="py-2 pr-4">Agent</th>
                    <th className="py-2 pr-4 text-right">Overall</th>
                    <th className="py-2 pr-4 text-right">Completion</th>
                    <th className="py-2 pr-4 text-right">Accuracy</th>
                    <th className="py-2 text-right">Latency</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {activeRun.summaries.map((s) => (
                    <tr key={s.agentId}>
                      <td className="py-2.5 pr-4 font-mono text-xs text-cyan-400">
                        #{s.rank}
                      </td>
                      <td className="py-2.5 pr-4 font-medium text-slate-100">
                        {s.agentName}
                      </td>
                      <td className="py-2.5 pr-4 text-right font-mono text-slate-100">
                        {s.overallScore}
                      </td>
                      <td className="py-2.5 pr-4 text-right font-mono text-slate-300">
                        {s.taskCompletionRate}%
                      </td>
                      <td className="py-2.5 pr-4 text-right font-mono text-slate-300">
                        {s.accuracyScore}%
                      </td>
                      <td className="py-2.5 text-right font-mono text-slate-300">
                        {s.avgLatencyMs}ms
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function TaskEditorForm({
  task,
  onSave,
  onCancel,
}: {
  task: TestCase;
  onSave: (updated: TestCase) => void;
  onCancel: () => void;
}) {
  const [title, setTitle] = useState(task.title);
  const [instructions, setInstructions] = useState(task.instructions);
  const [expectedOutcome, setExpectedOutcome] = useState(task.expectedOutcome);
  const [difficulty, setDifficulty] = useState<DifficultyLevel>(task.difficulty);

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        <div className="sm:col-span-2">
          <label className="block text-xs text-slate-400">Title</label>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="mt-1 w-full rounded-lg border border-slate-700 bg-[#070B14] px-3 py-1.5 text-sm text-slate-100"
          />
        </div>
        <div>
          <label className="block text-xs text-slate-400">Difficulty</label>
          <select
            value={difficulty}
            onChange={(e) => setDifficulty(e.target.value as DifficultyLevel)}
            className="mt-1 w-full rounded-lg border border-slate-700 bg-[#070B14] px-3 py-1.5 text-sm text-slate-100"
          >
            <option value="easy">easy</option>
            <option value="medium">medium</option>
            <option value="hard">hard</option>
            <option value="adversarial">adversarial</option>
          </select>
        </div>
      </div>

      <div>
        <label className="block text-xs text-slate-400">Instructions</label>
        <textarea
          rows={2}
          value={instructions}
          onChange={(e) => setInstructions(e.target.value)}
          className="mt-1 w-full rounded-lg border border-slate-700 bg-[#070B14] px-3 py-1.5 text-sm text-slate-100"
        />
      </div>

      <div>
        <label className="block text-xs text-slate-400">Expected Outcome</label>
        <input
          type="text"
          value={expectedOutcome}
          onChange={(e) => setExpectedOutcome(e.target.value)}
          className="mt-1 w-full rounded-lg border border-slate-700 bg-[#070B14] px-3 py-1.5 text-sm text-slate-100"
        />
      </div>

      <div className="flex justify-end gap-2">
        <button
          type="button"
          onClick={onCancel}
          className="rounded-lg border border-slate-700 px-3 py-1.5 text-xs text-slate-300"
        >
          Cancel
        </button>
        <button
          type="button"
          onClick={() =>
            onSave({ ...task, title, instructions, expectedOutcome, difficulty })
          }
          className="rounded-lg bg-blue-600 px-3 py-1.5 text-xs font-medium text-white"
        >
          Save Changes
        </button>
      </div>
    </div>
  );
}
