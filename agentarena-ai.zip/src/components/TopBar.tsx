import { Menu, Plus } from 'lucide-react';
import type { NavSection } from './Sidebar';

interface TopBarProps {
  activeSection: NavSection;
  onOpenMobileNav: () => void;
  onStartNewBenchmark: () => void;
}

const SECTION_TITLES: Record<NavSection, string> = {
  overview: 'Overview',
  'new-benchmark': 'New Benchmark',
  agents: 'Agent Management',
  history: 'Benchmark History',
  results: 'Results & Analytics',
  leaderboard: 'Leaderboard',
  settings: 'Settings',
};

export function TopBar({
  activeSection,
  onOpenMobileNav,
  onStartNewBenchmark,
}: TopBarProps) {
  return (
    <header className="flex h-16 shrink-0 items-center justify-between gap-4 border-b border-slate-800/80 bg-[#090E1B]/95 px-4 sm:px-8">
      <div className="flex items-center gap-3 min-w-0">
        <button
          type="button"
          onClick={onOpenMobileNav}
          aria-label="Open navigation menu"
          className="rounded-lg border border-slate-800 p-2 text-slate-300 hover:bg-slate-800 lg:hidden"
        >
          <Menu className="h-4 w-4" />
        </button>
        <div className="flex items-center gap-2 text-sm min-w-0">
          <span className="text-slate-400 hidden sm:inline whitespace-nowrap">
            AgentArena AI
          </span>
          <span className="text-slate-600 hidden sm:inline" aria-hidden="true">
            /
          </span>
          <h1 className="text-base font-semibold text-slate-100 truncate">
            {SECTION_TITLES[activeSection]}
          </h1>
        </div>
      </div>

      <button
        type="button"
        onClick={onStartNewBenchmark}
        className="inline-flex items-center gap-2 rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-blue-500 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-400 whitespace-nowrap shrink-0"
      >
        <Plus className="h-4 w-4" aria-hidden="true" />
        <span>New Benchmark</span>
      </button>
    </header>
  );
}
